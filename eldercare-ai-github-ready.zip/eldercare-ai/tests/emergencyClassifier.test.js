import { classifyIntent } from "../server/services/intentClassifier.js";

export function testEmergencyClassifier() {
  console.log("▶ Running Test Suite: Multi-Lingual Intent & Emergency Classifier");
  let passed = 0;
  let failed = 0;

  const testCases = [
    // 1. Acute Emergencies (English, Hindi, Hinglish)
    { query: "I can't breathe and feel breathless", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "I have severe chest pain and pressure", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "मुझे बहुत तेज़ छाती में दर्द हो रहा है", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "seene me bahut tez dard ho raha hai", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "saans nahi aa rahi", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "I think I am having a stroke and face is drooping", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },
    { query: "I fell down and cannot get up", expectedIntent: "EMERGENCY", expectedSeverity: "CRITICAL" },

    // 2. Fall Assistance
    { query: "I fell on the floor", expectedIntent: "FALL_ASSISTANCE", expectedSeverity: "HIGH" },
    { query: "मैं फर्श पर गिर गई हूँ", expectedIntent: "FALL_ASSISTANCE", expectedSeverity: "HIGH" },
    { query: "Main gir gaya hoon", expectedIntent: "FALL_ASSISTANCE", expectedSeverity: "HIGH" },

    // 3. Medicine Inquiries
    { query: "What medicines do I have today?", expectedIntent: "MEDICINE_QUERY", expectedSeverity: "LOW" },
    { query: "आज मुझे कौन सी दवाई लेनी है?", expectedIntent: "MEDICINE_QUERY", expectedSeverity: "LOW" },
    { query: "Meri next medicine kab hai?", expectedIntent: "MEDICINE_QUERY", expectedSeverity: "LOW" },
    { query: "Maine morning wali tablet li kya?", expectedIntent: "MEDICINE_QUERY", expectedSeverity: "LOW" },

    // 4. Appointment Inquiries
    { query: "When is my doctor appointment?", expectedIntent: "APPOINTMENT_QUERY", expectedSeverity: "LOW" },
    { query: "Who is my doctor?", expectedIntent: "APPOINTMENT_QUERY", expectedSeverity: "LOW" },
    { query: "Doctor ke paas kab jaana hai?", expectedIntent: "APPOINTMENT_QUERY", expectedSeverity: "LOW" },

    // 5. Health Knowledge
    { query: "What is blood pressure?", expectedIntent: "HEALTH_INFO", expectedSeverity: "LOW" },
    { query: "I feel dizzy after standing up", expectedIntent: "HEALTH_INFO", expectedSeverity: "MEDIUM" },
    { query: "How much water should I drink?", expectedIntent: "HEALTH_INFO", expectedSeverity: "LOW" },

    // 6. Companionship & Entertainment
    { query: "I feel very lonely today", expectedIntent: "COMPANIONSHIP", expectedSeverity: "LOW" },
    { query: "Tell me a short inspiring story", expectedIntent: "STORY", expectedSeverity: "LOW" },
    { query: "Tell me a clean funny joke", expectedIntent: "JOKE", expectedSeverity: "LOW" },
    { query: "Good morning, how are you?", expectedIntent: "GREETING", expectedSeverity: "LOW" },
    { query: "Thank you so much", expectedIntent: "GRATITUDE", expectedSeverity: "LOW" },

    // 7. Unknown / Fallback
    { query: "xyzabc123randomtext", expectedIntent: "UNKNOWN", expectedSeverity: "LOW" }
  ];

  for (const tc of testCases) {
    const res = classifyIntent(tc.query);
    const isIntentMatch = res.intent === tc.expectedIntent;
    const isSeverityMatch = res.severity === tc.expectedSeverity;

    if (isIntentMatch && isSeverityMatch) {
      console.log(`  ✅ PASSED: "${tc.query}" -> [${res.intent}] (${res.severity})`);
      passed++;
    } else {
      console.error(`  ❌ FAILED: "${tc.query}" -> Expected ${tc.expectedIntent}/${tc.expectedSeverity}, got ${res.intent}/${res.severity}`);
      failed++;
    }
  }

  return { passed, failed };
}
