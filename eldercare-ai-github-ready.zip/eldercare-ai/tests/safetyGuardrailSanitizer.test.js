import { sanitizeAiResponse } from "../server/services/safetyGuardrails.js";

export function testSafetySanitizer() {
  console.log("▶ Running Test Suite: AI Response Safety Sanitizer & Disclaimer Injection");
  let passed = 0;
  let failed = 0;

  // Case 1: Normal safe conversational text
  const safeText = "Good morning Kamla ji! Remember to drink a glass of water.";
  const res1 = sanitizeAiResponse(safeText, "en");
  if (res1 === safeText) {
    console.log("  ✅ PASSED: Safe conversational text passed untouched");
    passed++;
  } else {
    console.error("  ❌ FAILED: Safe text unexpectedly altered");
    failed++;
  }

  // Case 2: Attempted dosage prescription
  const unsafeText = "You should take 20 mg more of your BP tablet.";
  const res2 = sanitizeAiResponse(unsafeText, "en");
  if (res2.includes("Only your doctor can prescribe or adjust medication dosages")) {
    console.log("  ✅ PASSED: Prescription attempt intercepted with doctor redirection");
    passed++;
  } else {
    console.error("  ❌ FAILED: Prescription attempt was not sanitized:", res2);
    failed++;
  }

  return { passed, failed };
}
