import { testEmergencyClassifier } from "./emergencyClassifier.test.js";
import { testLocalAiService } from "./localAiService.test.js";
import { testCareScoreCalculation } from "./careScore.test.js";
import { testSafetySanitizer } from "./safetyGuardrailSanitizer.test.js";

async function run() {
  console.log("==================================================");
  console.log("🌸 ElderCare AI — 100% Local AI Automated Test Suite");
  console.log("==================================================\n");

  const r1 = testEmergencyClassifier();
  console.log("");
  const r2 = await testLocalAiService();
  console.log("");
  const r3 = testCareScoreCalculation();
  console.log("");
  const r4 = testSafetySanitizer();

  const totalPassed = r1.passed + r2.passed + r3.passed + r4.passed;
  const totalFailed = r1.failed + r2.failed + r3.failed + r4.failed;

  console.log("\n==================================================");
  console.log(`Test Results Summary: ${totalPassed} Passed, ${totalFailed} Failed`);
  if (totalFailed === 0) {
    console.log("🎉 ALL TESTS PASSED WITH 100% SUCCESS!");
  } else {
    console.error("❌ Some tests failed. Please investigate.");
    process.exit(1);
  }
  console.log("==================================================");
}

run();
