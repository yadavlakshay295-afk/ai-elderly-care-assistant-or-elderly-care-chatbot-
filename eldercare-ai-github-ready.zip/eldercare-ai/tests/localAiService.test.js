import { getLocalAiResponse } from "../server/services/localAiService.js";

export async function testLocalAiService() {
  console.log("▶ Running Test Suite: Local AI Service End-to-End Orchestrator");
  let passed = 0;
  let failed = 0;

  const mockContext = {
    name: "Kamla Devi",
    age: 72,
    phone: "+91 98765 43210",
    primaryCaregiver: { name: "Rahul Sharma", phone: "+91 98765 00001" },
    todayMedicines: [
      { name: "Amlodipine 5mg", scheduledTime: "08:00 AM", statusToday: "TAKEN", status: "TAKEN" },
      { name: "Metformin 500mg", scheduledTime: "01:30 PM", statusToday: "TAKEN", status: "TAKEN" },
      { name: "Vitamin D3", scheduledTime: "08:00 PM", statusToday: "PENDING", status: "PENDING" },
      { name: "Calcium 500mg", scheduledTime: "09:30 PM", statusToday: "PENDING", status: "PENDING" }
    ],
    appointments: [
      { doctorName: "Dr. Arvind Sharma", specialty: "Cardiologist", clinicName: "City Heart Clinic", displayDate: "Tomorrow", time: "10:30 AM", purpose: "Routine Checkup" }
    ]
  };

  // 1. Test Acute Emergency
  const resEmergency = await getLocalAiResponse({
    message: "I have severe chest pain and pressure",
    userContext: mockContext,
    language: "en"
  });
  if (resEmergency.intent === "EMERGENCY" && resEmergency.severity === "CRITICAL" && resEmergency.actionType === "TRIGGER_SOS") {
    console.log("  ✅ PASSED: Acute Emergency returns CRITICAL SOS trigger");
    passed++;
  } else {
    console.error("  ❌ FAILED: Emergency response mismatch:", resEmergency);
    failed++;
  }

  // 2. Test Fall Assistance
  const resFall = await getLocalAiResponse({
    message: "I fell down on the floor",
    userContext: mockContext,
    language: "en"
  });
  if (resFall.intent === "FALL_ASSISTANCE" && resFall.severity === "HIGH" && resFall.actionType === "TRIGGER_FALL_MODAL") {
    console.log("  ✅ PASSED: Fall incident triggers guided modal");
    passed++;
  } else {
    console.error("  ❌ FAILED: Fall response mismatch:", resFall);
    failed++;
  }

  // 3. Test Dynamic Medicine - All Today
  const resMeds = await getLocalAiResponse({
    message: "What medicines do I have today?",
    userContext: mockContext,
    language: "en"
  });
  if (resMeds.intent === "MEDICINE_QUERY" && resMeds.text.includes("Amlodipine") && resMeds.text.includes("Vitamin D3")) {
    console.log("  ✅ PASSED: Dynamic medicine list contains user's actual medicine records");
    passed++;
  } else {
    console.error("  ❌ FAILED: Medicine response did not include actual data:", resMeds.text);
    failed++;
  }

  // 4. Test Dynamic Medicine - Next Pending
  const resNextMed = await getLocalAiResponse({
    message: "What is my next medicine?",
    userContext: mockContext,
    language: "en"
  });
  if (resNextMed.intent === "MEDICINE_QUERY" && resNextMed.text.includes("Vitamin D3")) {
    console.log("  ✅ PASSED: Next medicine query accurately identifies pending Vitamin D3");
    passed++;
  } else {
    console.error("  ❌ FAILED: Next medicine query failed:", resNextMed.text);
    failed++;
  }

  // 5. Test Dynamic Appointments
  const resApt = await getLocalAiResponse({
    message: "When is my doctor appointment?",
    userContext: mockContext,
    language: "en"
  });
  if (resApt.intent === "APPOINTMENT_QUERY" && resApt.text.includes("Dr. Arvind Sharma") && resApt.text.includes("10:30 AM")) {
    console.log("  ✅ PASSED: Appointment query dynamically returns doctor and scheduled time");
    passed++;
  } else {
    console.error("  ❌ FAILED: Appointment query failed:", resApt.text);
    failed++;
  }

  // 6. Test Hindi Language Response
  const resHindi = await getLocalAiResponse({
    message: "आज मुझे कौन सी दवाई लेनी है?",
    userContext: mockContext,
    language: "hi"
  });
  if (resHindi.intent === "MEDICINE_QUERY" && /[\u0900-\u097F]/.test(resHindi.text)) {
    console.log("  ✅ PASSED: Hindi query returns natural Hindi response");
    passed++;
  } else {
    console.error("  ❌ FAILED: Hindi response failed:", resHindi.text);
    failed++;
  }

  // 7. Test Hinglish Language Response
  const resHinglish = await getLocalAiResponse({
    message: "Meri next medicine kab hai?",
    userContext: mockContext,
    language: "en" // will auto-detect hinglish
  });
  if (resHinglish.intent === "MEDICINE_QUERY" && resHinglish.text.includes("Vitamin D3")) {
    console.log("  ✅ PASSED: Hinglish query correctly resolved and answered");
    passed++;
  } else {
    console.error("  ❌ FAILED: Hinglish query failed:", resHinglish.text);
    failed++;
  }

  // 8. Test Educational Health Knowledge
  const resBP = await getLocalAiResponse({
    message: "What is blood pressure?",
    userContext: mockContext,
    language: "en"
  });
  if (resBP.intent === "HEALTH_INFO" && resBP.text.includes("Blood pressure")) {
    console.log("  ✅ PASSED: Health knowledge query returns educational info");
    passed++;
  } else {
    console.error("  ❌ FAILED: Health knowledge failed:", resBP.text);
    failed++;
  }

  // 9. Test Story Generation
  const resStory = await getLocalAiResponse({
    message: "Tell me a short inspiring story",
    userContext: mockContext,
    language: "en"
  });
  if (resStory.intent === "STORY" && resStory.text.length > 50) {
    console.log("  ✅ PASSED: Story request returns uplifting short story");
    passed++;
  } else {
    console.error("  ❌ FAILED: Story generation failed:", resStory.text);
    failed++;
  }

  // 10. Test Joke Generation
  const resJoke = await getLocalAiResponse({
    message: "Tell me a clean funny joke",
    userContext: mockContext,
    language: "en"
  });
  if (resJoke.intent === "JOKE" && resJoke.text.length > 20) {
    console.log("  ✅ PASSED: Joke request returns wholesome humor");
    passed++;
  } else {
    console.error("  ❌ FAILED: Joke generation failed:", resJoke.text);
    failed++;
  }

  // 11. Test Graceful Unknown Fallback
  const resUnknown = await getLocalAiResponse({
    message: "qwerty987xyz random nonsense",
    userContext: mockContext,
    language: "en"
  });
  if (resUnknown.intent === "UNKNOWN" && resUnknown.actionType === "SHOW_GUIDED_SUGGESTIONS") {
    console.log("  ✅ PASSED: Unknown query returns graceful guided suggestions");
    passed++;
  } else {
    console.error("  ❌ FAILED: Unknown query failed:", resUnknown);
    failed++;
  }

  return { passed, failed };
}
