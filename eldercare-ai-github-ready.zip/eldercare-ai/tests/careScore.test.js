import { calculateCareScore } from "../src/utils/careScore.js";

export function testCareScoreCalculation() {
  console.log("▶ Running Test Suite: Non-Diagnostic Care Activity Score Calculator");
  let passed = 0;
  let failed = 0;

  const todayStr = new Date().toISOString().split("T")[0];

  // Case 1: All 4 medicines taken + checked in today
  const res1 = calculateCareScore({
    medicines: [
      { id: '1', statusToday: 'TAKEN' },
      { id: '2', statusToday: 'TAKEN' },
      { id: '3', statusToday: 'TAKEN' },
      { id: '4', statusToday: 'TAKEN' }
    ],
    wellnessCheckins: [{ date: todayStr }],
    appointments: []
  });

  if (res1.score === 100 && res1.statusLabel === "Excellent Adherence") {
    console.log(`  ✅ PASSED: 100% adherence score (100 pts)`);
    passed++;
  } else {
    console.error(`  ❌ FAILED: Expected score 100, got ${res1.score}`);
    failed++;
  }

  // Case 2: Half medicines taken + checked in today
  const res2 = calculateCareScore({
    medicines: [
      { id: '1', statusToday: 'TAKEN' },
      { id: '2', statusToday: 'PENDING' }
    ],
    wellnessCheckins: [{ date: todayStr }],
    appointments: []
  });

  if (res2.score === 75) { // 25 (meds) + 30 (wellness) + 20 (routine) = 75
    console.log(`  ✅ PASSED: Half medication adherence score (75 pts)`);
    passed++;
  } else {
    console.error(`  ❌ FAILED: Expected score 75, got ${res2.score}`);
    failed++;
  }

  // Case 3: Zero medicines taken + no check-in today
  const res3 = calculateCareScore({
    medicines: [
      { id: '1', statusToday: 'PENDING' },
      { id: '2', statusToday: 'PENDING' }
    ],
    wellnessCheckins: [{ date: "2020-01-01" }],
    appointments: []
  });

  if (res3.score === 35 && res3.statusColor === "red") { // 0 (meds) + 15 (wellness) + 20 (routine) = 35
    console.log(`  ✅ PASSED: Low adherence score triggers warning status (35 pts)`);
    passed++;
  } else {
    console.error(`  ❌ FAILED: Expected score 35 with red status, got ${res3.score} / ${res3.statusColor}`);
    failed++;
  }

  return { passed, failed };
}
