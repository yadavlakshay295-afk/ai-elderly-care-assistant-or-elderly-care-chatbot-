import express from "express";
import { getLocalAiResponse } from "../services/localAiService.js";
import { classifyIntent } from "../services/intentClassifier.js";
import { seedElderlyProfile, seedMedicines, seedAppointments } from "../data/seedData.js";

const router = express.Router();

/**
 * POST /api/ai/chat
 * Primary conversation endpoint for Elderly Care Companion (100% Local AI)
 */
router.post("/chat", async (req, res) => {
  try {
    const { message, language = "en", userContext } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Message string is required" });
    }

    const context = userContext || {
      name: seedElderlyProfile.name,
      age: seedElderlyProfile.age,
      primaryCaregiver: seedElderlyProfile.primaryCaregiver,
      todayMedicines: seedMedicines.map(m => ({ 
        name: m.name, 
        time: m.scheduledTime, 
        scheduledTime: m.scheduledTime,
        status: m.statusToday,
        statusToday: m.statusToday 
      })),
      appointments: seedAppointments.map(a => ({ 
        doctor: a.doctorName, 
        doctorName: a.doctorName,
        clinic: a.clinicName,
        clinicName: a.clinicName,
        date: a.displayDate, 
        displayDate: a.displayDate,
        time: a.time,
        purpose: a.purpose 
      }))
    };

    const response = await getLocalAiResponse({
      message,
      userContext: context,
      language
    });

    return res.json({
      success: true,
      data: response
    });
  } catch (err) {
    console.error("Local AI Chat Route Error:", err);
    return res.status(500).json({
      success: false,
      error: "Failed to generate response. Please try again."
    });
  }
});

/**
 * POST /api/ai/classify
 * Intent and emergency classifier endpoint
 */
router.post("/classify", (req, res) => {
  const { message, language } = req.body;
  const classification = classifyIntent(message || "", language);
  return res.json({
    success: true,
    data: classification
  });
});

export default router;
