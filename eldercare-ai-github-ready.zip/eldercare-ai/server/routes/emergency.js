import express from "express";
import { seedEmergencyContacts, seedEmergencyEvents } from "../data/seedData.js";

const router = express.Router();

let emergencyEventsStore = JSON.parse(JSON.stringify(seedEmergencyEvents));
let contactsStore = JSON.parse(JSON.stringify(seedEmergencyContacts));

/**
 * GET /api/emergency/contacts
 */
router.get("/contacts", (req, res) => {
  return res.json({
    success: true,
    data: contactsStore
  });
});

/**
 * GET /api/emergency/events
 */
router.get("/events", (req, res) => {
  return res.json({
    success: true,
    data: emergencyEventsStore
  });
});

/**
 * POST /api/emergency/trigger
 * Trigger an SOS event - registers emergency dispatch (Caregiver, Police, Ambulance + SMS)
 */
router.post("/trigger", (req, res) => {
  const { type, location, userNotes, isDemo = true, dispatchedTargets, smsStatus } = req.body;

  const newEvent = {
    id: `sos_${Date.now()}`,
    userId: "elderly_kamla_001",
    timestamp: new Date().toISOString(),
    displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    type: type || "TRIPLE_SOS_DISPATCH",
    status: "ACTIVE_ALERT",
    triggeredBy: "Kamla Devi",
    location: location || "GPS Location: 28.4595° N, 77.0266° E (Sector 14, Gurugram)",
    isDemo: Boolean(isDemo),
    caregiverNotified: true,
    dispatchedTargets: dispatchedTargets || [
      { role: "Caregiver (Son)", status: "CALLED_AND_SMS_SENT" },
      { role: "Police (112)", status: "CALLED_AND_SMS_SENT" },
      { role: "Ambulance (108)", status: "CALLED_AND_SMS_SENT" }
    ],
    smsDeliveredTo: smsStatus || ["Caregiver", "Police", "Ambulance"],
    userNotes: userNotes || "Emergency SOS: Sequential call dispatch (Son -> Police -> Ambulance) + simultaneous GPS SMS triggered."
  };

  emergencyEventsStore.unshift(newEvent);

  return res.status(201).json({
    success: true,
    data: newEvent,
    message: isDemo 
      ? "DEMO: Simultaneous Location SMS sent & call dispatch initiated to Son, Police (112), and Ambulance (108)."
      : "LIVE: Emergency alert dispatched to caregiver, police, and ambulance with live GPS location."
  });
});

/**
 * POST /api/emergency/fall-assistance
 */
router.post("/fall-assistance", (req, res) => {
  const { ableToMove, stepReached, notes } = req.body;

  const fallEvent = {
    id: `fall_${Date.now()}`,
    userId: "elderly_kamla_001",
    timestamp: new Date().toISOString(),
    displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    type: ableToMove ? "FALL_ASSISTED_RECOVERY" : "FALL_IMMOBILIZED_ALERT",
    status: ableToMove ? "RECOVERED_GUIDED" : "CRITICAL_HELP_DISPATCHED",
    triggeredBy: "Kamla Devi",
    ableToMove: Boolean(ableToMove),
    stepReached: stepReached || "Initial Triage",
    notes: notes || (ableToMove ? "Elderly followed guided recovery steps." : "Elderly reported unable to move. Emergency alerted.")
  };

  emergencyEventsStore.unshift(fallEvent);

  return res.status(201).json({
    success: true,
    data: fallEvent
  });
});

/**
 * PUT /api/emergency/events/:id/resolve
 */
router.put("/events/:id/resolve", (req, res) => {
  const { id } = req.params;
  const event = emergencyEventsStore.find(e => e.id === id);
  if (event) {
    event.status = "RESOLVED";
    event.resolvedAt = new Date().toISOString();
    return res.json({ success: true, data: event });
  }
  return res.status(404).json({ error: "Event not found" });
});

export default router;
