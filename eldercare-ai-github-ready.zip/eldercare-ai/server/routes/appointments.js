import express from "express";
import { seedAppointments } from "../data/seedData.js";

const router = express.Router();

let appointmentsStore = JSON.parse(JSON.stringify(seedAppointments));

/**
 * GET /api/appointments
 */
router.get("/", (req, res) => {
  return res.json({
    success: true,
    data: appointmentsStore
  });
});

/**
 * POST /api/appointments
 */
router.post("/", (req, res) => {
  const { doctorName, specialty, clinicName, date, displayDate, time, purpose, notes } = req.body;

  if (!doctorName || !date || !time) {
    return res.status(400).json({ error: "Doctor name, date, and time are required" });
  }

  const newAppointment = {
    id: `apt_${Date.now()}`,
    userId: "elderly_kamla_001",
    doctorName,
    specialty: specialty || "Physician",
    clinicName: clinicName || "City Hospital",
    date,
    displayDate: displayDate || date,
    time,
    purpose: purpose || "General Checkup",
    notes: notes || "Carry medical records.",
    reminderSent: false,
    status: "CONFIRMED"
  };

  appointmentsStore.unshift(newAppointment);

  return res.status(201).json({
    success: true,
    data: newAppointment
  });
});

/**
 * DELETE /api/appointments/:id
 */
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  appointmentsStore = appointmentsStore.filter(a => a.id !== id);
  return res.json({
    success: true,
    message: "Appointment removed successfully"
  });
});

export default router;
