import express from "express";
import { seedMedicines } from "../data/seedData.js";

const router = express.Router();

// In-memory data store initialized with seed medicines
let medicinesStore = JSON.parse(JSON.stringify(seedMedicines));
let medicineLogs = [
  {
    id: "log_01",
    medicineId: "med_001",
    name: "Amlodipine (एम्लोडिपिन)",
    status: "TAKEN",
    time: "08:15 AM",
    date: new Date().toISOString().split("T")[0]
  },
  {
    id: "log_02",
    medicineId: "med_002",
    name: "Metformin (मेटफॉर्मिन)",
    status: "TAKEN",
    time: "01:45 PM",
    date: new Date().toISOString().split("T")[0]
  }
];

/**
 * GET /api/medicines
 * Retrieve all active medicines
 */
router.get("/", (req, res) => {
  return res.json({
    success: true,
    data: medicinesStore
  });
});

/**
 * POST /api/medicines
 * Add a new medicine
 */
router.post("/", (req, res) => {
  const { name, dosage, form, timeSlot, scheduledTime, frequency, withFood, startDate, endDate, instructions } = req.body;

  if (!name || !scheduledTime) {
    return res.status(400).json({ error: "Medicine name and scheduled time are required" });
  }

  const newMedicine = {
    id: `med_${Date.now()}`,
    userId: "elderly_kamla_001",
    name,
    dosage: dosage || "1 dose",
    form: form || "1 tablet",
    timeSlot: timeSlot || "Morning",
    scheduledTime,
    frequency: frequency || "Daily",
    withFood: withFood || "After food",
    startDate: startDate || new Date().toISOString().split("T")[0],
    endDate: endDate || "Ongoing",
    statusToday: "PENDING",
    instructions: instructions || "Take with water as advised by doctor."
  };

  medicinesStore.push(newMedicine);

  return res.status(201).json({
    success: true,
    data: newMedicine
  });
});

/**
 * PUT /api/medicines/:id/status
 * Update status for today ([TAKEN], [SKIP], [PENDING])
 */
router.put("/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // 'TAKEN', 'SKIPPED', 'PENDING'

  const medIndex = medicinesStore.findIndex(m => m.id === id);
  if (medIndex === -1) {
    return res.status(404).json({ error: "Medicine not found" });
  }

  const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  medicinesStore[medIndex].statusToday = status;
  if (status === "TAKEN") {
    medicinesStore[medIndex].takenAt = nowTime;
  } else {
    delete medicinesStore[medIndex].takenAt;
  }

  // Record log
  medicineLogs.unshift({
    id: `log_${Date.now()}`,
    medicineId: id,
    name: medicinesStore[medIndex].name,
    status,
    time: nowTime,
    date: new Date().toISOString().split("T")[0]
  });

  return res.json({
    success: true,
    data: medicinesStore[medIndex]
  });
});

/**
 * DELETE /api/medicines/:id
 */
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  medicinesStore = medicinesStore.filter(m => m.id !== id);
  return res.json({
    success: true,
    message: "Medicine removed successfully"
  });
});

/**
 * GET /api/medicines/history
 * Retrieve medicine adherence logs
 */
router.get("/history", (req, res) => {
  return res.json({
    success: true,
    data: medicineLogs
  });
});

export default router;
