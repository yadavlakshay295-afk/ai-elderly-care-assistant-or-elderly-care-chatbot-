import express from "express";
import { seedWellnessCheckins } from "../data/seedData.js";

const router = express.Router();

let wellnessStore = JSON.parse(JSON.stringify(seedWellnessCheckins));

/**
 * GET /api/wellness
 */
router.get("/", (req, res) => {
  return res.json({
    success: true,
    data: wellnessStore
  });
});

/**
 * POST /api/wellness
 * Record a daily wellness check-in
 */
router.post("/", (req, res) => {
  const { mood, moodEmoji, moodLabel, sleepHours, sleepQuality, waterGlasses, mealsTaken, painLevel, painArea, notes } = req.body;

  const now = new Date();
  const newCheckin = {
    id: `well_${Date.now()}`,
    userId: "elderly_kamla_001",
    date: now.toISOString().split("T")[0],
    time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    mood: mood || "good",
    moodEmoji: moodEmoji || "😊",
    moodLabel: moodLabel || "Good",
    sleepHours: Number(sleepHours) || 7,
    sleepQuality: sleepQuality || "Good",
    waterGlasses: Number(waterGlasses) || 6,
    mealsTaken: mealsTaken || { breakfast: true, lunch: true, dinner: true },
    painLevel: Number(painLevel) || 0,
    painArea: painArea || "None",
    notes: notes || "Feeling peaceful today."
  };

  wellnessStore.unshift(newCheckin);

  return res.status(201).json({
    success: true,
    data: newCheckin
  });
});

export default router;
