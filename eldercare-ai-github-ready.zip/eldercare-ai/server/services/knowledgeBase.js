// Verified Local Knowledge Base for Elderly Wellness & Care Education
// Strictly educational, supportive, and non-diagnostic
// Clear, simple explanations in English, Hindi, and Hinglish

export const KNOWLEDGE_TOPICS = {
  BP: {
    en: "Blood pressure is the natural force of blood flowing through your body as your heart beats. For seniors, keeping it steady around 120/80 with less salt, daily gentle walks, and timely medication keeps your heart and brain healthy. Your doctor Dr. Sharma will explain your exact target.",
    hi: "रक्तचाप (Blood Pressure) वह सामान्य दबाव है जिससे दिल पूरे शरीर में खून पहुँचाता है। बुजुर्गों के लिए कम नमक, हल्की सैर, और समय पर दवाई लेने से यह नियंत्रित (लगभग 120/80) रहता है। डॉ. शर्मा आपकी व्यक्तिगत जाँच के अनुसार सटीक मार्गदर्शन देंगे।",
    hinglish: "Blood pressure wo force hai jisse heart pure body me blood supply karta hai. Seniors ke liye kam namak, daily light walking, aur timely dawa lene se BP control me rehta hai. Dr. Sharma se regular follow-up zaroori hai."
  },

  DIZZINESS: {
    en: "Feeling dizzy or lightheaded upon standing often happens when blood pressure briefly shifts. Please sit down comfortably right away, rest your feet flat, and take slow sips of water. If dizziness continues or is severe, let us alert your caregiver and doctor.",
    hi: "अचानक खड़े होने पर हल्का चक्कर आना रक्तचाप के त्वरित बदलाव या पानी की कमी से हो सकता है। कृपया तुरंत किसी आरामदायक कुर्सी पर बैठ जाएँ और धीरे-धीरे गुनगुना पानी पिएँ। यदि चक्कर बार-बार आए तो डॉ. शर्मा से तुरंत परामर्श लें।",
    hinglish: "Achanak khade hone par chakkar aana BP shift hone ya dehydration ki wajah se ho sakta hai. Please turant aaram se baith jayein aur thoda paani piyein. Agar chakkar zyada ho toh Dr. Sharma ko zaroor batayein."
  },

  HYDRATION: {
    en: "Staying well-hydrated keeps your energy high, aids digestion, and prevents sudden dizziness. Seniors should aim for about 6 to 8 small glasses of water or warm liquids daily, spaced gently throughout the morning and afternoon.",
    hi: "पर्याप्त पानी पीने से शरीर में ऊर्जा बनी रहती है, पाचन अच्छा रहता है और चक्कर आने की संभावना कम होती है। बुजुर्गों को दिन भर में 6 से 8 गिलास गुनगुना पानी या ताज़ा तरल पदार्थ धीरे-धीरे पीना चाहिए।",
    hinglish: "Rozana 6 se 8 glass paani peene se energy rehti hai, digestion theek rehta hai aur dizziness se bachav hota hai. Raat ko sone se thoda pehle paani kam piyein taaki neend disturb na ho."
  },

  SLEEP: {
    en: "A restful 7-8 hours of sleep helps repair your body and mind. Good habits include keeping your bedroom pleasantly quiet, having a light warm dinner early, avoiding bright screens before bed, and drinking a small cup of warm milk.",
    hi: "7 से 8 घंटे की गहरी नींद शरीर और दिमाग को तरोताज़ा रखती है। सोने से पहले हल्का भोजन करें, गुनगुना दूध पिएँ, कमरे को शांत रखें और रात को स्क्रीन से दूर रहें। इससे नींद बहुत सुकून भरी आती है।",
    hinglish: "7-8 hours ki achi neend ke liye shaam ko halka khana khayein, sone se pehle gunguna doodh lein aur kamre ko shaant rakhein. Regular routine se neend kaafi achi aati hai."
  },

  FALL_PREVENTION: {
    en: "To prevent slips and falls at home: ensure rooms and hallways are brightly lit, remove loose rugs or clutter from pathways, wear non-skid slippers, and use bathroom grab bars. Always stand up slowly from bed or chairs.",
    hi: "घर में फिसलने और गिरने से बचने के आसान उपाय:\n1. रास्तों में पर्याप्त रोशनी रखें।\n2. फर्श पर फैले पायदान या तार हटा दें।\n3. फिसलने से रोकने वाली चप्पलें पहनें।\n4. बिस्तर या कुर्सी से हमेशा धीरे-धीरे उठें।",
    hinglish: "Ghar me girne se bachne ke safe tips:\n1. Raaste me achi roshni rakhein.\n2. Loose rugs aur clutter hata dein.\n3. Anti-skid chappal pehnein.\n4. Bed ya chair se aaram se dheere uthein."
  },

  HEADACHE: {
    en: "Mild headaches in seniors can be due to eye fatigue, dehydration, or neck tension. Please rest in a quiet, dimly lit room, sip a glass of water, and relax your shoulders. If the headache is sudden and unusually severe, seek emergency medical care.",
    hi: "हल्का सिरदर्द आँखों की थकान, पानी की कमी या तनाव से हो सकता है। कृपया थोड़ी देर शांत कमरे में आँखें बंद करके आराम करें और पानी पिएँ। यदि सिरदर्द अचानक और बहुत तेज़ हो, तो तुरंत डॉक्टर को दिखाएँ।",
    hinglish: "Halka sar dard paani ki kami ya fatigue se ho sakta hai. Please thoda paani piyein aur shaant kamre me rest karein. Agar pain achanak bohot tez ho toh turant doctor ko consult karein."
  },

  FEVER: {
    en: "If you are feeling feverish, please rest, drink plenty of fluids, and check your temperature with a thermometer. Do not take self-prescribed medications; please inform your caregiver Rahul and consult Dr. Sharma.",
    hi: "यदि शरीर गर्म लग रहा है या बुखार जैसा महसूस हो रहा है, तो आराम करें, पर्याप्त पानी पिएँ और थर्मामीटर से तापमान मापें। बिना डॉक्टर की सलाह के कोई दवाई न लें और तुरंत डॉ. शर्मा से परामर्श लें।",
    hinglish: "Agar bukhar mehsoos ho raha hai toh rest karein, liquid fluids lein aur thermometer se check karein. Bina doctor ki salah ke koi extra medicine na lein."
  }
};

/**
 * Retrieves educational knowledge for a specific health topic.
 * @param {string} topicKey - 'BP', 'DIZZINESS', 'HYDRATION', 'SLEEP', 'FALL_PREVENTION', etc.
 * @param {string} language - 'en', 'hi', or 'hinglish'
 * @returns {object}
 */
export function getHealthKnowledge(topicKey, language = "en") {
  const topic = KNOWLEDGE_TOPICS[topicKey] || KNOWLEDGE_TOPICS.BP;
  const langKey = language === "hi" ? "hi" : language === "hinglish" ? "hinglish" : "en";
  const text = topic[langKey] || topic.en;

  return {
    text,
    intent: "HEALTH_INFO",
    subTopic: topicKey,
    severity: topicKey === "DIZZINESS" || topicKey === "FEVER" ? "MEDIUM" : "LOW",
    requires_human_help: false
  };
}
