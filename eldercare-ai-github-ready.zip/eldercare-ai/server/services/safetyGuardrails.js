// Safety Guardrails Engine for ElderCare AI
// Strictly enforces elderly health safety rules:
// 1. Intercept urgent medical emergencies (chest pain, stroke, breathing, hemorrhage, choking, seizure, severe trauma)
// 2. Never diagnose diseases, alter medication dosages, or prescribe drugs
// 3. Keep responses calm, respectful, brief, and supportive

// Critical Emergency Matchers (English + Hindi Romanized & Devanagari)
export const EMERGENCY_PATTERNS = [
  // 1. Acute Breathing Distress
  /\b(can'?t breathe|cannot breathe|difficulty breathing|breathless|gasping|suffocating|shortness of breath|not able to breathe)\b/i,
  /\b(saans|saas)\b.*\b(nahi|takleef|ruk|phool|problem|ghut)\b/i,
  /\b(dum ghut|dum ghot)\b/i,
  /(साँस नहीं|सांस नहीं|दम घुट|सांस लेने में तकलीफ|सांस फूल|सांस में)/,

  // 2. Acute Chest Pain / Heart Concerns
  /\b(chest|heart|cardiac)\b.*\b(pain|pressure|attack|tightness|burning|ache|crushing)\b/i,
  /\b(chaati|seene|seena|dil)\b.*\b(dard|jalan|daura|pressure|takleef)\b/i,
  /(छाती|सीने|दिल).*(दर्द|दौरा|भारीपन|जलन)/,

  // 3. Stroke / Neurological Emergency (FAST symptoms)
  /\b(stroke|face drooping|arm weak|slurred speech|sudden numbness|cannot speak|half body numb|vision lost suddenly|loss of speech)\b/i,
  /\b(lakwa|faliij|pakshaghat|bol nahi pa|chehra tedha|aadha shareer sunn)\b/i,
  /(लकवा|फालिज|पक्षघात|बोल नहीं पा|आधा शरीर सुन्न)/,

  // 4. Consciousness Loss, Fainting, Profuse Bleeding
  /\b(unconscious|passed out|blacked out|fainted|fainting|heavy bleeding|bleeding badly|blood pouring|lost consciousness)\b/i,
  /\b(behosh|chakkar khakar behosh|khoon beh raha|bahut khoon)\b/i,
  /(बेहोश|बेहोशी|चक्कर खाकर गिर|खून बह|ज्यादा खून)/,

  // 5. Choking, Poisoning, Seizures / Convulsions
  /\b(choking|poison|poisoning|severe burn|seizure|convulsions|fits|swallowed poison)\b/i,
  /\b(gale me atak|zeher|fits padna|daura padna|jhatke lagna)\b/i,
  /(गले में अटक|जहर|दौरा|फिट्स|झटके)/,

  // 6. Severe Traumatic Fall where unable to move or fracture
  /\b(cannot get up|can'?t get up|cannot move after fall|broken bone|fracture|unable to move|can'?t move|severe injury)\b/i,
  /\b(uth nahi pa|hil nahi pa|haddi toot|chot lag gayi chal nahi pa)\b/i,
  /(हड्डी टूट|उठ नहीं पा रही|उठ नहीं पा रहा|हिल नहीं पा रही|हिल नहीं पा रहा|गंभीर चोट)/
];

/**
 * Check if the input message contains any critical acute emergency indicators.
 * @param {string} text - User message
 * @returns {object|null} Safety classification if emergency, else null
 */
export function checkEmergency(text = "") {
  const clean = text.trim();
  if (!clean) return null;

  for (const pattern of EMERGENCY_PATTERNS) {
    if (pattern.test(clean)) {
      return {
        isEmergency: true,
        intent: "EMERGENCY",
        severity: "CRITICAL",
        requires_human_help: true,
        alertType: "MEDICAL_EMERGENCY",
        suggestedAction: "IMMEDIATE_SOS_TRIGGER"
      };
    }
  }

  return null;
}

/**
 * Generate a deterministic local emergency response.
 * @param {object} params
 * @param {string} params.language - 'en', 'hi', or 'hinglish'
 * @param {object} params.userContext - User details
 * @returns {object} Emergency response packet
 */
export function createEmergencyResponse({ language = "en", userContext = {} } = {}) {
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";
  const userName = userContext.name || (isHindi ? "कमला जी" : "Kamla ji");
  const caregiverName = userContext.primaryCaregiver?.name || "Rahul";
  const caregiverPhone = userContext.primaryCaregiver?.phone || "+91 98765 00001";

  let responseText = "";

  if (isHindi) {
    responseText = `${userName}, कृपया तुरंत शांत होकर सुरक्षित बैठ या लेट जाएँ। यह स्थिति गंभीर हो सकती है।\n\n🚨 आपातकालीन कदम:\n1. मैंने स्क्रीन पर SOS आपातकालीन बटन खोल दिया है।\n2. तुरंत ${caregiverName} (${caregiverPhone}) या 112 (राष्ट्रीय आपातकालीन सेवा) को कॉल करें।\n3. कोई भी भारी काम न करें और गहरी सांस लें।`;
  } else if (isHinglish) {
    responseText = `${userName}, please turant shaant hokar safe jagah baith ya let jayein. Yeh urgent ho sakta hai.\n\n🚨 Emergency Steps:\n1. Maine screen par SOS emergency button open kar diya hai.\n2. Turant ${caregiverName} (${caregiverPhone}) ya 112 emergency helpline ko call karein.\n3. Deep breath lein aur hilne ki koshish na karein.`;
  } else {
    responseText = `${userName}, please stay calm and immediately sit or lie down in a safe position. This sounds urgent.\n\n🚨 Emergency Guidance:\n1. I have activated the Emergency SOS screen for you.\n2. Call ${caregiverName} (${caregiverPhone}) or dial 112 emergency services immediately.\n3. Take slow, gentle breaths and avoid sudden movements.`;
  }

  return {
    text: responseText,
    intent: "EMERGENCY",
    severity: "CRITICAL",
    requires_human_help: true,
    actionType: "TRIGGER_SOS",
    isEmergency: true
  };
}

/**
 * Validates and sanitizes AI generated responses to prevent dangerous medical assertions.
 * @param {string} responseText - Raw text
 * @param {string} language - 'en', 'hi', or 'hinglish'
 * @returns {string} Sanitized response
 */
export function sanitizeAiResponse(responseText = "", language = "en") {
  let sanitized = responseText.trim();

  // Check if text attempted to prescribe dosages or alter prescriptions
  const prescriptionRedFlags = [
    /take \d+ mg more/i,
    /stop taking your/i,
    /increase your dosage/i,
    /decrease your dosage/i,
    /you definitely have/i,
    /diagnosed with/i
  ];

  for (const flag of prescriptionRedFlags) {
    if (flag.test(sanitized)) {
      if (language === "hi") {
        return "दवाइयों की मात्रा बदलना या निदान करना केवल आपके डॉक्टर के परामर्श पर होना चाहिए। कृपया अपने डॉक्टर या परिवार से बात करें।\n\n(नोट: मैं आपकी एआई देखभाल साथी हूँ, डॉक्टर नहीं।)";
      }
      return "Only your doctor can prescribe or adjust medication dosages. Please contact your doctor or caregiver for guidance.\n\n(Note: I am your AI care companion, not a doctor.)";
    }
  }

  return sanitized;
}
