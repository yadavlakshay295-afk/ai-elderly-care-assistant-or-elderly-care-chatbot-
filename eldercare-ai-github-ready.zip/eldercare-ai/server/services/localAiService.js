// Local AI Service for ElderCare AI
// 100% API-Free, Offline-First Local Intelligence Engine
// Zero external API dependencies, zero API keys required

import { classifyIntent, detectLanguage } from "./intentClassifier.js";
import { checkEmergency, createEmergencyResponse, sanitizeAiResponse } from "./safetyGuardrails.js";
import { handleMedicineQuery } from "./medicineHandler.js";
import { handleAppointmentQuery } from "./appointmentHandler.js";
import { getHealthKnowledge } from "./knowledgeBase.js";
import { 
  getStory, 
  getJoke, 
  getCompanionshipResponse, 
  getGreetingResponse, 
  getGratitudeResponse 
} from "./storiesAndJokes.js";

/**
 * Generates an intelligent, local, context-aware AI response.
 * @param {object} params
 * @param {string} params.message - Input string from user
 * @param {object} params.userContext - Contains profile, medicines, appointments, etc.
 * @param {string} params.language - 'en', 'hi', or auto-detected
 * @returns {Promise<object>} Structured response packet
 */
export async function getLocalAiResponse({ message = "", userContext = {}, language = "en" }) {
  const normalizedMessage = String(message).trim();
  if (!normalizedMessage) {
    return createHelpfulFallback({ language, userContext });
  }

  // 1. Language Detection
  const detectedLang = detectLanguage(normalizedMessage);
  // If user explicitly requests 'hi' from UI or message is Hindi/Hinglish, use matched language
  const activeLang = language === "hi" || detectedLang === "hi" 
    ? "hi" 
    : detectedLang === "hinglish" 
    ? "hinglish" 
    : "en";

  const userName = userContext.name || (activeLang === "hi" ? "कमला जी" : "Kamla ji");

  // 2. Safety Guardrails: Acute Emergency Check First
  const emergencyCheck = checkEmergency(normalizedMessage);
  if (emergencyCheck) {
    const emergencyRes = createEmergencyResponse({
      language: activeLang,
      userContext
    });
    return {
      ...emergencyRes,
      engine: "ElderCare Local Intelligence Engine"
    };
  }

  // 3. Intent Classification
  const classification = classifyIntent(normalizedMessage, activeLang);

  let responsePacket = null;

  // 4. Intent Dispatching
  switch (classification.intent) {
    case "FALL_ASSISTANCE":
      responsePacket = handleFallResponse({ language: activeLang, userContext });
      break;

    case "MEDICINE_QUERY":
      responsePacket = handleMedicineQuery({
        message: normalizedMessage,
        subType: classification.subType,
        language: activeLang,
        userContext
      });
      break;

    case "APPOINTMENT_QUERY":
      responsePacket = handleAppointmentQuery({
        message: normalizedMessage,
        subType: classification.subType,
        language: activeLang,
        userContext
      });
      break;

    case "HEALTH_INFO":
      responsePacket = getHealthKnowledge(classification.subTopic, activeLang);
      break;

    case "COMPANIONSHIP":
      responsePacket = getCompanionshipResponse({
        language: activeLang,
        userContext
      });
      break;

    case "STORY":
      responsePacket = getStory(activeLang);
      break;

    case "JOKE":
      responsePacket = getJoke(activeLang);
      break;

    case "GREETING":
      responsePacket = getGreetingResponse({
        language: activeLang,
        userContext
      });
      break;

    case "GRATITUDE":
      responsePacket = getGratitudeResponse({
        language: activeLang,
        userContext
      });
      break;

    case "UNKNOWN":
    default:
      responsePacket = createHelpfulFallback({
        language: activeLang,
        userContext,
        query: normalizedMessage
      });
      break;
  }

  // 5. Sanitize Output through Medical Guardrails
  const sanitizedText = sanitizeAiResponse(responsePacket.text, activeLang);

  return {
    text: sanitizedText,
    intent: classification.intent,
    severity: responsePacket.severity || classification.severity || "LOW",
    requires_human_help: Boolean(responsePacket.requires_human_help || classification.requires_human_help),
    actionType: responsePacket.actionType || classification.actionType || null,
    subType: classification.subType || null,
    engine: "ElderCare Local Intelligence Engine"
  };
}

/**
 * Handles Fall incidents with immediate reassurance and guided check.
 */
function handleFallResponse({ language = "en", userContext = {} }) {
  const userName = userContext.name || (language === "hi" ? "कमला जी" : "Kamla ji");
  const caregiverName = userContext.primaryCaregiver?.name || "Rahul";

  if (language === "hi") {
    return {
      text: `${userName}, घबराइए मत। गहरी और शांत सांस लीजिए। क्या आप अपने हाथ-पैर हिला पा रही हैं और सुरक्षित हैं? अगर कोई तेज़ दर्द हो तो बिल्कुल ज़ोर मत लगाइएगा। मैंने स्क्रीन पर सहायता विकल्प खोल दिए हैं।`,
      intent: "FALL_ASSISTANCE",
      severity: "HIGH",
      requires_human_help: true,
      actionType: "TRIGGER_FALL_MODAL"
    };
  }

  if (language === "hinglish") {
    return {
      text: `${userName}, ghabraiye mat. Deep breath lein. Kya aap apne hath-pair hila pa rahi hain? Agar tez dard ho toh bilkul zore mat lagaiye. Maine screen par fall assistance open kar diya hai.`,
      intent: "FALL_ASSISTANCE",
      severity: "HIGH",
      requires_human_help: true,
      actionType: "TRIGGER_FALL_MODAL"
    };
  }

  return {
    text: `${userName}, please stay calm and take slow, gentle breaths. Are you able to move your arms and legs comfortably? If you feel sharp pain, please stay still and allow me to alert ${caregiverName}. I have opened the Fall Assistance screen.`,
    intent: "FALL_ASSISTANCE",
    severity: "HIGH",
    requires_human_help: true,
    actionType: "TRIGGER_FALL_MODAL"
  };
}

/**
 * Helpful, graceful fallback for unknown or unmatched user queries.
 */
function createHelpfulFallback({ language = "en", userContext = {}, query = "" }) {
  const userName = userContext.name || (language === "hi" ? "कमला जी" : "Kamla ji");

  if (language === "hi") {
    return {
      text: `${userName}, मैं इसे पूरी तरह समझ नहीं पाई। आप मुझसे पूछ सकती हैं:\n• "मेरी आज की दवाइयाँ क्या हैं?" 💊\n• "मेरा अगला डॉक्टर अपॉइंटमेंट कब है?" 📅\n• "मुझे एक अच्छी कहानी सुनाओ" 📖\n• "मुझे चक्कर आ रहा है" 🩺\nया आपातकाल में 'मदद' बोलें।`,
      intent: "UNKNOWN",
      severity: "LOW",
      requires_human_help: false,
      actionType: "SHOW_GUIDED_SUGGESTIONS"
    };
  }

  if (language === "hinglish") {
    return {
      text: `${userName}, main theek se samajh nahi paayi. Aap mujhse yeh pooch sakti hain:\n• "Meri aaj ki kaunsi medicine hai?" 💊\n• "Doctor appointment kab hai?" 📅\n• "Mujhe ek kahani sunao" 📖\n• "Chakkar aa rahe hain" 🩺\nEmergency ke liye 'Help' ya SOS dabayein.`,
      intent: "UNKNOWN",
      severity: "LOW",
      requires_human_help: false,
      actionType: "SHOW_GUIDED_SUGGESTIONS"
    };
  }

  return {
    text: `I'm not sure I understood that, ${userName}. You can ask me:\n• "What medicines do I have today?" 💊\n• "When is my doctor appointment?" 📅\n• "Tell me a story" 📖\n• "What should I do for dizziness?" 🩺\nOr say "Help" anytime if you need immediate assistance.`,
    intent: "UNKNOWN",
    severity: "LOW",
    requires_human_help: false,
    actionType: "SHOW_GUIDED_SUGGESTIONS"
  };
}
