// Multi-Lingual Intent Classification Engine for ElderCare AI
// Supports English, Hindi (Devanagari), and Hinglish (Romanized Hindi)
// Deterministic, offline-first, keyword & regex-based matching with priority hierarchy

import { checkEmergency } from "./safetyGuardrails.js";

/**
 * Detect language of the input message: 'hi' (Devanagari Hindi), 'hinglish', or 'en'.
 * @param {string} text
 * @returns {string} 'hi' | 'hinglish' | 'en'
 */
export function detectLanguage(text = "") {
  if (/[\u0900-\u097F]/.test(text)) {
    return "hi";
  }

  const hinglishTokens = [
    /\b(aaj|meri|mera|mere|kaunsi|kaunsa|kab|kya|kyun|kahan|maine|liya|li|le|gaya|gayi|hoon|hai|hain|tha|thi|rahe|rahi|chakkar|dawa|dawai|tablet|batao|sunao|jaana|chahiye|karo|accha|theek|lag|raha|dard|paas|doctor|shukriya|dhanyawad|kripya|namaste|suprabhat|khao|pani|neend|khana|gir)\b/i
  ];

  for (const token of hinglishTokens) {
    if (token.test(text)) {
      return "hinglish";
    }
  }

  return "en";
}

// Intent Pattern Definitions
const PATTERNS = {
  FALL_ASSISTANCE: [
    /\b(i fell|i have fallen|fell down|had a fall|slip and fell|fallen down|dropped to floor|tripped and fell)\b/i,
    /\b(gir gaya|gir gayi|gir gaye|gir gaya hoon|gir gayi hoon|fisal gaya|fisal gayi|gira tha)\b/i,
    /(गिर गई|गिर गया|फिसल गई|फिसल गया|गिर पड़े|गिर गया हूँ|गिर गई हूँ)/
  ],

  MEDICINE_QUERY: [
    /\b(medicine|medicines|tablet|tablets|pill|pills|dosage|dawa|dawai|dawiyan|meds|dose|amlodipine|metformin|vitamin|calcium|prescriptions)\b/i,
    /\b(which medicine|what medicine|next medicine|morning medicine|evening medicine|night medicine|did i take|have i taken|take my pill)\b/i,
    /\b(kaunsi medicine|kaunsi dawai|agli dawai|morning wali|evening wali|raat wali|subah ki dawai|dawai li kya|medicine khayi)\b/i,
    /(दवाई|दवा|दवाइयाँ|गोली|खुराक|एम्लोडिपिन|मेटफॉर्मिन|विटामिन|कैल्शियम|सुबह की दवाई|रात की दवाई|दवाई लेनी|दवाई ली)/
  ],

  APPOINTMENT_QUERY: [
    /\b(appointment|appointments|doctor|dr\.|dr|clinic|hospital|checkup|consultation|visit doctor|specialist)\b/i,
    /\b(when is my appointment|who is my doctor|doctor visit|clinic visit|next checkup)\b/i,
    /\b(doctor ke paas|appointment kab|doctor kaun|clinic kab|aspatal kab|doctor se milna)\b/i,
    /(डॉक्टर|अपॉइंटमेंट|अस्पताल|क्लिनिक|जाँच|मुलाकात|डॉक्टर के पास)/
  ],

  HEALTH_BP: [
    /\b(blood pressure|high bp|low bp|hypertension|bp reading|bp check|what is bp)\b/i,
    /\b(high blood pressure|low blood pressure|bp kya hai|bp badh gaya)\b/i,
    /(रक्तचाप|ब्लड प्रेशर|बीपी|उच्च रक्तचाप)/
  ],

  HEALTH_DIZZINESS: [
    /\b(dizzy|dizziness|lightheaded|head spinning|feeling faint|room spinning|vertigo)\b/i,
    /\b(chakkar|chakkar aa rahe|sir ghoom raha|sir chakar)\b/i,
    /(चक्कर|सिर घूम|चक्कर आना|सिर चकरा)/
  ],

  HEALTH_HYDRATION: [
    /\b(hydration|drink water|glass of water|how much water|water intake|thirsty|dehydrated)\b/i,
    /\b(paani peena|pani peena|pani kitna|paani kitna)\b/i,
    /(पानी पीना|पानी कितना|जल|प्यासा|निर्जलीकरण)/
  ],

  HEALTH_SLEEP: [
    /\b(sleep|insomnia|cannot sleep|sleep well|sleep better|sleeping tips|restful sleep|tired)\b/i,
    /\b(neend nahi|achi neend|neend aane|sone ke tips|so nahi pa)\b/i,
    /(नींद|अनिद्रा|गहरी नींद|सो नहीं|अच्छी नींद)/
  ],

  HEALTH_FALL_PREVENTION: [
    /\b(fall prevention|prevent falls|prevent falling|balance exercise|home safety|slip prevention)\b/i,
    /\b(girne se kaise bache|balance kaise banaye|girne se bachav)\b/i,
    /(गिरने से बचाव|संतुलन|फिसलने से बचाव)/
  ],

  HEALTH_HEADACHE: [
    /\b(headache|head ache|head hurting|migraine|head pain)\b/i,
    /\b(sir dard|sar dard|sar me dard|sir me dard)\b/i,
    /(सिर दर्द|सर दर्द|माइग्रेन)/
  ],

  HEALTH_FEVER: [
    /\b(fever|temperature|feeling feverish|chills|high temperature)\b/i,
    /\b(bukhar|taap|garam shareer|bukhar lag raha)\b/i,
    /(बुखार|तापमान|ज्वर)/
  ],

  LONELINESS: [
    /\b(lonely|feeling lonely|alone|sad|nobody to talk|feeling low|depressed|isolated|need company|bored|talk to me)\b/i,
    /\b(akela|akeli|akelapan|udaas|mann udaas|bore ho raha|baat karne wala koi nahi|baat karo)\b/i,
    /(अकेला|अकेली|अकेलापन|उदास|मन उदास|मुझसे बात करो|कोई नहीं है)/
  ],

  STORY: [
    /\b(tell me a story|short story|inspiring story|bedtime story|read a story|tell a story)\b/i,
    /\b(kahani sunao|ek kahani|prernadayak kahani|story sunao)\b/i,
    /(कहानी|कहानी सुनाओ|प्रेरणादायक कहानी|कथा)/
  ],

  JOKE: [
    /\b(tell me a joke|funny joke|clean joke|make me laugh|tell a joke|humor)\b/i,
    /\b(chutkula sunao|joke sunao|hansi ka joke|hasao|koi joke)\b/i,
    /(चुटकुला|चुटकुला सुनाओ|मजाक|हँसी|जोक)/
  ],

  GREETING: [
    /\b(good morning|good afternoon|good evening|hello|hi|hey|how are you|how are you doing|namaste|suprabhat)\b/i,
    /\b(kaise ho|kaisi ho|kya haal hai|suprabhat|namaskar|pranam)\b/i,
    /(नमस्ते|सुप्रभात|शुभ दोपहर|शुभ संध्या|प्रणाम|कैसी हैं|कैसे हैं|नमस्कार)/
  ],

  GRATITUDE: [
    /\b(thank you|thanks|thank you so much|appreciate it|great help|good job)\b/i,
    /\b(dhanyawad|shukriya|bahut shukriya|dhanyavaad|accha laga)\b/i,
    /(धन्यवाद|शुक्रिया|बहुत शुक्रिया|आभार)/
  ]
};

/**
 * Classifies user message into structured intent and metadata.
 * @param {string} text - Raw user message
 * @param {string} forcedLanguage - Optional override language
 * @returns {object} Classification result packet
 */
export function classifyIntent(text = "", forcedLanguage = null) {
  const clean = text.trim();
  const lang = forcedLanguage || detectLanguage(clean);

  // 1. Critical Acute Emergency Check (Highest Priority)
  const emergencyCheck = checkEmergency(clean);
  if (emergencyCheck) {
    return {
      ...emergencyCheck,
      language: lang,
      matchedQuery: clean
    };
  }

  // 2. Fall Assistance Check
  for (const pattern of PATTERNS.FALL_ASSISTANCE) {
    if (pattern.test(clean)) {
      return {
        intent: "FALL_ASSISTANCE",
        subType: "FALL_INCIDENT",
        severity: "HIGH",
        requires_human_help: true,
        actionType: "TRIGGER_FALL_MODAL",
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 3. Medicine Inquiries
  for (const pattern of PATTERNS.MEDICINE_QUERY) {
    if (pattern.test(clean)) {
      return {
        intent: "MEDICINE_QUERY",
        subType: determineMedicineSubtype(clean),
        severity: "LOW",
        requires_human_help: false,
        actionType: "NAVIGATE_MEDICINES",
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 4. Appointment Inquiries
  for (const pattern of PATTERNS.APPOINTMENT_QUERY) {
    if (pattern.test(clean)) {
      return {
        intent: "APPOINTMENT_QUERY",
        subType: determineAppointmentSubtype(clean),
        severity: "LOW",
        requires_human_help: false,
        actionType: "NAVIGATE_APPOINTMENTS",
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 5. Health Knowledge Topics
  if (PATTERNS.HEALTH_BP.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "BP", severity: "LOW", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_DIZZINESS.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "DIZZINESS", severity: "MEDIUM", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_HYDRATION.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "HYDRATION", severity: "LOW", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_SLEEP.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "SLEEP", severity: "LOW", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_FALL_PREVENTION.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "FALL_PREVENTION", severity: "LOW", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_HEADACHE.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "HEADACHE", severity: "LOW", requires_human_help: false, language: lang };
  }
  if (PATTERNS.HEALTH_FEVER.some(p => p.test(clean))) {
    return { intent: "HEALTH_INFO", subTopic: "FEVER", severity: "MEDIUM", requires_human_help: false, language: lang };
  }

  // 6. Companionship & Emotional Support
  for (const pattern of PATTERNS.LONELINESS) {
    if (pattern.test(clean)) {
      return {
        intent: "COMPANIONSHIP",
        subType: "LONELINESS",
        severity: "LOW",
        requires_human_help: false,
        actionType: "COMPANION_SUPPORT",
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 7. Stories
  for (const pattern of PATTERNS.STORY) {
    if (pattern.test(clean)) {
      return {
        intent: "STORY",
        severity: "LOW",
        requires_human_help: false,
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 8. Jokes
  for (const pattern of PATTERNS.JOKE) {
    if (pattern.test(clean)) {
      return {
        intent: "JOKE",
        severity: "LOW",
        requires_human_help: false,
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 9. Greetings
  for (const pattern of PATTERNS.GREETING) {
    if (pattern.test(clean)) {
      return {
        intent: "GREETING",
        severity: "LOW",
        requires_human_help: false,
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 10. Gratitude
  for (const pattern of PATTERNS.GRATITUDE) {
    if (pattern.test(clean)) {
      return {
        intent: "GRATITUDE",
        severity: "LOW",
        requires_human_help: false,
        language: lang,
        matchedQuery: clean
      };
    }
  }

  // 11. Unknown / General Chat Fallback
  return {
    intent: "UNKNOWN",
    severity: "LOW",
    requires_human_help: false,
    actionType: "SHOW_GUIDED_SUGGESTIONS",
    language: lang,
    matchedQuery: clean
  };
}

/**
 * Determine sub-type of medicine query (morning, evening, next, specific med, etc.)
 */
function determineMedicineSubtype(text) {
  const t = text.toLowerCase();
  if (t.includes("next") || t.includes("agli") || t.includes("अगली")) return "NEXT";
  if (t.includes("morning") || t.includes("subah") || t.includes("सुबह") || t.includes("breakfast") || t.includes("nashta")) return "MORNING";
  if (t.includes("afternoon") || t.includes("dopahar") || t.includes("दोपहर") || t.includes("lunch")) return "AFTERNOON";
  if (t.includes("evening") || t.includes("shaam") || t.includes("शाम")) return "EVENING";
  if (t.includes("night") || t.includes("raat") || t.includes("रात") || t.includes("dinner") || t.includes("sone")) return "NIGHT";
  if (t.includes("status") || t.includes("li kya") || t.includes("take") || t.includes("taken") || t.includes("ली क्या")) return "STATUS";
  if (t.includes("amlodipine") || t.includes("एम्लोडिपिन")) return "AMLODIPINE";
  if (t.includes("metformin") || t.includes("मेटफॉर्मिन")) return "METFORMIN";
  if (t.includes("vitamin") || t.includes("विटामिन")) return "VITAMIN_D3";
  if (t.includes("calcium") || t.includes("कैल्शियम")) return "CALCIUM";
  return "ALL_TODAY";
}

/**
 * Determine sub-type of appointment query (when, doctor name, clinic, etc.)
 */
function determineAppointmentSubtype(text) {
  const t = text.toLowerCase();
  if (t.includes("who") || t.includes("kaun") || t.includes("कौन")) return "DOCTOR_INFO";
  if (t.includes("where") || t.includes("kahan") || t.includes("कहाँ") || t.includes("clinic") || t.includes("hospital")) return "LOCATION";
  if (t.includes("time") || t.includes("kab") || t.includes("when") || t.includes("कब") || t.includes("समय")) return "TIME";
  return "NEXT";
}
