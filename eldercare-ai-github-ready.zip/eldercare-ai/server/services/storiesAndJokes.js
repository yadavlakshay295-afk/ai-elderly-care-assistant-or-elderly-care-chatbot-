// Wholesome Stories, Clean Jokes, and Companionship Responses for Seniors
// Carefully curated for elderly emotional warmth, joy, and peace

const STORIES = {
  hi: [
    "एक गाँव में एक बुज़ुर्ग माली रोज़ सुबह नन्हें पौधे लगा रहे थे। किसी राहगीर ने पूछा, 'बाबा, इस पेड़ के फल तो आप शायद कभी नहीं चख पाएँगे, फिर इतनी मेहनत क्यों?' बुज़ुर्ग ने मुस्कुराकर कहा, 'बेटा, दूसरों के लगाए पेड़ों के मीठे फल मैंने खाए, तो आने वाली पीढ़ी के लिए छाया और फल छोड़ जाना मेरा भी कर्तव्य है।' अच्छाई का बीज कभी व्यर्थ नहीं जाता! 🌸",
    "एक राजा के राजमहल के बगीचे में एक नन्ही चिड़िया रोज़ सुबह मधुर स्वर में गाती थी। राजा ने पूछा, 'तुम इतनी छोटी होकर भी रोज़ इतनी प्रसन्न कैसे रहती हो?' चिड़िया ने उत्तर दिया, 'महाराज, मैं बीते कल का बोझ नहीं ढोती और आने वाले कल की चिंता में आज को नहीं खोती। बस आज की सुनहरी धूप का आनंद लेती हूँ।' हर नया दिन परमात्मा का अनमोल वरदान है।"
  ],
  hinglish: [
    "Ek gaon me ek pyare gardener roz naye paudhe lagate the. Ek traveller ne poocha, 'Aap in pedon ke fal shayad nahi dekh payenge, fir itni mehnat kyu?' Gardener ne smile karke kaha, 'Pehle logon ne ped lagaye jiske fal maine khaye, toh aane wali generation ke liye chhav aur fal chhodna mera farz hai.' Achhi soch hamesha khilti hai! 🌸",
    "Ek chhoti chirya roz subah meethi aawaz me gaati thi. Kisi ne poocha ki itni khush kaise rehti ho? Usne kaha, 'Main kal ki chinta me aaj ka din kharab nahi karti, bas aaj ki dhoop ka aanand leti hoon.' Har naya din ek gift hai."
  ],
  en: [
    "In a quiet countryside village, an elderly gardener was lovingly planting mango saplings. A passerby smiled and asked, 'Grandfather, why do you toil so hard when you might not live to taste these sweet fruits?' The wise man beamed and said, 'Others planted trees whose fruit I enjoyed all my life; I plant today so tomorrow's children will find cool shade and sweet fruit.' Every kind act blooms forever! 🌸",
    "A little sparrow sang joyfully on a temple branch every morning. When asked the secret of her endless happiness, she chirped, 'I do not carry the burdens of yesterday, nor do I fret about tomorrow. I simply rejoice in today's warm morning sunshine.' Every new dawn is a beautiful blessing."
  ]
};

const JOKES = {
  hi: [
    "पोता: 'दादी जी, क्या आप थोड़ी देर के लिए अपनी आँखें बंद कर सकती हैं?'\nदादी: 'क्यों बेटा?'\nपोता: 'क्योंकि पापा कह रहे थे कि दादी आँखें बंद करेंगी तो हमें नई कार मिलेगी!' 😄\nमुस्कुराते रहिए!",
    "मरीज़ डॉक्टर से: 'डॉक्टर साहब, क्या चश्मा लगाने के बाद मैं पढ़ सकूँगा?'\nडॉक्टर: 'हाँ, बिल्कुल!'\nमरीज़: 'वाह डॉक्टर साहब! आपने तो कमाल कर दिया, मुझे तो पहले पढ़ना आता ही नहीं था!' 😄"
  ],
  hinglish: [
    "Pota: 'Dadi ji, kya aap thodi der ke liye aankhein band kar sakti hain?'\nDadi: 'Kyu beta?'\nPota: 'Kyunki papa keh rahe the ki dadi aankh band karengi toh hum nayi car lenge!' 😄\nHamesha muskurate rahiye!",
    "Patient: 'Doctor saab, kya chashma lagane ke baad main padh paunga?'\nDoctor: 'Haan bilkul!'\nPatient: 'Arey wah, pehle toh mujhe padhna hi nahi aata tha!' 😄"
  ],
  en: [
    "Grandson: 'Grandma, what is the very best thing about turning 70?'\nGrandma: 'What is it, dear?'\nGrandson: 'Zero peer pressure!' 😄\nKeep that lovely smile on your face!",
    "Patient: 'Doctor, will I be able to play the piano after my thumb heals?'\nDoctor: 'Certainly, in two weeks!'\nPatient: 'Wonderful! I could never play a single note before!' 😄"
  ]
};

/**
 * Returns a warm, uplifting short story.
 */
export function getStory(language = "en") {
  const langKey = language === "hi" ? "hi" : language === "hinglish" ? "hinglish" : "en";
  const list = STORIES[langKey] || STORIES.en;
  const selected = list[Math.floor(Math.random() * list.length)];

  return {
    text: selected,
    intent: "STORY",
    severity: "LOW",
    requires_human_help: false
  };
}

/**
 * Returns a clean, heartwarming joke.
 */
export function getJoke(language = "en") {
  const langKey = language === "hi" ? "hi" : language === "hinglish" ? "hinglish" : "en";
  const list = JOKES[langKey] || JOKES.en;
  const selected = list[Math.floor(Math.random() * list.length)];

  return {
    text: selected,
    intent: "JOKE",
    severity: "LOW",
    requires_human_help: false
  };
}

/**
 * Generates an empathetic companionship response for loneliness or low mood.
 */
export function getCompanionshipResponse({ language = "en", userContext = {} } = {}) {
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";
  const userName = userContext.name || (isHindi ? "कमला जी" : "Kamla ji");
  const caregiverName = userContext.primaryCaregiver?.name || "Rahul";

  if (isHindi) {
    return {
      text: `${userName}, मैं हमेशा आपके साथ हूँ! आप कभी अकेली नहीं हैं। क्या आप एक प्रेरणादायक छोटी कहानी सुनना चाहेंगी, या एक हल्का-फुल्का चुटकुला सुनाऊँ? या मैं ${caregiverName} जी को आपका हालचाल पूछने का संदेश भेज दूँ? 🌸`,
      intent: "COMPANIONSHIP",
      severity: "LOW",
      requires_human_help: false,
      actionType: "COMPANION_SUPPORT"
    };
  }

  if (isHinglish) {
    return {
      text: `${userName}, main hamesha aapke saath hoon! Aap bilkul akeli nahi hain. Kya aap ek pyari kahani sunna chahengi, ya ek halka-fulka chutkula sunau? Ya main ${caregiverName} ji ko message kar doon? 🌸`,
      intent: "COMPANIONSHIP",
      severity: "LOW",
      requires_human_help: false,
      actionType: "COMPANION_SUPPORT"
    };
  }

  return {
    text: `${userName}, I am right here by your side! You are never alone. Would you like to hear an inspiring short story, a cheerful joke, or shall I let ${caregiverName} know you'd love a quick hello? 🌸`,
    intent: "COMPANIONSHIP",
    severity: "LOW",
    requires_human_help: false,
    actionType: "COMPANION_SUPPORT"
  };
}

/**
 * Generates warm greeting response.
 */
export function getGreetingResponse({ language = "en", userContext = {} } = {}) {
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";
  const userName = userContext.name || (isHindi ? "कमला जी" : "Kamla ji");

  if (isHindi) {
    return {
      text: `नमस्ते ${userName}! सुप्रभात 🌸 आशा है आपकी नींद अच्छी रही। क्या आपने एक गिलास गुनगुना पानी पिया? आज आपकी दवाई और दिनचर्या में मैं आपकी क्या मदद कर सकती हूँ?`,
      intent: "GREETING",
      severity: "LOW"
    };
  }

  if (isHinglish) {
    return {
      text: `Namaste ${userName}! Suprabhat 🌸 Asha hai aapki neend achi rahi. Kya aapne ek glass gunguna paani piya? Aaj main aapki kya madad kar sakti hoon?`,
      intent: "GREETING",
      severity: "LOW"
    };
  }

  return {
    text: `Good morning, ${userName}! 🌸 I hope you had a restful and peaceful sleep. Remember to drink a glass of fresh water. How can I assist your day today?`,
    intent: "GREETING",
    severity: "LOW"
  };
}

/**
 * Generates warm gratitude acknowledgement.
 */
export function getGratitudeResponse({ language = "en", userContext = {} } = {}) {
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";
  const userName = userContext.name || (isHindi ? "कमला जी" : "Kamla ji");

  if (isHindi) {
    return {
      text: `आपका बहुत-बहुत धन्यवाद, ${userName}! आपकी सेवा और मदद करना मेरे लिए खुशी की बात है। अपना ख्याल रखिए! 🌸`,
      intent: "GRATITUDE",
      severity: "LOW"
    };
  }

  if (isHinglish) {
    return {
      text: `Bahut shukriya, ${userName}! Aapki madad karke mujhe bohot khushi hoti hai. Apna khayal rakhein! 🌸`,
      intent: "GRATITUDE",
      severity: "LOW"
    };
  }

  return {
    text: `You are most welcome, ${userName}! It is my pleasure to be here for you. Take wonderful care of yourself! 🌸`,
    intent: "GRATITUDE",
    severity: "LOW"
  };
}
