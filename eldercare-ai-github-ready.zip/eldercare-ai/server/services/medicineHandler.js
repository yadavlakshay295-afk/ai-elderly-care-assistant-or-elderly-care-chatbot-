// Dynamic Medicine Information & Response Handler
// Generates accurate, empathetic responses strictly using local application data
// Never invents or fabricates medicine, dosage, or schedule data

/**
 * Handles medicine queries dynamically using provided userContext or local state.
 * @param {object} params
 * @param {string} params.message
 * @param {string} params.subType - 'ALL_TODAY', 'NEXT', 'MORNING', 'AFTERNOON', 'EVENING', 'NIGHT', 'STATUS', specific med
 * @param {string} params.language - 'en', 'hi', or 'hinglish'
 * @param {object} params.userContext - Contains todayMedicines array
 * @returns {object} Response packet
 */
export function handleMedicineQuery({ message, subType = "ALL_TODAY", language = "en", userContext = {} }) {
  const medicines = userContext.todayMedicines || [];
  const userName = userContext.name || (language === "hi" ? "कमला जी" : "Kamla ji");
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";

  if (!medicines || medicines.length === 0) {
    let emptyText = "";
    if (isHindi) {
      emptyText = `${userName}, आपकी आज की सूची में कोई भी दवाई दर्ज नहीं है। यदि आपकी कोई नई दवाई शुरू हुई है, तो कृपया देखभालकर्ता राहुल या डॉक्टर से संपर्क करें।`;
    } else if (isHinglish) {
      emptyText = `${userName}, aapki aaj ki list me koi medicine schedule nahi hai. Agar koi nayi dawa shuru hui hai toh please caregiver Rahul ya doctor se check karein.`;
    } else {
      emptyText = `${userName}, there are no medicines scheduled in your records for today. If a new medication was prescribed, please check with your caregiver or physician.`;
    }

    return {
      text: emptyText,
      intent: "MEDICINE_QUERY",
      severity: "LOW",
      requires_human_help: false,
      actionType: "NAVIGATE_MEDICINES"
    };
  }

  // 1. Next Medicine Query
  if (subType === "NEXT") {
    const pendingMeds = medicines.filter(m => (m.status || m.statusToday || "").toUpperCase() === "PENDING");
    if (pendingMeds.length === 0) {
      const allDoneText = isHindi
        ? `${userName}, शाबाश! आपने आज की अपनी सभी निर्धारित दवाइयाँ समय पर ले ली हैं। कोई भी दवाई बाकी नहीं है। 🌸`
        : isHinglish
        ? `${userName}, wonderful! Aapne aaj ki sabhi medicines time par le li hain. Koi bhi tablet pending nahi hai. 🌸`
        : `${userName}, wonderful! You have taken all your scheduled medicines for today. None are pending. 🌸`;

      return {
        text: allDoneText,
        intent: "MEDICINE_QUERY",
        severity: "LOW",
        actionType: "NAVIGATE_MEDICINES"
      };
    }

    const nextMed = pendingMeds[0];
    const medName = nextMed.name || "Medicine";
    const medTime = nextMed.time || nextMed.scheduledTime || "Scheduled time";

    let nextText = "";
    if (isHindi) {
      nextText = `${userName}, आपकी अगली दवाई **${medName}** है, जो **${medTime}** पर लेनी है। स्थिति: बाकी है 💊`;
    } else if (isHinglish) {
      nextText = `${userName}, aapki agli dawa **${medName}** hai, jise **${medTime}** par lena hai. Status: Pending 💊`;
    } else {
      nextText = `${userName}, your next medicine is **${medName}**, scheduled for **${medTime}**. Status: Pending 💊`;
    }

    return {
      text: nextText,
      intent: "MEDICINE_QUERY",
      severity: "LOW",
      actionType: "NAVIGATE_MEDICINES"
    };
  }

  // 2. Specific Slot Queries (Morning, Afternoon, Evening, Night)
  if (["MORNING", "AFTERNOON", "EVENING", "NIGHT"].includes(subType)) {
    const slotMeds = medicines.filter(m => {
      const t = `${m.name} ${m.timeSlot || ''} ${m.time || ''} ${m.scheduledTime || ''}`.toLowerCase();
      if (subType === "MORNING") return t.includes("morning") || t.includes("सुबह") || t.includes("08:") || t.includes("07:") || t.includes("09:");
      if (subType === "AFTERNOON") return t.includes("afternoon") || t.includes("दोपहर") || t.includes("01:") || t.includes("02:") || t.includes("12:") || t.includes("13:");
      if (subType === "EVENING") return t.includes("evening") || t.includes("शाम") || t.includes("05:") || t.includes("06:") || t.includes("07:") || t.includes("08:") || t.includes("20:");
      if (subType === "NIGHT") return t.includes("night") || t.includes("रात") || t.includes("09:") || t.includes("10:") || t.includes("21:") || t.includes("22:");
      return false;
    });

    if (slotMeds.length > 0) {
      let slotSummary = slotMeds.map(m => {
        const isTaken = (m.status || m.statusToday || "").toUpperCase() === "TAKEN";
        const statusLabel = isTaken 
          ? (isHindi ? "ली जा चुकी है ✅" : isHinglish ? "Li ja chuki hai ✅" : "Taken ✅")
          : (isHindi ? "बाकी है 💊" : isHinglish ? "Pending 💊" : "Pending 💊");
        return `• ${m.name} (${m.time || m.scheduledTime || 'Scheduled'}) — ${statusLabel}`;
      }).join("\n");

      let slotText = "";
      if (isHindi) {
        slotText = `${userName}, आपकी ${subType === "MORNING" ? "सुबह" : subType === "AFTERNOON" ? "दोपहर" : subType === "EVENING" ? "शाम" : "रात"} की दवाई का विवरण:\n${slotSummary}`;
      } else if (isHinglish) {
        slotText = `${userName}, aapki ${subType.toLowerCase()} medicine details:\n${slotSummary}`;
      } else {
        slotText = `${userName}, here are your ${subType.toLowerCase()} medicine details:\n${slotSummary}`;
      }

      return {
        text: slotText,
        intent: "MEDICINE_QUERY",
        severity: "LOW",
        actionType: "NAVIGATE_MEDICINES"
      };
    }
  }

  // 3. Specific Named Medicine Queries
  const specificNames = ["AMLODIPINE", "METFORMIN", "VITAMIN_D3", "CALCIUM"];
  if (specificNames.includes(subType)) {
    const targetKey = subType.toLowerCase().replace('_', '');
    const matchedMed = medicines.find(m => m.name.toLowerCase().includes(targetKey.slice(0, 5)));

    if (matchedMed) {
      const isTaken = (matchedMed.status || matchedMed.statusToday || "").toUpperCase() === "TAKEN";
      const statusLabel = isTaken 
        ? (isHindi ? "ली जा चुकी है ✅" : isHinglish ? "Li ja chuki hai ✅" : "Taken ✅")
        : (isHindi ? "बाकी है 💊" : isHinglish ? "Pending 💊" : "Pending 💊");

      let medDetail = "";
      if (isHindi) {
        medDetail = `${userName}, ${matchedMed.name} का समय: ${matchedMed.time || matchedMed.scheduledTime || 'निर्धारित समय'}\nस्थिति: ${statusLabel}`;
      } else if (isHinglish) {
        medDetail = `${userName}, ${matchedMed.name} timing: ${matchedMed.time || matchedMed.scheduledTime || 'Scheduled'}\nStatus: ${statusLabel}`;
      } else {
        medDetail = `${userName}, ${matchedMed.name} is scheduled at ${matchedMed.time || matchedMed.scheduledTime || 'Scheduled time'}\nStatus: ${statusLabel}`;
      }

      return {
        text: medDetail,
        intent: "MEDICINE_QUERY",
        severity: "LOW",
        actionType: "NAVIGATE_MEDICINES"
      };
    }
  }

  // 4. Default: Full Today's Medicine List
  const medListFormatted = medicines.map(m => {
    const isTaken = (m.status || m.statusToday || "").toUpperCase() === "TAKEN";
    const statusLabel = isTaken 
      ? (isHindi ? "ली जा चुकी है ✅" : isHinglish ? "Taken ✅" : "Taken ✅")
      : (isHindi ? "बाकी है 💊" : isHinglish ? "Pending 💊" : "Pending 💊");
    return `• ${m.time || m.scheduledTime || 'Time'}: ${m.name} — ${statusLabel}`;
  }).join("\n");

  let fullResponse = "";
  if (isHindi) {
    fullResponse = `${userName}, आपकी आज की दवाइयाँ:\n${medListFormatted}\n\nक्या आपने समय पर दवाई ले ली है?`;
  } else if (isHinglish) {
    fullResponse = `${userName}, aapka aaj ka medicine schedule:\n${medListFormatted}\n\nKya aapne samay par dawa le li hai?`;
  } else {
    fullResponse = `${userName}, here is your medicine schedule for today:\n${medListFormatted}\n\nWould you like me to update any medicine status?`;
  }

  return {
    text: fullResponse,
    intent: "MEDICINE_QUERY",
    severity: "LOW",
    requires_human_help: false,
    actionType: "NAVIGATE_MEDICINES"
  };
}
