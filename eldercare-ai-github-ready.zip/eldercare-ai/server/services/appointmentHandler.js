// Dynamic Appointment Information & Response Handler
// Uses dynamic local appointments data from userContext and local state
// Never fabricates or hallucinates appointment dates or doctor details

/**
 * Handles appointment inquiries dynamically.
 * @param {object} params
 * @param {string} params.message
 * @param {string} params.subType - 'NEXT', 'DOCTOR_INFO', 'LOCATION', 'TIME'
 * @param {string} params.language - 'en', 'hi', or 'hinglish'
 * @param {object} params.userContext - Contains appointments array
 * @returns {object} Response packet
 */
export function handleAppointmentQuery({ message, subType = "NEXT", language = "en", userContext = {} }) {
  const appointments = userContext.appointments || [];
  const userName = userContext.name || (language === "hi" ? "कमला जी" : "Kamla ji");
  const caregiverName = userContext.primaryCaregiver?.name || "Rahul";
  const isHindi = language === "hi";
  const isHinglish = language === "hinglish";

  if (!appointments || appointments.length === 0) {
    let emptyText = "";
    if (isHindi) {
      emptyText = `${userName}, इस समय आपके लिए कोई आगामी डॉक्टर अपॉइंटमेंट निर्धारित नहीं है। यदि नया अपॉइंटमेंट लेना है तो राहुल जी सहायता कर सकते हैं।`;
    } else if (isHinglish) {
      emptyText = `${userName}, currently aapka koi doctor appointment scheduled nahi hai. Agar naya checkup book karna ho toh Rahul ji madad kar sakte hain.`;
    } else {
      emptyText = `${userName}, you have no upcoming doctor appointments scheduled right now. Please let ${caregiverName} know if you need to arrange a visit.`;
    }

    return {
      text: emptyText,
      intent: "APPOINTMENT_QUERY",
      severity: "LOW",
      requires_human_help: false,
      actionType: "NAVIGATE_APPOINTMENTS"
    };
  }

  const nextApt = appointments[0];
  const doctorName = nextApt.doctor || nextApt.doctorName || "Dr. Arvind Sharma";
  const clinicName = nextApt.clinic || nextApt.clinicName || "City Heart Clinic";
  const aptDate = nextApt.displayDate || nextApt.date || "Tomorrow";
  const aptTime = nextApt.time || "10:30 AM";
  const purpose = nextApt.purpose || "Routine Health Checkup";

  // Subtype: Doctor Info
  if (subType === "DOCTOR_INFO") {
    let docText = "";
    if (isHindi) {
      docText = `${userName}, आपके डॉक्टर **${doctorName}** हैं। आपका अगला चेकअप **${aptDate}** को सुबह **${aptTime}** बजे **${clinicName}** में निर्धारित है।`;
    } else if (isHinglish) {
      docText = `${userName}, aapke doctor **${doctorName}** hain. Agla checkup **${aptDate}** ko **${aptTime}** baje **${clinicName}** par hai.`;
    } else {
      docText = `${userName}, your doctor is **${doctorName}**. Your next consultation is scheduled for **${aptDate}** at **${aptTime}** at **${clinicName}**.`;
    }

    return {
      text: docText,
      intent: "APPOINTMENT_QUERY",
      severity: "LOW",
      actionType: "NAVIGATE_APPOINTMENTS"
    };
  }

  // Subtype: Location / Clinic
  if (subType === "LOCATION") {
    let locText = "";
    if (isHindi) {
      locText = `${userName}, आपका अगला अपॉइंटमेंट **${clinicName}** में **${doctorName}** के साथ है। तारीख: **${aptDate}**, समय: **${aptTime}**।`;
    } else if (isHinglish) {
      locText = `${userName}, aapka next checkup **${clinicName}** me **${doctorName}** ke saath hai. Date: **${aptDate}**, Time: **${aptTime}**.`;
    } else {
      locText = `${userName}, your appointment will take place at **${clinicName}** with **${doctorName}** on **${aptDate}** at **${aptTime}**.`;
    }

    return {
      text: locText,
      intent: "APPOINTMENT_QUERY",
      severity: "LOW",
      actionType: "NAVIGATE_APPOINTMENTS"
    };
  }

  // General Next Appointment Detail
  let generalAptText = "";
  if (isHindi) {
    generalAptText = `${userName}, आपका अगला अपॉइंटमेंट:\n• डॉक्टर: ${doctorName}\n• क्लिनिक: ${clinicName}\n• तारीख: ${aptDate}\n• समय: ${aptTime}\n• जाँच: ${purpose}\n\nराहुल जी आपके साथ चलेंगे। अपनी बीपी डायरी साथ ले जाना न भूलें। 🌸`;
  } else if (isHinglish) {
    generalAptText = `${userName}, aapka agla doctor appointment:\n• Doctor: ${doctorName}\n• Clinic: ${clinicName}\n• Date: ${aptDate}\n• Time: ${aptTime}\n• Purpose: ${purpose}\n\nRahul aapke saath chalenge. Purani BP diary saath le jana na bhoolein. 🌸`;
  } else {
    generalAptText = `${userName}, your upcoming doctor appointment:\n• Doctor: ${doctorName}\n• Clinic: ${clinicName}\n• Date: ${aptDate}\n• Time: ${aptTime}\n• Purpose: ${purpose}\n\n${caregiverName} will accompany you. Remember to take your recent BP diary and reports. 🌸`;
  }

  return {
    text: generalAptText,
    intent: "APPOINTMENT_QUERY",
    severity: "LOW",
    requires_human_help: false,
    actionType: "NAVIGATE_APPOINTMENTS"
  };
}
