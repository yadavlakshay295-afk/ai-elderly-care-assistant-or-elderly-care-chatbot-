// Seed Data for ElderCare AI Demo
// Realistic sample profiles for Kamla Devi (Elderly) and Rahul (Caregiver)

export const seedElderlyProfile = {
  id: "elderly_kamla_001",
  name: "Kamla Devi",
  phone: "+91 98765 43210",
  age: 72,
  gender: "Female",
  preferredLanguage: "hi", // 'hi' or 'en'
  bloodGroup: "O+",
  emergencyNotes: "Known hypertension and mild Type-2 diabetes. Takes daily blood pressure medication.",
  address: "Flat 402, Shanti Niketan Apartments, Sector 14, Gurugram, Haryana",
  primaryCaregiver: {
    name: "Rahul Sharma",
    relation: "Son",
    phone: "+91 98765 00001",
    email: "rahul.care@example.com"
  },
  doctor: {
    name: "Dr. Arvind Sharma",
    specialty: "Cardiologist",
    clinic: "City Heart & Health Clinic",
    phone: "+91 98765 00002"
  }
};

export const seedMedicines = [
  {
    id: "med_001",
    userId: "elderly_kamla_001",
    name: "Amlodipine (एम्लोडिपिन)",
    purpose: "Blood Pressure / रक्तचाप",
    dosage: "5 mg",
    form: "1 tablet (गोली)",
    timeSlot: "Morning (सुबह)",
    scheduledTime: "08:00 AM",
    frequency: "Daily (रोज़ाना)",
    withFood: "After breakfast (नाश्ते के बाद)",
    startDate: "2025-01-01",
    endDate: "2026-12-31",
    statusToday: "TAKEN", // TAKEN, PENDING, SKIPPED
    takenAt: "08:15 AM",
    instructions: "Take with half glass of water. Do not skip.",
    color: "blue"
  },
  {
    id: "med_002",
    userId: "elderly_kamla_001",
    name: "Metformin (मेटफॉर्मिन)",
    purpose: "Sugar control / शुगर नियंत्रण",
    dosage: "500 mg",
    form: "1 tablet (गोली)",
    timeSlot: "Afternoon (दोपहर)",
    scheduledTime: "01:30 PM",
    frequency: "Daily (रोज़ाना)",
    withFood: "After lunch (दोपहर के खाने के बाद)",
    startDate: "2025-01-01",
    endDate: "2026-12-31",
    statusToday: "TAKEN",
    takenAt: "01:45 PM",
    instructions: "Take immediately after lunch.",
    color: "amber"
  },
  {
    id: "med_003",
    userId: "elderly_kamla_001",
    name: "Vitamin D3 (विटामिन डी3)",
    purpose: "Bones & Immunity / हड्डियों के लिए",
    dosage: "60,000 IU",
    form: "1 capsule (कैप्सूल)",
    timeSlot: "Evening (शाम)",
    scheduledTime: "08:00 PM",
    frequency: "Weekly (रविवार / Weekly)",
    withFood: "With warm milk (दूध के साथ)",
    startDate: "2025-01-01",
    endDate: "2026-12-31",
    statusToday: "PENDING",
    instructions: "Take once weekly with warm milk after dinner.",
    color: "emerald"
  },
  {
    id: "med_004",
    userId: "elderly_kamla_001",
    name: "Calcium + Zinc (कैल्शियम)",
    purpose: "Bone Strength / हड्डियों की मजबूती",
    dosage: "500 mg",
    form: "1 tablet (गोली)",
    timeSlot: "Night (रात)",
    scheduledTime: "09:30 PM",
    frequency: "Daily (रोज़ाना)",
    withFood: "Before sleep (सोने से पहले)",
    startDate: "2025-01-01",
    endDate: "2026-12-31",
    statusToday: "PENDING",
    instructions: "Take at bedtime.",
    color: "purple"
  }
];

export const seedAppointments = [
  {
    id: "apt_001",
    userId: "elderly_kamla_001",
    doctorName: "Dr. Arvind Sharma",
    specialty: "Cardiologist (हृदय रोग विशेषज्ञ)",
    clinicName: "City Heart & Wellness Center",
    address: "Room 204, Sector 14, Gurugram",
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    displayDate: "Tomorrow (कल)",
    time: "10:30 AM",
    purpose: "Routine Blood Pressure & Heart Checkup",
    notes: "Please carry previous ECG reports and 7-day BP tracking diary.",
    reminderSent: true,
    status: "CONFIRMED"
  },
  {
    id: "apt_002",
    userId: "elderly_kamla_001",
    doctorName: "Dr. Priya Verma",
    specialty: "Ophthalmologist / Eye Specialist (नेत्र रोग विशेषज्ञ)",
    clinicName: "Apex Eye Care Hospital",
    address: "Plot 12, Main Road, Gurugram",
    date: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0], // 5 days later
    displayDate: "Next Tuesday (अगले मंगलवार)",
    time: "04:00 PM",
    purpose: "Annual vision and cataract progression checkup",
    notes: "Eye drops will be administered; accompany with Rahul.",
    reminderSent: false,
    status: "UPCOMING"
  }
];

export const seedWellnessCheckins = [
  {
    id: "well_001",
    userId: "elderly_kamla_001",
    date: new Date().toISOString().split('T')[0], // Today
    time: "09:00 AM",
    mood: "good", // good, okay, not_great, worried, low
    moodEmoji: "😊",
    moodLabel: "Feeling Good / अच्छा लग रहा है",
    sleepHours: 7.5,
    sleepQuality: "Restful (गहरी नींद)",
    waterGlasses: 6,
    mealsTaken: { breakfast: true, lunch: true, dinner: false },
    painLevel: 2, // 0-10
    painArea: "Mild knee stiffness (घुटनों में हल्का दर्द)",
    notes: "Went for a gentle morning balcony stroll. Spoke to granddaughter."
  },
  {
    id: "well_002",
    userId: "elderly_kamla_001",
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0], // Yesterday
    time: "09:15 AM",
    mood: "okay",
    moodEmoji: "🙂",
    moodLabel: "Okay / ठीक-ठाक",
    sleepHours: 6,
    sleepQuality: "Moderate",
    waterGlasses: 5,
    mealsTaken: { breakfast: true, lunch: true, dinner: true },
    painLevel: 3,
    painArea: "Lower back",
    notes: "Felt a bit tired in the afternoon."
  }
];

export const seedEmergencyContacts = [
  {
    id: "cont_001",
    name: "Rahul Sharma (Son / बेटा)",
    relation: "Primary Caregiver",
    phone: "+91 98765 00001",
    isPrimary: true,
    avatar: "👨"
  },
  {
    id: "cont_002",
    name: "Dr. Arvind Sharma (Doctor)",
    relation: "Personal Cardiologist",
    phone: "+91 98765 00002",
    isPrimary: false,
    avatar: "🩺"
  },
  {
    id: "cont_003",
    name: "National Emergency Helpline",
    relation: "All Emergencies",
    phone: "112",
    isPrimary: false,
    avatar: "🚨"
  },
  {
    id: "cont_004",
    name: "Ambulance / एम्बुलेंस",
    relation: "Medical Emergency",
    phone: "108",
    isPrimary: false,
    avatar: "🚑"
  }
];

export const seedEmergencyEvents = [
  {
    id: "sos_demo_01",
    userId: "elderly_kamla_001",
    timestamp: new Date(Date.now() - 3 * 86400000).toISOString(),
    type: "TEST_SOS",
    status: "RESOLVED",
    triggeredBy: "Kamla Devi",
    location: "Home (Sector 14, Gurugram)",
    resolvedBy: "Rahul Sharma",
    resolutionNotes: "Demo test verification completed successfully."
  }
];
