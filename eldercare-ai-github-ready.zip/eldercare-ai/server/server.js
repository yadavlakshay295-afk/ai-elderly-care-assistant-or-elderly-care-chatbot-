import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import aiRoutes from "./routes/ai.js";
import medicineRoutes from "./routes/medicines.js";
import appointmentRoutes from "./routes/appointments.js";
import wellnessRoutes from "./routes/wellness.js";
import emergencyRoutes from "./routes/emergency.js";
import { seedElderlyProfile } from "./data/seedData.js";

// Load optional environment variables from .env if present
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// API Health Check
app.get("/api/health", (req, res) => {
  res.json({
    status: "healthy",
    service: "ElderCare AI Backend",
    timestamp: new Date().toISOString(),
    aiEngine: "Local Intelligence Engine (API-Free)",
    mode: "Fully Offline Local Intelligence Engine"
  });
});

// Profile route
app.get("/api/profile", (req, res) => {
  res.json({
    success: true,
    data: seedElderlyProfile
  });
});

// Route registration
app.use("/api/ai", aiRoutes);
app.use("/api/medicines", medicineRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/wellness", wellnessRoutes);
app.use("/api/emergency", emergencyRoutes);

// Error Handling Middleware
app.use((err, req, res, next) => {
  console.error("Unhandled Server Error:", err);
  res.status(500).json({
    success: false,
    error: "Internal Server Error occurred. Please try again."
  });
});

// Start Server
app.listen(PORT, () => {
  console.log("==================================================");
  console.log(`🌸 ElderCare AI Server is running on port ${PORT}`);
  console.log(`📍 API Health: http://localhost:${PORT}/api/health`);
  console.log(`🤖 AI Engine: Local Intelligence Engine (100% API-Free & Offline Ready)`);
  console.log("==================================================");
});
