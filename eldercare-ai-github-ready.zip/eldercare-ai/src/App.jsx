import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext.jsx';
import { LanguageProvider } from './contexts/LanguageContext.jsx';
import { VoiceProvider } from './contexts/VoiceContext.jsx';
import { HealthDataProvider } from './contexts/HealthDataContext.jsx';

import Navbar from './components/layout/Navbar.jsx';
import Footer from './components/layout/Footer.jsx';
import SOSModal from './components/emergency/SOSModal.jsx';
import FallAssistanceModal from './components/emergency/FallAssistanceModal.jsx';

import ElderlyHome from './pages/ElderlyHome.jsx';
import AIChatPage from './pages/AIChatPage.jsx';
import MedicinesPage from './pages/MedicinesPage.jsx';
import AppointmentsPage from './pages/AppointmentsPage.jsx';
import WellnessPage from './pages/WellnessPage.jsx';
import SOSPage from './pages/SOSPage.jsx';
import CaregiverDashboard from './pages/CaregiverDashboard.jsx';
import SettingsPage from './pages/SettingsPage.jsx';
import ProfilePage from './pages/ProfilePage.jsx';

const AppContent = () => {
  const { currentRole } = useAuth();
  const [activeTab, setActiveTab] = useState('home');

  const renderActivePage = () => {
    // If caregiver role is chosen and tab was home, default to caregiver view
    if (currentRole === 'caregiver' && activeTab === 'home') {
      return <CaregiverDashboard onNavigate={setActiveTab} />;
    }

    switch (activeTab) {
      case 'home':
        return <ElderlyHome onNavigate={setActiveTab} />;
      case 'chat':
        return <AIChatPage onNavigate={setActiveTab} />;
      case 'medicines':
        return <MedicinesPage />;
      case 'appointments':
        return <AppointmentsPage onNavigate={setActiveTab} />;
      case 'wellness':
        return <WellnessPage />;
      case 'sos':
        return <SOSPage />;
      case 'caregiver':
        return <CaregiverDashboard onNavigate={setActiveTab} />;
      case 'settings':
        return <SettingsPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <ElderlyHome onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col glass-mesh-bg text-slate-900 selection:bg-amber-200">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        {renderActivePage()}
      </main>

      <Footer activeTab={activeTab} onTabChange={setActiveTab} />
      
      {/* Global Modals */}
      <SOSModal />
      <FallAssistanceModal />
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <VoiceProvider>
          <HealthDataProvider>
            <AppContent />
          </HealthDataProvider>
        </VoiceProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;
