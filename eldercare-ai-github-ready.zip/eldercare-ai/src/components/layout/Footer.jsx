import React from 'react';
import { Home, MessageSquare, Pill, Calendar, Heart, ShieldAlert, LayoutDashboard, User } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext.jsx';
import { useAuth } from '../../contexts/AuthContext.jsx';

export const Footer = ({ activeTab, onTabChange }) => {
  const { t, language } = useLanguage();
  const { currentRole } = useAuth();

  const navItems = currentRole === 'caregiver' ? [
    { id: 'caregiver',     label: t("nav.caregiver", "Panel"),      icon: LayoutDashboard, color: 'text-emerald-700' },
    { id: 'medicines',     label: t("nav.medicines", "Medicines"),   icon: Pill,            color: 'text-blue-700' },
    { id: 'appointments',  label: t("nav.appointments", "Doctor"),   icon: Calendar,        color: 'text-purple-700' },
    { id: 'wellness',      label: t("nav.wellness", "Wellness"),     icon: Heart,           color: 'text-rose-600' },
    { id: 'chat',          label: t("nav.chat", "AI"),               icon: MessageSquare,   color: 'text-amber-600' },
    { id: 'profile',       label: language === 'hi' ? 'प्रोफ़ाइल' : 'Profile', icon: User, color: 'text-slate-700' },
  ] : [
    { id: 'home',         label: t("nav.home", "Home"),             icon: Home,            color: 'text-blue-700' },
    { id: 'chat',         label: t("nav.chat", "AI Helper"),        icon: MessageSquare,   color: 'text-amber-600' },
    { id: 'medicines',    label: t("nav.medicines", "Medicines"),   icon: Pill,            color: 'text-teal-700' },
    { id: 'appointments', label: t("nav.appointments", "Doctor"),   icon: Calendar,        color: 'text-purple-700' },
    { id: 'wellness',     label: t("nav.wellness", "How I Feel"),   icon: Heart,           color: 'text-rose-600' },
    { id: 'sos',          label: t("nav.emergency", "SOS"),         icon: ShieldAlert,     color: 'text-red-600', isSOS: true },
    { id: 'profile',      label: language === 'hi' ? 'प्रोफ़ाइल' : 'Profile', icon: User, color: 'text-slate-700' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 glass-footer pb-safe">
      <div className="max-w-5xl mx-auto px-1.5 py-2.5 flex items-center justify-around overflow-x-auto no-scrollbar gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-2.5 sm:px-3.5 rounded-2xl transition-all select-none min-w-[54px] sm:min-w-[70px] min-h-[58px] flex-shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white font-extrabold shadow-md shadow-blue-500/25 scale-105'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60 font-semibold'
              } ${item.isSOS ? 'bg-red-500/10 text-red-700 border border-red-300/80 hover:bg-red-500/20' : ''}`}
            >
              <Icon className={`w-6 h-6 sm:w-7 sm:h-7 stroke-[2.2] ${isActive ? 'text-white' : item.color}`} />
              <span className={`text-[10px] sm:text-xs tracking-tight mt-0.5 whitespace-nowrap leading-tight text-center ${isActive ? 'text-white' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default Footer;
