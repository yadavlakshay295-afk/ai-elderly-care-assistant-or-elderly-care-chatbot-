import React from 'react';
import { ShieldAlert, Globe, UserCheck, Users, Volume2, Type, Sparkles } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useLanguage } from '../../contexts/LanguageContext.jsx';
import { useHealthData } from '../../contexts/HealthDataContext.jsx';

export const Navbar = () => {
  const { currentRole, switchRole, fontSizeScale, setFontSizeScale, isDemoMode, elderlyUser } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();
  const { setActiveSOSModal, triggerSOS } = useHealthData();

  const handleFontIncrease = () => {
    setFontSizeScale(prev => Math.min(1.4, prev + 0.1));
  };

  const handleFontDecrease = () => {
    setFontSizeScale(prev => Math.max(0.9, prev - 0.1));
  };

  return (
    <header className="sticky top-0 z-40 glass-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-700 text-white rounded-2xl flex items-center justify-center text-2xl font-bold shadow-md">
              👵
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl font-extrabold text-blue-900 tracking-tight">
                  ElderCare AI
                </span>
                {isDemoMode && (
                  <span className="hidden sm:inline-block px-2.5 py-0.5 text-xs font-black bg-amber-100 text-amber-900 rounded-full border border-amber-300">
                    DEMO
                  </span>
                )}
              </div>
              <p className="hidden md:block text-xs font-semibold text-slate-500">
                {language === 'hi' ? 'बुजुर्गों की देखभाल एवं सुरक्षा साथी' : 'Your caring digital companion'}
              </p>
            </div>
          </div>

          {/* Controls: Role Switch, Language, Font Scaler, SOS Pill */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Font Scaling Buttons */}
            <div className="hidden sm:flex items-center bg-white/70 backdrop-blur-md rounded-2xl p-1 border border-white/80 shadow-sm">
              <button
                onClick={handleFontDecrease}
                className="px-2.5 py-1 text-base font-bold text-slate-700 hover:bg-white rounded-xl transition-colors"
                title="Decrease font size"
              >
                A-
              </button>
              <button
                onClick={handleFontIncrease}
                className="px-2.5 py-1 text-lg font-extrabold text-slate-900 hover:bg-white rounded-xl transition-colors"
                title="Increase font size"
              >
                A+
              </button>
            </div>

            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="min-h-[46px] px-3.5 py-2 bg-white/75 hover:bg-white active:scale-95 text-slate-900 rounded-2xl font-bold text-base flex items-center gap-2 border border-white/90 shadow-sm backdrop-blur-md transition-all"
              title="Toggle English / Hindi"
            >
              <Globe className="w-5 h-5 text-blue-700" />
              <span>{language === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Role Switcher Button */}
            <button
              onClick={() => switchRole(currentRole === 'elderly' ? 'caregiver' : 'elderly')}
              className={`min-h-[46px] px-3.5 py-2 rounded-2xl font-bold text-base flex items-center gap-2 border shadow-sm backdrop-blur-md transition-all ${
                currentRole === 'elderly'
                  ? 'bg-blue-50/80 text-blue-900 border-blue-200 hover:bg-blue-100/90'
                  : 'bg-emerald-50/80 text-emerald-900 border-emerald-200 hover:bg-emerald-100/90'
              }`}
            >
              {currentRole === 'elderly' ? (
                <>
                  <UserCheck className="w-5 h-5 text-blue-700" />
                  <span className="hidden sm:inline">Elder: Kamla ji</span>
                  <span className="sm:hidden">Elderly</span>
                </>
              ) : (
                <>
                  <Users className="w-5 h-5 text-emerald-700" />
                  <span className="hidden sm:inline">Caregiver: Rahul</span>
                  <span className="sm:hidden">Caregiver</span>
                </>
              )}
            </button>

            {/* Quick SOS Red Button */}
            <button
              onClick={() => {
                triggerSOS({
                  type: "NAVBAR_QUICK_SOS",
                  location: elderlyUser?.address ? `${elderlyUser.address} (28.4595° N, 77.0266° E)` : "Sector 14, Gurugram (28.4595° N, 77.0266° E)",
                  notes: "Elderly pressed Quick SOS button in Navbar."
                });
              }}
              className="min-h-[48px] px-4 py-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-xl font-extrabold text-lg flex items-center gap-2 shadow-md border-2 border-red-700 sos-pulse-btn transition-all"
              aria-label="Emergency SOS"
            >
              <ShieldAlert className="w-6 h-6 stroke-[2.5]" />
              <span className="tracking-wide">SOS</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
