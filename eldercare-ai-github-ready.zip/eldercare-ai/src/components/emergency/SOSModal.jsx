import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, 
  MapPin, 
  AlertTriangle, 
  ShieldCheck, 
  X, 
  Check, 
  Volume2, 
  Send, 
  CheckCircle2, 
  Radio, 
  PhoneCall, 
  MessageSquare,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { useHealthData } from '../../contexts/HealthDataContext.jsx';
import { useLanguage } from '../../contexts/LanguageContext.jsx';
import { useVoice } from '../../contexts/VoiceContext.jsx';
import { useAuth } from '../../contexts/AuthContext.jsx';

export const SOSModal = () => {
  const { activeSOSModal, setActiveSOSModal, contacts } = useHealthData();
  const { elderlyUser, caregiver } = useAuth();
  const { language, t } = useLanguage();
  const { speak } = useVoice();
  const [copied, setCopied] = useState(false);

  // Dynamic targets based on live profile & contacts
  const sonPhone = caregiver?.phone || "+91 98765 00001";
  const sonName = caregiver?.name || "Rahul";
  const policePhone = "112";
  const ambulancePhone = "108";

  const sampleLocation = "https://maps.google.com/?q=28.4595,77.0266";
  const locationText = elderlyUser?.address 
    ? `${elderlyUser.address} (28.4595° N, 77.0266° E)`
    : "Sector 14, Gurugram (28.4595° N, 77.0266° E)";

  const smsMessage = `🚨 EMERGENCY ALERT: ${elderlyUser?.name || 'Kamla Devi'} needs urgent assistance! Location: ${locationText} Maps link: ${sampleLocation}`;

  // Call sequence state:
  // Step 0: Initialized
  // Step 1: Calling Son (Caregiver)
  // Step 2: Calling Police (112)
  // Step 3: Calling Ambulance (108)
  // Step 4: Sequence Completed / Monitoring
  const [callStep, setCallStep] = useState(1);
  const [countdown, setCountdown] = useState(4);
  const [isSequencePaused, setIsSequencePaused] = useState(false);
  const [smsStatus, setSmsStatus] = useState({
    son: "sent",
    police: "sent",
    ambulance: "sent"
  });

  const timerRef = useRef(null);

  // Play voice instructions and trigger calling whenever modal opens
  useEffect(() => {
    if (activeSOSModal) {
      setCallStep(1);
      setCountdown(4);
      setIsSequencePaused(false);
      setSmsStatus({ son: "sent", police: "sent", ambulance: "sent" });

      const text = language === 'hi'
        ? `आपातकालीन सायरन चालू है! आपकी जीपीएस लोकेशन तीनों नंबरों पर एसएमएस कर दी गई है। सबसे पहले राहुल जी को कॉल किया जा रहा है, उसके बाद पुलिस 112 और फिर एम्बुलेंस 108 को कॉल लगेगी।`
        : `Emergency SOS initiated! Your live GPS location has been sent via SMS to all three responders. Now calling son Rahul, followed by Police 112, and then Ambulance 108.`;
      speak(text);

      // Trigger first call attempt
      attemptDial(sonPhone);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [activeSOSModal]);

  // Sequential Call Dispatch Timer
  useEffect(() => {
    if (!activeSOSModal || isSequencePaused) return;

    if (callStep >= 1 && callStep <= 3) {
      timerRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            // Advance to next call target in the sequence
            setCallStep((currStep) => {
              const nextStep = currStep + 1;
              if (nextStep === 2) {
                attemptDial(policePhone);
                const announce = language === 'hi' 
                  ? "अब पुलिस 112 को कॉल किया जा रहा है।" 
                  : "Now connecting to National Police 112.";
                speak(announce);
              } else if (nextStep === 3) {
                attemptDial(ambulancePhone);
                const announce = language === 'hi' 
                  ? "अब एम्बुलेंस 108 को कॉल किया जा रहा है।" 
                  : "Now connecting to Ambulance 108.";
                speak(announce);
              } else if (nextStep === 4) {
                const announce = language === 'hi'
                  ? "सभी तीनों आपातकालीन सेवाओं को कॉल और एसएमएस भेज दिया गया है।"
                  : "All three emergency channels have been dialed and SMS delivered.";
                speak(announce);
              }
              return nextStep;
            });
            return 4; // Reset countdown for next step
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeSOSModal, callStep, isSequencePaused]);

  const attemptDial = (number) => {
    try {
      window.location.href = `tel:${number.replace(/\s+/g, '')}`;
    } catch (err) {
      console.warn("Direct dial intent:", err);
    }
  };

  const handleManualDial = (number, stepIndex) => {
    setCallStep(stepIndex);
    attemptDial(number);
  };

  const handleCopyLocation = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`Emergency Location: ${locationText} - ${sampleLocation}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleSendManualSms = (phone) => {
    const cleanPhone = phone.replace(/\s+/g, '');
    window.location.href = `sms:${cleanPhone}?body=${encodeURIComponent(smsMessage)}`;
  };

  const restartSequence = () => {
    setCallStep(1);
    setCountdown(4);
    setIsSequencePaused(false);
    attemptDial(sonPhone);
  };

  if (!activeSOSModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border-4 border-red-600 overflow-hidden my-4 relative">
        
        {/* Urgent Pulsing Emergency Header */}
        <div className="bg-red-600 text-white p-5 sm:p-6 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-red-700 opacity-20 animate-ping pointer-events-none" />
          
          <button
            onClick={() => setActiveSOSModal(false)}
            className="absolute top-4 right-4 p-2 bg-red-900/80 hover:bg-red-950 rounded-full text-white transition-colors z-10"
            aria-label="Close emergency modal"
          >
            <X className="w-7 h-7 sm:w-8 sm:h-8" />
          </button>
          
          <div className="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-white text-red-600 rounded-full shadow-xl mb-2 sm:mb-3 animate-bounce">
            <AlertTriangle className="w-10 h-10 sm:w-12 sm:h-12 stroke-[2.5]" />
          </div>

          <h2 className="text-2xl sm:text-4xl font-black tracking-tight uppercase">
            {language === 'hi' ? '🚨 आपातकालीन SOS सक्रिय' : '🚨 EMERGENCY SOS ACTIVE'}
          </h2>
          <p className="text-lg sm:text-2xl font-bold mt-1 text-red-100">
            {language === 'hi'
              ? 'तीनों को कॉल और लोकेशन SMS भेजा जा रहा है'
              : 'Direct calling & Live GPS SMS to all 3 responders'}
          </p>

          {/* Audio repeat pill */}
          <button
            onClick={() => {
              const text = language === 'hi'
                ? `घबराइए मत कमला जी। राहुल जी, पुलिस 112 और एम्बुलेंस 108 को कॉल और लोकेशन एसएमएस भेजा जा रहा है।`
                : `Stay calm. Calling Son, Police 112, and Ambulance 108 with your live GPS location.`;
              speak(text);
            }}
            className="mt-3 inline-flex items-center gap-2 px-4 py-1.5 bg-red-800 hover:bg-red-900 rounded-full text-base font-extrabold border border-red-400 text-white shadow"
          >
            <Volume2 className="w-5 h-5" />
            <span>{language === 'hi' ? 'आवाज़ में सुनें' : 'Listen Status'}</span>
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="p-5 sm:p-7 space-y-6">

          {/* SIMULTANEOUS LOCATION SMS STATUS BANNER */}
          <div className="bg-emerald-50 border-2 border-emerald-400 rounded-2xl p-4 sm:p-5 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 shadow">
                <Send className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg sm:text-xl font-black text-emerald-950 flex items-center gap-2">
                    <span>{language === 'hi' ? 'लोकेशन SMS तीनों को भेजा गया ✅' : 'Live Location SMS Sent to All 3 ✅'}</span>
                  </h3>
                  <span className="px-2.5 py-0.5 bg-emerald-200 text-emerald-900 font-extrabold text-xs rounded-full uppercase">
                    Simultaneous
                  </span>
                </div>
                <p className="text-sm sm:text-base font-semibold text-emerald-900 mt-1">
                  📍 {locationText}
                </p>

                {/* 3 SMS target badges */}
                <div className="flex flex-wrap gap-2 mt-2 pt-2 border-t border-emerald-200">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white text-emerald-800 rounded-lg text-xs font-bold border border-emerald-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>1. Son ({sonName})</span>
                  </span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white text-emerald-800 rounded-lg text-xs font-bold border border-emerald-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>2. Police (112)</span>
                  </span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white text-emerald-800 rounded-lg text-xs font-bold border border-emerald-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>3. Ambulance (108)</span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* SEQUENTIAL CALL DISPATCH ENGINE (1st Son -> 2nd Police -> 3rd Ambulance) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
                <PhoneCall className="w-6 h-6 text-red-600" />
                <span>{language === 'hi' ? 'कॉल क्रम (Son ➔ Police ➔ Ambulance)' : 'Sequential Call Dispatch'}</span>
              </h3>
              {callStep <= 3 && !isSequencePaused && (
                <span className="px-3 py-1 bg-amber-100 text-amber-900 font-black text-sm rounded-full animate-pulse border border-amber-300">
                  Next in {countdown}s
                </span>
              )}
            </div>

            {/* TARGET 1: SON (CAREGIVER) */}
            <div
              className={`p-4 rounded-2xl border-3 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                callStep === 1
                  ? 'bg-red-50 border-red-600 ring-4 ring-red-200 shadow-lg'
                  : callStep > 1
                  ? 'bg-slate-50 border-emerald-500 opacity-90'
                  : 'bg-white border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black shadow-md ${
                  callStep === 1 ? 'bg-red-600 text-white animate-pulse' : 'bg-white text-slate-900 border'
                }`}>
                  1
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black text-slate-900">
                      {language === 'hi' ? `1. राहुल (${sonName} - बेटा)` : `1. Son (${sonName})`}
                    </span>
                    {callStep === 1 && (
                      <span className="px-2.5 py-0.5 bg-red-600 text-white text-xs font-black rounded-full animate-ping">
                        CALLING NOW
                      </span>
                    )}
                    {callStep > 1 && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-extrabold rounded-full">
                        DIALED ✓
                      </span>
                    )}
                  </div>
                  <div className="text-base text-slate-600 font-bold">{sonPhone} (Primary Caregiver)</div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => handleManualDial(sonPhone, 1)}
                  className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl shadow flex items-center gap-2 text-base active:scale-95"
                >
                  <Phone className="w-5 h-5" />
                  <span>Call Now</span>
                </button>
                <button
                  onClick={() => handleSendManualSms(sonPhone)}
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300"
                  title="Open SMS App"
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* TARGET 2: POLICE (112) */}
            <div
              className={`p-4 rounded-2xl border-3 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                callStep === 2
                  ? 'bg-blue-50 border-blue-600 ring-4 ring-blue-200 shadow-lg'
                  : callStep > 2
                  ? 'bg-slate-50 border-emerald-500 opacity-90'
                  : 'bg-white border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black shadow-md ${
                  callStep === 2 ? 'bg-blue-700 text-white animate-pulse' : 'bg-white text-slate-900 border'
                }`}>
                  2
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black text-slate-900">
                      {language === 'hi' ? '2. पुलिस (Police Helpline)' : '2. National Police'}
                    </span>
                    {callStep === 2 && (
                      <span className="px-2.5 py-0.5 bg-blue-700 text-white text-xs font-black rounded-full animate-ping">
                        CALLING NOW
                      </span>
                    )}
                    {callStep > 2 && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-extrabold rounded-full">
                        DIALED ✓
                      </span>
                    )}
                  </div>
                  <div className="text-base text-slate-600 font-bold">112 (All-India Emergency Police & Rescue)</div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => handleManualDial(policePhone, 2)}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl shadow flex items-center gap-2 text-base active:scale-95"
                >
                  <Phone className="w-5 h-5" />
                  <span>Call 112</span>
                </button>
                <button
                  onClick={() => handleSendManualSms(policePhone)}
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300"
                  title="Open SMS App"
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* TARGET 3: AMBULANCE (108) */}
            <div
              className={`p-4 rounded-2xl border-3 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                callStep === 3
                  ? 'bg-emerald-50 border-emerald-600 ring-4 ring-emerald-200 shadow-lg'
                  : callStep > 3
                  ? 'bg-emerald-50 border-emerald-500'
                  : 'bg-white border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black shadow-md ${
                  callStep === 3 ? 'bg-emerald-700 text-white animate-pulse' : 'bg-white text-slate-900 border'
                }`}>
                  3
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black text-slate-900">
                      {language === 'hi' ? '3. एम्बुलेंस (Ambulance)' : '3. Medical Ambulance'}
                    </span>
                    {callStep === 3 && (
                      <span className="px-2.5 py-0.5 bg-emerald-700 text-white text-xs font-black rounded-full animate-ping">
                        CALLING NOW
                      </span>
                    )}
                    {callStep >= 4 && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-extrabold rounded-full">
                        DIALED ✓
                      </span>
                    )}
                  </div>
                  <div className="text-base text-slate-600 font-bold">108 / 102 (Medical Emergency & Paramedics)</div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => handleManualDial(ambulancePhone, 3)}
                  className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow flex items-center gap-2 text-base active:scale-95"
                >
                  <Phone className="w-5 h-5" />
                  <span>Call 108</span>
                </button>
                <button
                  onClick={() => handleSendManualSms(ambulancePhone)}
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300"
                  title="Open SMS App"
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* SEQUENCE CONTROLS: PAUSE / RESTART */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-100 rounded-2xl border border-slate-300">
            <div className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <Radio className="w-5 h-5 text-red-600 animate-pulse" />
              <span>
                {callStep <= 3 
                  ? (language === 'hi' ? `कॉल प्रगति पर: चरण ${callStep}/3` : `Call sequence in progress: Step ${callStep} of 3`)
                  : (language === 'hi' ? 'सभी 3 कॉल प्रारंभ हो चुकी हैं' : 'All 3 emergency calls initiated')}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsSequencePaused(!isSequencePaused)}
                className="px-3.5 py-1.5 bg-white border border-slate-300 text-slate-800 font-bold text-sm rounded-xl hover:bg-slate-50 transition-colors"
              >
                {isSequencePaused ? "Resume Auto Sequence" : "Pause Auto Timer"}
              </button>
              <button
                onClick={restartSequence}
                className="px-3.5 py-1.5 bg-red-100 border border-red-300 text-red-800 font-bold text-sm rounded-xl hover:bg-red-200 flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Restart All</span>
              </button>
            </div>
          </div>

          {/* LOCATION SHARE & COPY BAR */}
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <MapPin className="w-6 h-6 text-amber-700 flex-shrink-0" />
              <div className="text-sm sm:text-base font-bold text-slate-900">
                <span>{locationText}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyLocation}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-sm shadow flex items-center gap-1.5"
              >
                {copied ? <Check className="w-4 h-4" /> : <MapPin className="w-4 h-4" />}
                <span>{copied ? "Copied!" : "Copy Link"}</span>
              </button>
              <a
                href={sampleLocation}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2 bg-white text-slate-800 border border-slate-300 rounded-xl font-bold text-sm hover:bg-slate-50 shadow-sm no-underline"
              >
                Maps
              </a>
            </div>
          </div>

          {/* CALM SAFETY GUIDANCE FOR ELDERLY */}
          <div className="bg-slate-100 border border-slate-300 rounded-2xl p-4">
            <h4 className="text-lg font-bold text-slate-900 mb-1 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-700" />
              <span>{t("sos.guidanceTitle", "Emergency Guidance")}</span>
            </h4>
            <ul className="space-y-1 text-base text-slate-800 font-medium">
              <li>{t("sos.step1", "1. Sit or lie down in a safe position.")}</li>
              <li>{t("sos.step2", "2. Take slow, deep breaths.")}</li>
              <li>{t("sos.step3", "3. Keep your phone near you and stay on the line.")}</li>
            </ul>
          </div>

          {/* CLOSE BUTTON */}
          <div className="pt-1 text-center">
            <button
              onClick={() => setActiveSOSModal(false)}
              className="w-full sm:w-auto px-8 py-3.5 bg-slate-200 hover:bg-slate-300 text-slate-900 rounded-2xl font-extrabold text-lg border border-slate-400 transition-colors"
            >
              Close Emergency Screen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SOSModal;
