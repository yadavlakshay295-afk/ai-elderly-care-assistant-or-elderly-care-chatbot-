import React, { useState } from 'react';
import { AlertCircle, CheckCircle, ShieldAlert, Phone, ArrowRight, X, Volume2 } from 'lucide-react';
import { useHealthData } from '../../contexts/HealthDataContext.jsx';
import { useLanguage } from '../../contexts/LanguageContext.jsx';
import { useVoice } from '../../contexts/VoiceContext.jsx';

export const FallAssistanceModal = () => {
  const { activeFallModal, setActiveFallModal, reportFallAssistance, triggerSOS } = useHealthData();
  const { language, t } = useLanguage();
  const { speak } = useVoice();

  const [step, setStep] = useState(0); // 0: Question, 1: Guided Steps, 2: Immobilized Alert, 3: Completed Safe
  const [currentGuidedStep, setCurrentGuidedStep] = useState(1);

  if (!activeFallModal) return null;

  const handleAbleToMove = () => {
    setStep(1);
    setCurrentGuidedStep(1);
    reportFallAssistance(true, "Started Step 1");
    const introSpeech = language === 'hi'
      ? "कमला जी, बहुत बढ़िया। शांत रहें। पहला चरण: एक मिनट शांत लेटें और गहरी सांस लें। देखें कि कहीं कोई गंभीर दर्द तो नहीं है।"
      : "Kamla ji, stay calm. Step 1: Stay still for a minute and catch your breath. Check if anything hurts severely.";
    speak(introSpeech);
  };

  const handleCannotMove = () => {
    setStep(2);
    reportFallAssistance(false, "Elderly Reported Immobilized");
    triggerSOS({ type: "FALL_IMMOBILIZED_ALERT", notes: "Elderly reported unable to move after falling." });
    const emergencySpeech = language === 'hi'
      ? "कमला जी, कृपया बिल्कुल मत हिलिए। हमने राहुल जी और आपातकालीन सेवा को तुरंत अलर्ट कर दिया है।"
      : "Kamla ji, please stay completely still. We are alerting Rahul and emergency services right now.";
    speak(emergencySpeech);
  };

  const nextGuidedStep = () => {
    if (currentGuidedStep < 4) {
      const next = currentGuidedStep + 1;
      setCurrentGuidedStep(next);
      reportFallAssistance(true, `Step ${next}`);
      
      const stepTextsHi = {
        2: "चरण 2: धीरे से करवट लें और अपने हाथों तथा घुटनों के बल आएं।",
        3: "चरण 3: धीरे-धीरे किसी मजबूत कुर्सी या बिस्तर की तरफ रेंग कर जाएं।",
        4: "चरण 4: दोनों हाथ कुर्सी पर रखें, एक पैर आगे लाएं और धीरे से कुर्सी पर बैठ जाएं।"
      };
      const stepTextsEn = {
        2: "Step 2: Roll gently onto your side, then get onto your hands and knees.",
        3: "Step 3: Crawl slowly towards the nearest sturdy chair or bed.",
        4: "Step 4: Place both hands on the seat, bring one foot forward, and gently push up to sit."
      };
      speak(language === 'hi' ? stepTextsHi[next] : stepTextsEn[next]);
    } else {
      setStep(3);
      reportFallAssistance(true, "Completed - Seated Safely");
      const doneSpeech = language === 'hi'
        ? "बहुत अच्छा कमला जी! अब आराम से बैठें और पानी पिएँ। राहुल जी को आपके सुरक्षित होने की सूचना मिल गई है।"
        : "Wonderful, Kamla ji! Sit comfortably and take a sip of water. Rahul has been notified that you are safe.";
      speak(doneSpeech);
    }
  };

  const handleClose = () => {
    setActiveFallModal(false);
    setStep(0);
    setCurrentGuidedStep(1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border-4 border-amber-500 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-amber-600 text-white p-6 text-center relative">
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 bg-amber-800/80 hover:bg-amber-900 rounded-full text-white transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          
          <div className="inline-flex items-center justify-center w-18 h-18 bg-white text-amber-600 rounded-full shadow-lg mb-2 p-3">
            <ShieldAlert className="w-10 h-10 stroke-[2.5]" />
          </div>
          <h2 className="text-3xl font-extrabold">{t("fall.title", "Safety & Fall Assistance")}</h2>
          <p className="text-xl text-amber-100 font-semibold mt-1">
            {language === 'hi' ? 'घबराइए मत, हम आपके साथ हैं' : 'Do not panic, we are here with you'}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8">
          {/* STEP 0: Initial Triage Question */}
          {step === 0 && (
            <div className="space-y-6 text-center">
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-6">
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  {t("fall.prompt", "Are you able to move your body safely?")}
                </h3>
                <p className="text-lg text-slate-700 mt-2 font-medium">
                  {language === 'hi' 
                    ? 'अगर आपको कहीं भी बहुत तेज़ दर्द है, तो "नहीं" चुनें।'
                    : 'If you feel severe pain in your back, hip, or head, select "NO".'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {/* YES CAN MOVE */}
                <button
                  onClick={handleAbleToMove}
                  className="min-h-[90px] bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-2xl p-4 flex flex-col items-center justify-center gap-1 shadow-lg border-2 border-emerald-800 transition-all font-bold text-xl"
                >
                  <CheckCircle className="w-8 h-8 text-emerald-200" />
                  <span>{t("fall.yesMove", "YES, I CAN MOVE")}</span>
                </button>

                {/* NO CANNOT MOVE */}
                <button
                  onClick={handleCannotMove}
                  className="min-h-[90px] bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-2xl p-4 flex flex-col items-center justify-center gap-1 shadow-lg border-2 border-red-700 transition-all font-bold text-xl sos-pulse-btn"
                >
                  <AlertCircle className="w-8 h-8 text-red-200" />
                  <span>{t("fall.noMove", "NO, I CANNOT MOVE")}</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 1: Calm Guided Recovery Steps */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b pb-4">
                <h3 className="text-2xl font-bold text-slate-900">
                  {t("fall.recoveryStepsTitle", "Calm Guided Recovery")}
                </h3>
                <span className="px-4 py-1.5 bg-blue-100 text-blue-800 font-extrabold rounded-full text-lg">
                  Step {currentGuidedStep} of 4
                </span>
              </div>

              {/* Step Display Card */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6 min-h-[160px] flex flex-col justify-center">
                <div className="text-2xl font-bold text-slate-900 leading-relaxed">
                  {currentGuidedStep === 1 && t("fall.step1", "1. Stay still for a minute and catch your breath. Check if anything hurts severely.")}
                  {currentGuidedStep === 2 && t("fall.step2", "2. Roll gently onto your side, then get onto your hands and knees.")}
                  {currentGuidedStep === 3 && t("fall.step3", "3. Crawl slowly towards the nearest sturdy chair or bed.")}
                  {currentGuidedStep === 4 && t("fall.step4", "4. Place both hands on the seat, bring one foot forward, and gently push up to sit.")}
                </div>
              </div>

              {/* Progression Controls */}
              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <button
                  onClick={nextGuidedStep}
                  className="flex-1 min-h-[64px] bg-blue-700 hover:bg-blue-800 text-white rounded-2xl p-4 flex items-center justify-center gap-3 font-bold text-xl shadow-md border-2 border-blue-800"
                >
                  <span>{currentGuidedStep === 4 ? (language === 'hi' ? 'हाँ, मैं बैठ गई हूँ ✅' : 'I am seated safely now ✅') : (language === 'hi' ? 'अगला कदम ▶' : 'Next Step ▶')}</span>
                  <ArrowRight className="w-6 h-6" />
                </button>

                <button
                  onClick={handleCannotMove}
                  className="px-6 py-4 bg-red-100 hover:bg-red-200 text-red-700 rounded-2xl font-bold text-lg border border-red-300"
                >
                  {language === 'hi' ? 'मदद चाहिए (कॉल करें)' : 'I need help (Call Caregiver)'}
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Critical Emergency Alert (Cannot Move) */}
          {step === 2 && (
            <div className="space-y-6 text-center">
              <div className="bg-red-50 border-4 border-red-600 rounded-2xl p-6">
                <AlertCircle className="w-16 h-16 text-red-600 mx-auto mb-3 animate-pulse" />
                <h3 className="text-2xl sm:text-3xl font-extrabold text-red-700">
                  {t("fall.immobilizedAlert", "EMERGENCY ALERT SENT")}
                </h3>
                <p className="text-xl text-slate-800 font-bold mt-2">
                  {language === 'hi' 
                    ? 'कृपया बिल्कुल न हिलें। राहुल और 112 को तुरंत सूचित किया गया है।'
                    : 'Please stay still. Rahul and 112 emergency services have been alerted.'}
                </p>
              </div>

              <div className="space-y-3">
                <a
                  href="tel:+919876500001"
                  className="w-full min-h-[64px] bg-red-600 hover:bg-red-700 text-white rounded-2xl p-4 flex items-center justify-center gap-3 font-extrabold text-2xl shadow-lg border-2 border-red-800 no-underline"
                >
                  <Phone className="w-7 h-7" />
                  <span>{language === 'hi' ? 'राहुल को कॉल करें (+91 98765 00001)' : 'Call Rahul (+91 98765 00001)'}</span>
                </a>

                <a
                  href="tel:112"
                  className="w-full min-h-[60px] bg-slate-900 hover:bg-slate-800 text-white rounded-2xl p-4 flex items-center justify-center gap-3 font-bold text-xl shadow border-2 border-slate-700 no-underline"
                >
                  <Phone className="w-6 h-6" />
                  <span>Call Emergency 112</span>
                </a>
              </div>
            </div>
          )}

          {/* STEP 3: Safe & Completed */}
          {step === 3 && (
            <div className="space-y-6 text-center">
              <div className="bg-emerald-50 border-2 border-emerald-400 rounded-2xl p-6">
                <CheckCircle className="w-16 h-16 text-emerald-600 mx-auto mb-3" />
                <h3 className="text-3xl font-extrabold text-emerald-800">
                  {language === 'hi' ? 'आप सुरक्षित बैठ गई हैं 🌸' : 'You are Seated Safely 🌸'}
                </h3>
                <p className="text-lg text-slate-700 font-medium mt-2">
                  {language === 'hi' 
                    ? 'अब आराम से बैठें, एक घूँट पानी पिएँ और कुछ देर विश्राम करें।'
                    : 'Rest for a few minutes, sip some water, and take it slow.'}
                </p>
              </div>

              <button
                onClick={handleClose}
                className="w-full min-h-[60px] bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-xl shadow"
              >
                {language === 'hi' ? 'वापस होम स्क्रीन पर जाएं' : 'Return to Home Screen'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FallAssistanceModal;
