import React from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { useVoice } from '../../contexts/VoiceContext.jsx';

export const SpeechReader = ({ text, className = '', label = "Listen" }) => {
  const { speak, isSpeaking, stopSpeaking } = useVoice();

  const handleToggle = (e) => {
    e.stopPropagation();
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speak(text);
    }
  };

  return (
    <button
      onClick={handleToggle}
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-sm transition-colors active:scale-95 shadow-sm ${className}`}
      title={isSpeaking ? "Stop reading" : "Read aloud"}
      aria-label="Read text aloud"
    >
      {isSpeaking ? (
        <>
          <VolumeX className="w-5 h-5 text-red-600 animate-pulse" />
          <span className="text-red-600 font-medium">Stop</span>
        </>
      ) : (
        <>
          <Volume2 className="w-5 h-5 text-blue-600" />
          <span>{label}</span>
        </>
      )}
    </button>
  );
};

export default SpeechReader;
