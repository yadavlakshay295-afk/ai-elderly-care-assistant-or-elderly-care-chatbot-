import React from 'react';
import clsx from 'clsx';

export const BigButton = ({
  children,
  onClick,
  variant = 'primary',
  size = 'lg',
  icon: Icon,
  disabled = false,
  className = '',
  pulse = false,
  ariaLabel
}) => {
  const variantStyles = {
    primary: 'bg-blue-700 hover:bg-blue-800 text-white shadow-blue-200 border-2 border-blue-800',
    secondary: 'bg-teal-700 hover:bg-teal-800 text-white shadow-teal-200 border-2 border-teal-800',
    success: 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-200 border-2 border-emerald-800',
    danger: 'bg-red-600 hover:bg-red-700 text-white shadow-red-200 border-2 border-red-700',
    amber: 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-200 border-2 border-amber-700',
    outline: 'bg-white hover:bg-slate-100 text-slate-900 border-2 border-slate-400 shadow-slate-100',
    subtle: 'bg-slate-100 hover:bg-slate-200 text-slate-900 border-2 border-slate-300'
  };

  const sizeStyles = {
    md: 'min-h-[52px] px-5 py-3 text-[18px] rounded-xl',
    lg: 'min-h-[64px] px-6 py-4 text-[20px] rounded-2xl',
    xl: 'min-h-[76px] px-8 py-5 text-[24px] rounded-2xl'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      className={clsx(
        'elder-btn font-bold tracking-wide transition-all duration-150 flex items-center justify-center gap-3 select-none active:scale-95 disabled:opacity-50 disabled:pointer-events-none',
        variantStyles[variant] || variantStyles.primary,
        sizeStyles[size] || sizeStyles.lg,
        pulse && 'sos-pulse-btn',
        className
      )}
    >
      {Icon && <Icon className="w-7 h-7 flex-shrink-0 stroke-[2.5]" />}
      <span>{children}</span>
    </button>
  );
};

export default BigButton;
