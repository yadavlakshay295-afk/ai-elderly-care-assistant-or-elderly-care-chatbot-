import React from 'react';
import { Activity, CheckCircle, Clock, Heart, ShieldAlert } from 'lucide-react';
import { useHealthData } from '../../contexts/HealthDataContext.jsx';
import { useLanguage } from '../../contexts/LanguageContext.jsx';

export const CareScoreCard = () => {
  const { careScore } = useHealthData();
  const { language, t } = useLanguage();

  const { score, statusLabel, statusColor, breakdown, disclaimer } = careScore;

  // Determine stroke color
  const colorMap = {
    emerald: 'text-emerald-600 stroke-emerald-600',
    blue: 'text-blue-600 stroke-blue-600',
    amber: 'text-amber-600 stroke-amber-600',
    red: 'text-red-600 stroke-red-600'
  };

  const bgMap = {
    emerald: 'bg-emerald-50 border-emerald-300',
    blue: 'bg-blue-50 border-blue-300',
    amber: 'bg-amber-50 border-amber-300',
    red: 'bg-red-50 border-red-300'
  };

  return (
    <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left: Score Gauge */}
        <div className="flex items-center gap-6">
          <div className="relative w-32 h-32 flex items-center justify-center flex-shrink-0">
            {/* SVG Progress Circle */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                className="text-slate-100 stroke-current"
                strokeWidth="12"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                className={colorMap[statusColor] || 'text-blue-600 stroke-current'}
                strokeWidth="12"
                strokeDasharray={251.2}
                strokeDashoffset={251.2 - (251.2 * score) / 100}
                strokeLinecap="round"
                fill="transparent"
                style={{ transition: 'stroke-dashoffset 0.8s ease' }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-slate-900">{score}</span>
              <span className="text-xs font-bold text-slate-500 uppercase">/ 100</span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 text-sm font-extrabold rounded-full bg-slate-100 text-slate-700 uppercase tracking-wider">
                Activity Score
              </span>
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">
              {t("caregiver.careScore", "Care Activity Score")}
            </h3>
            <p className={`text-lg font-bold mt-0.5 ${colorMap[statusColor]?.split(' ')[0] || 'text-blue-700'}`}>
              {statusLabel}
            </p>
          </div>
        </div>

        {/* Right: Category Breakdown */}
        <div className="w-full md:w-auto flex-1 max-w-md space-y-3">
          {/* Medicine Adherence */}
          <div>
            <div className="flex justify-between text-base font-bold text-slate-700 mb-1">
              <span className="flex items-center gap-2">
                💊 <span>Medicine Adherence</span>
              </span>
              <span>{breakdown.medicationPoints} / 50 pts</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 rounded-full transition-all duration-500"
                style={{ width: `${(breakdown.medicationPoints / 50) * 100}%` }}
              />
            </div>
          </div>

          {/* Daily Wellness Check-in */}
          <div>
            <div className="flex justify-between text-base font-bold text-slate-700 mb-1">
              <span className="flex items-center gap-2">
                ❤️ <span>Daily Check-in</span>
              </span>
              <span>{breakdown.wellnessPoints} / 30 pts</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-600 rounded-full transition-all duration-500"
                style={{ width: `${(breakdown.wellnessPoints / 30) * 100}%` }}
              />
            </div>
          </div>

          {/* Appointment Punctuality */}
          <div>
            <div className="flex justify-between text-base font-bold text-slate-700 mb-1">
              <span className="flex items-center gap-2">
                📅 <span>Routine & Safety</span>
              </span>
              <span>{breakdown.appointmentPoints} / 20 pts</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${(breakdown.appointmentPoints / 20) * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Non-Diagnostic Disclaimer Banner */}
      <div className="mt-6 pt-4 border-t border-slate-200 flex items-center gap-3 text-slate-500 text-sm">
        <ShieldAlert className="w-5 h-5 flex-shrink-0 text-slate-400" />
        <p className="font-medium">
          {disclaimer}
        </p>
      </div>
    </div>
  );
};

export default CareScoreCard;
