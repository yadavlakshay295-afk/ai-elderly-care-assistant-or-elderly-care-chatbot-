/**
 * Date and time formatting utilities with bilingual support
 */

export function getTimeGreeting(lang = 'en') {
  const hour = new Date().getHours();
  if (hour < 12) {
    return lang === 'hi' ? 'सुप्रभात 🌸' : 'Good Morning 🌸';
  } else if (hour < 17) {
    return lang === 'hi' ? 'नमस्ते / शुभ दोपहर ☀️' : 'Good Afternoon ☀️';
  } else {
    return lang === 'hi' ? 'शुभ संध्या 🌙' : 'Good Evening 🌙';
  }
}

export function formatCurrentDate(lang = 'en') {
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const locale = lang === 'hi' ? 'hi-IN' : 'en-US';
  return new Date().toLocaleDateString(locale, options);
}

export function formatTimestamp(isoString) {
  if (!isoString) return '';
  const date = new Date(isoString);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
