/**
 * Calculates a non-diagnostic Care Activity Score (0 to 100).
 * Based ONLY on routine completion (medication adherence, daily check-in, appointments).
 * 
 * DISCLAIMER: This is an activity adherence indicator, NOT a medical or clinical diagnosis.
 */

export function calculateCareScore({ medicines = [], wellnessCheckins = [], appointments = [] }) {
  let score = 0;
  const breakdown = {
    medicationPoints: 0,
    wellnessPoints: 0,
    appointmentPoints: 0
  };

  // 1. Medication Adherence (Up to 50 Points)
  const totalMeds = medicines.length;
  if (totalMeds > 0) {
    const takenMeds = medicines.filter(m => m.statusToday === "TAKEN").length;
    breakdown.medicationPoints = Math.round((takenMeds / totalMeds) * 50);
  } else {
    breakdown.medicationPoints = 50; // No meds due today
  }

  // 2. Daily Wellness Check-in (Up to 30 Points)
  const todayStr = new Date().toISOString().split("T")[0];
  const hasCheckedInToday = wellnessCheckins.some(w => w.date === todayStr);
  breakdown.wellnessPoints = hasCheckedInToday ? 30 : 15;

  // 3. Appointment & Safety Routine (Up to 20 Points)
  breakdown.appointmentPoints = 20;

  score = breakdown.medicationPoints + breakdown.wellnessPoints + breakdown.appointmentPoints;

  // Rating label
  let statusLabel = "Good Routine";
  let statusColor = "emerald";

  if (score >= 85) {
    statusLabel = "Excellent Adherence";
    statusColor = "emerald";
  } else if (score >= 65) {
    statusLabel = "Good Daily Routine";
    statusColor = "blue";
  } else if (score >= 45) {
    statusLabel = "Moderate (Reminders Needed)";
    statusColor = "amber";
  } else {
    statusLabel = "Needs Family Follow-up";
    statusColor = "red";
  }

  return {
    score: Math.min(100, Math.max(0, score)),
    statusLabel,
    statusColor,
    breakdown,
    disclaimer: "Activity & Adherence Indicator — Not a Clinical Medical Diagnosis."
  };
}
