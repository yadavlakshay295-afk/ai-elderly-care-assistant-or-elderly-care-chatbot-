import React from 'react';
import { Type, Globe, Volume2, Sparkles, Check, Info } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import { useVoice } from '../contexts/VoiceContext.jsx';

export const SettingsPage = () => {
  const { fontSizeScale, setFontSizeScale, isDemoMode } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { speechRate, setSpeechRate, autoSpeak, setAutoSpeak, speak } = useVoice();

  const testVoice = () => {
    const testText = language === 'hi'
      ? "नमस्ते कमला जी, यह आवाज़ की गति का परीक्षण है। आशा है आपको साफ सुनाई दे रहा है।"
      : "Hello, this is a test of your voice assistant speed. How does this sound?";
    speak(testText);
  };

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-elder border-2 border-slate-200">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
          {t("settings.title", "Accessibility & Preferences")}
        </h1>
        <p className="text-lg sm:text-xl font-semibold text-slate-600 mt-1">
          {t("settings.subtitle", "Customize fonts, voice, and language for maximum comfort.")}
        </p>
      </div>

      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-elder border-2 border-slate-200 space-y-8">
        {/* 1. Font Sizing */}
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2 mb-3">
            <Type className="w-6 h-6 text-blue-700" />
            <span>{t("settings.textSize", "Text Size")}</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { scale: 0.95, label: t("settings.sizeNormal", "Normal (18px)") },
              { scale: 1.1, label: t("settings.sizeLarge", "Large (22px)") },
              { scale: 1.3, label: t("settings.sizeXLarge", "Extra Large (26px)") }
            ].map((item) => (
              <button
                key={item.scale}
                onClick={() => setFontSizeScale(item.scale)}
                className={`p-4 rounded-2xl border-2 font-bold text-lg flex items-center justify-between transition-all ${
                  Math.abs(fontSizeScale - item.scale) < 0.05
                    ? 'bg-blue-700 text-white border-blue-800 shadow-md'
                    : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-slate-100'
                }`}
              >
                <span>{item.label}</span>
                {Math.abs(fontSizeScale - item.scale) < 0.05 && <Check className="w-6 h-6" />}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Language Selection */}
        <div className="pt-4 border-t border-slate-200">
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2 mb-3">
            <Globe className="w-6 h-6 text-teal-700" />
            <span>{t("settings.language", "Interface Language")}</span>
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setLanguage('hi')}
              className={`p-5 rounded-2xl border-2 font-black text-xl flex items-center justify-between transition-all ${
                language === 'hi'
                  ? 'bg-teal-700 text-white border-teal-800 shadow-md'
                  : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-slate-100'
              }`}
            >
              <span>🇮🇳 हिंदी (Hindi)</span>
              {language === 'hi' && <Check className="w-6 h-6" />}
            </button>

            <button
              onClick={() => setLanguage('en')}
              className={`p-5 rounded-2xl border-2 font-black text-xl flex items-center justify-between transition-all ${
                language === 'en'
                  ? 'bg-teal-700 text-white border-teal-800 shadow-md'
                  : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-slate-100'
              }`}
            >
              <span>🇬🇧 English</span>
              {language === 'en' && <Check className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* 3. Voice & Speech Controls */}
        <div className="pt-4 border-t border-slate-200 space-y-4">
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2 mb-2">
            <Volume2 className="w-6 h-6 text-amber-600" />
            <span>Voice & Audio Companion</span>
          </h2>

          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-slate-800">
                {t("settings.speechRate", "Voice Speaking Rate")}
              </span>
              <span className="text-xl font-extrabold text-blue-700">
                {speechRate}x ({speechRate <= 0.85 ? 'Calm & Slow' : 'Normal'})
              </span>
            </div>

            <input
              type="range"
              min="0.7"
              max="1.1"
              step="0.05"
              value={speechRate}
              onChange={(e) => setSpeechRate(Number(e.target.value))}
              className="w-full h-3 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-blue-700"
            />

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={testVoice}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold text-base shadow flex items-center gap-2"
              >
                <Volume2 className="w-5 h-5" />
                <span>Test Voice Sample</span>
              </button>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoSpeak}
                  onChange={(e) => setAutoSpeak(e.target.checked)}
                  className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="font-bold text-slate-800 text-base">Auto-readout AI replies</span>
              </label>
            </div>
          </div>
        </div>

        {/* Demo Mode Notice */}
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3">
          <Info className="w-6 h-6 text-amber-700 flex-shrink-0 mt-0.5" />
          <div className="text-sm font-medium text-amber-950">
            <p className="font-bold text-base">Local AI — 100% API-Key-Free & Offline Ready</p>
            <p>ElderCare AI is pre-configured with sample records for Kamla Devi (72), Rahul (Son), and Dr. Sharma. All features work completely locally with an intelligent intent engine — no API key or external cloud AI required.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
