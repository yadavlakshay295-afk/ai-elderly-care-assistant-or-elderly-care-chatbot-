import React, { useState } from 'react';
import { Users, Pill, Calendar, Heart, ShieldAlert, CheckCircle2, AlertTriangle, Phone, Plus, RefreshCw, Sparkles, MapPin } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import CareScoreCard from '../components/caregiver/CareScoreCard.jsx';
import SpeechReader from '../components/common/SpeechReader.jsx';

export const CaregiverDashboard = ({ onNavigate }) => {
  const { elderlyUser, caregiver } = useAuth();
  const { language, t } = useLanguage();
  const { medicines, appointments, wellnessCheckins, emergencyEvents, resolveEmergencyEvent } = useHealthData();

  const takenMeds = medicines.filter(m => m.statusToday === 'TAKEN');
  const pendingMeds = medicines.filter(m => m.statusToday !== 'TAKEN');
  const latestWellness = wellnessCheckins[0];
  const activeEmergencies = emergencyEvents.filter(e => e.status === 'ACTIVE_ALERT');

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-5xl mx-auto">
      {/* Caregiver Welcome Banner */}
      <div className="bg-gradient-to-r from-teal-900/90 via-emerald-900/90 to-slate-900/95 backdrop-blur-xl text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-white/20 relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-18 h-18 bg-white text-emerald-800 rounded-2xl flex items-center justify-center text-3xl font-bold shadow-md">
              👵
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-emerald-700/80 text-emerald-100 rounded-full text-xs font-bold uppercase tracking-wider">
                  Caregiver Portal
                </span>
                <span className="text-xs font-semibold text-emerald-200">
                  Caregiver: {caregiver.name} ({caregiver.relation})
                </span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold mt-1">
                {elderlyUser.name} ({elderlyUser.age} yrs)
              </h1>
              <p className="text-base sm:text-lg text-emerald-100 font-medium mt-1">
                📍 {elderlyUser.address} • Blood Group: {elderlyUser.bloodGroup}
              </p>
            </div>
          </div>

          <a
            href={`tel:${(elderlyUser.phone || "+91 98765 43210").replace(/\s+/g, '')}`}
            className="px-5 py-3 bg-white hover:bg-emerald-50 active:scale-95 text-emerald-900 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-md self-start sm:self-auto no-underline transition-all"
          >
            <Phone className="w-5 h-5 text-emerald-700" />
            <span>Call Mom</span>
          </a>
        </div>

        {/* Medical Notes Pill */}
        <div className="mt-4 pt-3 border-t border-emerald-700/70 text-sm sm:text-base text-emerald-100 flex items-center gap-2">
          <span className="font-bold text-white">Health Profile Notes:</span>
          <span>{elderlyUser.emergencyNotes}</span>
        </div>
      </div>

      {/* Care Activity Score Component */}
      <CareScoreCard />

      {/* Active Alerts Banner if any */}
      {activeEmergencies.length > 0 && (
        <div className="bg-red-50 border-4 border-red-500 rounded-3xl p-6 shadow-md space-y-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-8 h-8 text-red-600 animate-bounce" />
            <div>
              <h2 className="text-2xl font-black text-red-900">
                ACTIVE EMERGENCY SOS EVENT
              </h2>
              <p className="text-base text-red-700 font-bold">
                Kamla Devi triggered an emergency signal.
              </p>
            </div>
          </div>

          {activeEmergencies.map((ev) => (
            <div key={ev.id} className="bg-white p-4 rounded-2xl border border-red-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <div className="font-extrabold text-lg text-slate-900">
                  {ev.type} • {ev.displayTime}
                </div>
                <div className="text-sm text-slate-600 font-medium">
                  {ev.location} - {ev.userNotes}
                </div>
              </div>
              <button
                onClick={() => resolveEmergencyEvent(ev.id)}
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-base shadow transition-all"
              >
                Mark as Checked & Resolved
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 2-Column Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Column 1: Today's Medication Adherence */}
        <div className="glass-card rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Pill className="w-6 h-6 text-blue-700" />
              <span>Medication Tracking</span>
            </h2>
            <button
              onClick={() => onNavigate('medicines')}
              className="text-base font-bold text-blue-700 hover:underline"
            >
              Manage &gt;
            </button>
          </div>

          <div className="space-y-3">
            {medicines.map((m) => {
              const isTaken = m.statusToday === 'TAKEN';
              return (
                <div
                  key={m.id}
                  className={`p-4 rounded-2xl border backdrop-blur-md flex items-center justify-between transition-all ${
                    isTaken ? 'bg-emerald-500/10 border-emerald-300' : 'bg-amber-500/10 border-amber-300'
                  }`}
                >
                  <div>
                    <div className="font-bold text-lg text-slate-900">{m.name}</div>
                    <div className="text-sm font-semibold text-slate-600">
                      {m.scheduledTime} • {m.dosage} ({m.withFood})
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-extrabold ${
                    isTaken ? 'bg-emerald-200/80 text-emerald-900' : 'bg-amber-200/80 text-amber-950'
                  }`}>
                    {isTaken ? `Taken (${m.takenAt || 'On time'})` : 'Due / Pending'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Column 2: Latest Daily Wellness */}
        <div className="glass-card rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Heart className="w-6 h-6 text-rose-600" />
              <span>Daily Wellness Overview</span>
            </h2>
            <button
              onClick={() => onNavigate('wellness')}
              className="text-base font-bold text-rose-600 hover:underline"
            >
              History &gt;
            </button>
          </div>

          {latestWellness ? (
            <div className="bg-white/60 backdrop-blur-md border border-white/80 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{latestWellness.moodEmoji}</span>
                <div>
                  <div className="text-xl font-extrabold text-slate-900">
                    {latestWellness.moodLabel}
                  </div>
                  <div className="text-xs font-bold text-slate-500">
                    Logged today at {latestWellness.time}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200 text-center">
                <div className="bg-white/80 p-2.5 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-500">Sleep</div>
                  <div className="text-lg font-black text-purple-700">{latestWellness.sleepHours} hrs</div>
                </div>
                <div className="bg-white/80 p-2.5 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-500">Water</div>
                  <div className="text-lg font-black text-blue-700">{latestWellness.waterGlasses} glasses</div>
                </div>
                <div className="bg-white/80 p-2.5 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-500">Discomfort</div>
                  <div className="text-lg font-black text-rose-600">{latestWellness.painLevel}/10</div>
                </div>
              </div>

              {latestWellness.notes && (
                <p className="text-sm font-medium text-slate-700 italic bg-white/80 p-3 rounded-xl border border-slate-200">
                  Mom's Note: "{latestWellness.notes}"
                </p>
              )}
            </div>
          ) : (
            <div className="p-6 text-center text-slate-500 bg-white/50 rounded-2xl">
              No wellness check-in recorded for today yet.
            </div>
          )}
        </div>
      </div>

      {/* Safety & Incident History Log */}
      <div className="glass-card rounded-3xl p-6 shadow-xl space-y-4">
        <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-amber-600" />
          <span>{t("caregiver.recentAlerts", "Safety & SOS Incident Feed")}</span>
        </h2>

        <div className="space-y-3">
          {emergencyEvents.length === 0 ? (
            <div className="p-4 bg-emerald-50 text-emerald-800 rounded-2xl font-bold flex items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              <span>{t("caregiver.noAlerts", "🟢 No critical safety emergencies detected.")}</span>
            </div>
          ) : (
            emergencyEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">{ev.type}</span>
                    <span className={`px-2.5 py-0.5 text-xs font-extrabold rounded-full ${
                      ev.status === 'ACTIVE_ALERT' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {ev.status}
                    </span>
                  </div>
                  <div className="text-sm font-medium text-slate-600 mt-0.5">
                    {ev.timestamp?.split('T')[0]} • {ev.displayTime || 'Recent'} • {ev.location || 'Home'}
                  </div>
                </div>

                {ev.status === 'ACTIVE_ALERT' && (
                  <button
                    onClick={() => resolveEmergencyEvent(ev.id)}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-bold shadow"
                  >
                    Mark Resolved
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default CaregiverDashboard;
