import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Send, Volume2, VolumeX, Sparkles, AlertTriangle, Trash2, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useVoice } from '../contexts/VoiceContext.jsx';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { api } from '../services/api.js';

export const AIChatPage = ({ onNavigate }) => {
  const { language, t } = useLanguage();
  const { elderlyUser } = useAuth();
  const { speak, isSpeaking, stopSpeaking, isListening, startListening, stopListening, autoSpeak, setAutoSpeak } = useVoice();
  const { medicines, appointments, setActiveSOSModal, setActiveFallModal } = useHealthData();

  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState(() => {
    return [
      {
        id: 'msg_welcome',
        sender: 'ai',
        text: language === 'hi'
          ? `नमस्ते कमला जी! 🌸 मैं आपकी एआई देखभाल साथी हूँ। आप मुझसे अपनी दवाइयों, डॉक्टर के अपॉइंटमेंट, या किसी भी बात पर चर्चा कर सकती हैं। आप माइक दबाकर बोल भी सकती हैं!`
          : `Hello ${elderlyUser.name}! 🌸 I am your caring AI companion. You can ask me about your medicines, doctor appointments, or just talk. Tap the microphone anytime to speak!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isLoading) return;

    const userMsg = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const userContext = {
        name: elderlyUser.name,
        age: elderlyUser.age,
        primaryCaregiver: elderlyUser.primaryCaregiver,
        todayMedicines: medicines.map(m => ({ name: m.name, time: m.scheduledTime, status: m.statusToday })),
        appointments: appointments.map(a => ({ doctor: a.doctorName, date: a.displayDate, time: a.time }))
      };

      const aiResponse = await api.sendChatMessage({
        message: text,
        language,
        userContext
      });

      const aiMsg = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: aiResponse.text,
        intent: aiResponse.intent,
        severity: aiResponse.severity,
        requires_human_help: aiResponse.requires_human_help,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);

      // If Emergency or Fall Intent detected, trigger modal
      if (aiResponse.intent === 'EMERGENCY') {
        setActiveSOSModal(true);
      } else if (aiResponse.intent === 'FALL_ASSISTANCE') {
        setActiveFallModal(true);
      }

      // Auto readout
      if (autoSpeak) {
        speak(aiResponse.text);
      }
    } catch (err) {
      console.error("Chat error:", err);
      const errorMsg = {
        id: `err_${Date.now()}`,
        sender: 'ai',
        text: language === 'hi'
          ? "माफ़ कीजिए, मुझे उत्तर देने में कुछ कठिनाई हुई। कृपया दोबारा पूछें।"
          : "I had a momentary hiccup. Please ask me again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMic = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening(
        (transcript) => {
          setInputMessage(transcript);
          handleSendMessage(transcript);
        },
        (err) => {
          console.warn("Speech error:", err);
        }
      );
    }
  };

  const quickPrompts = [
    { key: 'medicines', label: t("chat.prompts.medicines", "What medicines do I have today?"), icon: "💊" },
    { key: 'appointment', label: t("chat.prompts.appointment", "When is my next doctor appointment?"), icon: "📅" },
    { key: 'lonely', label: t("chat.prompts.lonely", "I am feeling a bit lonely today."), icon: "🌸" },
    { key: 'story', label: t("chat.prompts.story", "Tell me a short inspiring story."), icon: "📖" },
    { key: 'joke', label: t("chat.prompts.joke", "Tell me a clean funny joke."), icon: "😄" },
    { key: 'bp', label: t("chat.prompts.bp", "What is blood pressure?"), icon: "🩺" },
    { key: 'dizzy', label: t("chat.prompts.dizzy", "I am feeling dizzy after standing up."), icon: "💫" },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] max-w-4xl mx-auto pb-4">
      {/* Top Header */}
      <div className="glass-card rounded-3xl p-4 sm:p-5 shadow-lg mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-amber-100 text-amber-800 rounded-2xl flex items-center justify-center text-2xl shadow-sm">
            🤖
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {t("chat.title", "AI Care Companion")}
              </h2>
              <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-bold bg-emerald-100 text-emerald-800 rounded-full border border-emerald-300">
                ⚡ Local AI (API-Free)
              </span>
            </div>
            <p className="text-xs sm:text-sm font-semibold text-slate-500">
              {language === 'hi' ? 'स्थानीय एआई • हमेशा सुनने व मार्गदर्शन के लिए उपस्थित' : 'Local AI Assistant • Patient, warm & safety-conscious'}
            </p>
          </div>
        </div>

        {/* Audio auto-speak toggle & clear */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoSpeak(!autoSpeak)}
            className={`p-2.5 rounded-xl border font-bold text-sm flex items-center gap-1.5 transition-colors ${
              autoSpeak ? 'bg-blue-50 text-blue-800 border-blue-300' : 'bg-slate-100 text-slate-600 border-slate-300'
            }`}
            title="Toggle Auto Read-aloud"
          >
            {autoSpeak ? <Volume2 className="w-5 h-5 text-blue-700" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
            <span className="hidden sm:inline">{autoSpeak ? 'Voice On' : 'Voice Off'}</span>
          </button>

          <button
            onClick={() => setMessages([messages[0]])}
            className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors border border-slate-300"
            title="Clear Chat"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto space-y-4 p-4 bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 mb-3 shadow-inner">
        {messages.map((msg) => {
          const isAi = msg.sender === 'ai';
          const isEmergency = msg.intent === 'EMERGENCY';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isAi ? 'items-start' : 'items-end'} animate-fade-in`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[78%] rounded-3xl p-5 shadow-sm ${
                  isAi
                    ? isEmergency
                      ? 'bg-red-500/15 border-2 border-red-500 text-red-950 font-bold backdrop-blur-md'
                      : 'bg-white/85 backdrop-blur-md border border-white/90 text-slate-900 shadow-md'
                    : 'bg-gradient-to-r from-blue-700 to-indigo-700 text-white rounded-br-md font-medium shadow-md'
                }`}
              >
                {/* Header for bubble */}
                <div className="flex items-center justify-between gap-3 mb-2">
                  <span className={`text-xs font-bold uppercase tracking-wider ${isAi ? 'text-blue-700' : 'text-blue-200'}`}>
                    {isAi ? '👵 ElderCare AI' : elderlyUser.name}
                  </span>
                  <span className={`text-xs ${isAi ? 'text-slate-400' : 'text-blue-200'}`}>
                    {msg.timestamp}
                  </span>
                </div>

                {/* Bubble Text */}
                <p className="text-xl sm:text-2xl leading-relaxed whitespace-pre-line">
                  {msg.text}
                </p>

                {/* If Emergency, show quick alert action inside message */}
                {isEmergency && (
                  <div className="mt-4 pt-3 border-t-2 border-red-300 flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-red-700">🚨 Critical Help Screen</span>
                    <button
                      onClick={() => setActiveSOSModal(true)}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-base font-extrabold shadow"
                    >
                      Open SOS Now
                    </button>
                  </div>
                )}

                {/* AI Speech Readout Button */}
                {isAi && (
                  <div className="mt-3 pt-2 border-t border-slate-100 flex justify-end">
                    <button
                      onClick={() => speak(msg.text)}
                      className="inline-flex items-center gap-1.5 text-sm font-bold text-blue-700 hover:text-blue-900 p-1.5 rounded-lg hover:bg-blue-50 transition-colors"
                    >
                      <Volume2 className="w-5 h-5" />
                      <span>{language === 'hi' ? 'बोलकर सुनाएँ' : 'Read Aloud'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-3 p-4 bg-white/80 backdrop-blur-md rounded-2xl border border-white max-w-xs animate-pulse shadow-md">
            <Sparkles className="w-6 h-6 text-amber-600 animate-spin" />
            <span className="text-lg font-bold text-slate-700">
              {language === 'hi' ? 'उत्तर तैयार किया जा रहा है...' : 'Thinking warmly...'}
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="mb-3 overflow-x-auto pb-1 flex items-center gap-2 no-scrollbar">
        {quickPrompts.map((p) => (
          <button
            key={p.key}
            onClick={() => handleSendMessage(p.label)}
            className="flex-shrink-0 bg-white/70 backdrop-blur-md hover:bg-white active:scale-95 text-slate-800 border border-white/80 hover:border-amber-400 rounded-2xl px-4 py-2 text-base sm:text-lg font-bold shadow-sm transition-all flex items-center gap-2"
          >
            <span>{p.icon}</span>
            <span>{p.label}</span>
          </button>
        ))}
      </div>

      {/* Big Touch Voice & Text Input Bar */}
      <div className="glass-card rounded-3xl p-3 sm:p-4 shadow-xl flex items-center gap-2 sm:gap-3">
        {/* Large Microphone Button */}
        <button
          onClick={toggleMic}
          className={`w-16 h-16 sm:w-18 sm:h-18 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all shadow-md ${
            isListening
              ? 'bg-red-600 text-white mic-active border-4 border-red-300'
              : 'bg-amber-500 hover:bg-amber-600 text-slate-950 border-2 border-amber-600'
          }`}
          aria-label="Voice input microphone"
        >
          {isListening ? (
            <MicOff className="w-8 h-8 stroke-[2.5]" />
          ) : (
            <Mic className="w-8 h-8 stroke-[2.5]" />
          )}
        </button>

        {/* Text Input */}
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder={isListening ? (language === 'hi' ? 'सुन रही हूँ...' : 'Listening to your voice...') : t("chat.placeholder", "Type or speak...")}
          className="flex-1 bg-slate-50 border-2 border-slate-300 focus:border-blue-700 focus:bg-white rounded-2xl px-4 py-3.5 text-xl font-medium text-slate-900 outline-none transition-all placeholder:text-slate-400"
        />

        {/* Send Button */}
        <button
          onClick={() => handleSendMessage()}
          disabled={!inputMessage.trim() || isLoading}
          className="w-14 h-14 sm:w-16 sm:h-16 bg-blue-700 hover:bg-blue-800 disabled:opacity-40 disabled:pointer-events-none active:scale-95 text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md transition-all"
          aria-label="Send message"
        >
          <Send className="w-7 h-7 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};

export default AIChatPage;
