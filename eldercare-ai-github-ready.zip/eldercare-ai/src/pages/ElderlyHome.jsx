import React from 'react';
import { Mic, Pill, Calendar, Heart, ShieldAlert, Phone, Sparkles, ChevronRight, AlertCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useVoice } from '../contexts/VoiceContext.jsx';
import { getTimeGreeting, formatCurrentDate } from '../utils/formatters.js';
import SpeechReader from '../components/common/SpeechReader.jsx';

export const ElderlyHome = ({ onNavigate }) => {
  const { elderlyUser } = useAuth();
  const { language, t } = useLanguage();
  const { medicines, appointments, wellnessCheckins, triggerSOS, setActiveSOSModal, setActiveFallModal } = useHealthData();
  const { startListening } = useVoice();

  const greeting = getTimeGreeting(language);
  const formattedDate = formatCurrentDate(language);

  // Status summaries
  const takenMedsCount = medicines.filter(m => m.statusToday === 'TAKEN').length;
  const totalMedsCount = medicines.length;
  const nextAppointment = appointments[0];
  const todayWellness = wellnessCheckins.find(w => w.date === new Date().toISOString().split('T')[0]);

  const welcomeSentence = language === 'hi'
    ? `${greeting} कमला जी! आज आप कैसा महसूस कर रही हैं?`
    : `${greeting}, ${elderlyUser.name}! How can I help you today?`;

  const handleVoiceAssistant = () => {
    onNavigate('chat');
  };

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Hero Greeting Card */}
      <div className="bg-gradient-to-br from-blue-900/90 via-indigo-900/90 to-slate-900/95 backdrop-blur-xl text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-white/20 relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -top-12 w-40 h-40 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-blue-200 text-sm font-bold uppercase tracking-wider mb-2 border border-white/15">
              <span>📅 {formattedDate}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              {language === 'hi' ? `${greeting} कमला जी 👋` : `${greeting} Kamla ji 👋`}
            </h1>
            <p className="text-xl sm:text-2xl font-semibold text-blue-100 mt-2">
              {t("home.subtitle", "How can I help you today?")}
            </p>
          </div>

          <div className="self-start sm:self-auto">
            <SpeechReader text={welcomeSentence} label={language === 'hi' ? 'बोलकर सुनाएँ' : 'Listen'} />
          </div>
        </div>

        {/* Primary TALK TO ME Voice Button */}
        <div className="mt-6">
          <button
            onClick={handleVoiceAssistant}
            className="w-full min-h-[76px] bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 active:scale-98 text-slate-950 rounded-2xl p-4 flex items-center justify-between shadow-xl border-2 border-amber-300/80 transition-all font-extrabold text-2xl sm:text-3xl group"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-slate-950 text-amber-400 rounded-2xl flex items-center justify-center shadow-lg">
                <Mic className="w-8 h-8 stroke-[2.5] group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-left">
                <div>{t("home.talkToMe", "TALK TO ME")}</div>
                <div className="text-base sm:text-lg font-bold text-slate-800">
                  {language === 'hi' ? 'बोलकर अपनी बात कहें' : 'Tap to speak with your AI Helper'}
                </div>
              </div>
            </div>
            <Sparkles className="w-8 h-8 text-slate-900 mr-2" />
          </button>
        </div>
      </div>

      {/* Fall / Safety Help Button */}
      <button
        onClick={() => setActiveFallModal(true)}
        className="w-full min-h-[64px] bg-red-500/10 hover:bg-red-500/20 active:scale-98 text-red-900 rounded-2xl p-4 flex items-center justify-between border-2 border-red-300/70 backdrop-blur-md shadow-sm transition-all"
      >
        <div className="flex items-center gap-3">
          <AlertCircle className="w-8 h-8 text-red-600 flex-shrink-0" />
          <span className="font-extrabold text-xl sm:text-2xl text-left">
            {t("home.iFellBtn", "🚨 I FELL DOWN (HELP ME)")}
          </span>
        </div>
        <ChevronRight className="w-7 h-7 text-red-700" />
      </button>

      {/* Main 4 Core Action Tiles with Glassmorphism */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
        {/* Tile 1: Medicines */}
        <button
          onClick={() => onNavigate('medicines')}
          className="glass-card glass-card-hover rounded-3xl p-6 text-left transition-all flex flex-col justify-between min-h-[175px] group"
        >
          <div className="flex items-start justify-between">
            <div className="w-16 h-16 bg-blue-500/15 text-blue-700 rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-blue-400/30">
              💊
            </div>
            <span className="px-3.5 py-1 text-base font-extrabold rounded-full bg-blue-500/15 text-blue-800 border border-blue-300/50">
              {takenMedsCount}/{totalMedsCount} {language === 'hi' ? 'ली गई' : 'Taken'}
            </span>
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
              {t("home.medicinesTitle", "Medicines")}
            </h2>
            <p className="text-lg text-slate-600 font-semibold mt-1">
              {language === 'hi' ? 'आज की दवाइयाँ व समय' : "Today's schedule & reminders"}
            </p>
          </div>
        </button>

        {/* Tile 2: Appointments */}
        <button
          onClick={() => onNavigate('appointments')}
          className="glass-card glass-card-hover rounded-3xl p-6 text-left transition-all flex flex-col justify-between min-h-[175px] group"
        >
          <div className="flex items-start justify-between">
            <div className="w-16 h-16 bg-purple-500/15 text-purple-700 rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-purple-400/30">
              📅
            </div>
            {nextAppointment && (
              <span className="px-3 py-1 text-sm font-extrabold rounded-full bg-purple-500/15 text-purple-900 border border-purple-300/50">
                {nextAppointment.displayDate}
              </span>
            )}
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-purple-700 transition-colors">
              {t("home.appointmentsTitle", "Appointments")}
            </h2>
            <p className="text-lg text-slate-600 font-semibold mt-1">
              {nextAppointment ? nextAppointment.doctorName : (language === 'hi' ? 'डॉक्टर से मुलाकात' : 'Doctor visits')}
            </p>
          </div>
        </button>

        {/* Tile 3: Wellness */}
        <button
          onClick={() => onNavigate('wellness')}
          className="glass-card glass-card-hover rounded-3xl p-6 text-left transition-all flex flex-col justify-between min-h-[175px] group"
        >
          <div className="flex items-start justify-between">
            <div className="w-16 h-16 bg-rose-500/15 text-rose-600 rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-rose-400/30">
              ❤️
            </div>
            {todayWellness ? (
              <span className="px-3.5 py-1 text-base font-extrabold rounded-full bg-emerald-500/15 text-emerald-800 border border-emerald-300/50">
                {todayWellness.moodEmoji} {todayWellness.moodLabel?.split('/')[0]}
              </span>
            ) : (
              <span className="px-3 py-1 text-sm font-extrabold rounded-full bg-amber-500/15 text-amber-900 border border-amber-300/50">
                {language === 'hi' ? 'जाँच बाकी है' : 'Due today'}
              </span>
            )}
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-rose-600 transition-colors">
              {t("home.wellnessTitle", "How I Feel")}
            </h2>
            <p className="text-lg text-slate-600 font-semibold mt-1">
              {language === 'hi' ? 'दैनिक स्वास्थ्य और मूड' : 'Daily health & mood check-in'}
            </p>
          </div>
        </button>

        {/* Tile 4: Family Direct Call */}
        <a
          href={`tel:${(elderlyUser?.primaryCaregiver?.phone || "+91 98765 00001").replace(/\s+/g, '')}`}
          className="glass-card glass-card-hover rounded-3xl p-6 text-left transition-all flex flex-col justify-between min-h-[175px] group no-underline"
        >
          <div className="flex items-start justify-between">
            <div className="w-16 h-16 bg-emerald-500/15 text-emerald-700 rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-emerald-400/30">
              👨
            </div>
            <Phone className="w-8 h-8 text-emerald-600 animate-pulse" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
              {t("home.familyTitle", "Call Family")}
            </h2>
            <p className="text-lg text-slate-600 font-semibold mt-1">
              {language === 'hi' 
                ? `${elderlyUser?.primaryCaregiver?.name || 'राहुल'} (${elderlyUser?.primaryCaregiver?.relation || 'बेटा'}) को कॉल करें` 
                : `Call ${elderlyUser?.primaryCaregiver?.name || 'Rahul'} (${elderlyUser?.primaryCaregiver?.relation || 'Son'})`}
            </p>
          </div>
        </a>
      </div>

      {/* Big Emergency SOS Card */}
      <div className="pt-2">
        <button
          onClick={() => {
            triggerSOS({
              type: "MANUAL_SOS_HOME_BUTTON",
              location: elderlyUser?.address ? `${elderlyUser.address} (28.4595° N, 77.0266° E)` : "Sector 14, Gurugram (28.4595° N, 77.0266° E)",
              notes: "Elderly pressed main Emergency SOS button on Home screen."
            });
          }}
          className="w-full min-h-[84px] bg-red-600 hover:bg-red-700 active:scale-98 text-white rounded-3xl p-5 flex items-center justify-between shadow-elder-sos border-4 border-red-700 transition-all group"
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white text-red-600 rounded-2xl flex items-center justify-center shadow-md">
              <ShieldAlert className="w-10 h-10 stroke-[2.5]" />
            </div>
            <div className="text-left">
              <div className="text-2xl sm:text-3xl font-black tracking-wide">
                {t("home.sosTitle", "EMERGENCY / SOS")}
              </div>
              <div className="text-base sm:text-lg font-bold text-red-100">
                {language === 'hi' 
                  ? 'तीनों को कॉल (बेटा ➔ पुलिस ➔ एम्बुलेंस) व लोकेशन SMS' 
                  : 'Calls Son ➔ Police ➔ Ambulance + Live GPS SMS'}
              </div>
            </div>
          </div>
          <ArrowRight className="w-8 h-8 stroke-[2.5] mr-2 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};

export default ElderlyHome;
