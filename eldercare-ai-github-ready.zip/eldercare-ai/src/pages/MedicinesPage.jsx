import React, { useState } from 'react';
import { Pill, CheckCircle2, XCircle, Clock, Plus, AlertCircle, Trash2, Calendar, ShieldCheck } from 'lucide-react';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import SpeechReader from '../components/common/SpeechReader.jsx';

export const MedicinesPage = () => {
  const { medicines, updateMedicineStatus, addMedicine, deleteMedicine } = useHealthData();
  const { language, t } = useLanguage();

  const [showAddModal, setShowAddModal] = useState(false);
  const [newMed, setNewMed] = useState({
    name: '',
    dosage: '1 tablet',
    timeSlot: 'Morning',
    scheduledTime: '08:00 AM',
    frequency: 'Daily',
    withFood: 'After breakfast',
    instructions: ''
  });

  const handleCreateMedicine = (e) => {
    e.preventDefault();
    if (!newMed.name || !newMed.scheduledTime) return;

    addMedicine({
      name: newMed.name,
      dosage: newMed.dosage,
      timeSlot: newMed.timeSlot,
      scheduledTime: newMed.scheduledTime,
      frequency: newMed.frequency,
      withFood: newMed.withFood,
      instructions: newMed.instructions || "Take with water as advised by doctor.",
      startDate: new Date().toISOString().split('T')[0],
      endDate: "Ongoing"
    });

    setNewMed({
      name: '',
      dosage: '1 tablet',
      timeSlot: 'Morning',
      scheduledTime: '08:00 AM',
      frequency: 'Daily',
      withFood: 'After breakfast',
      instructions: ''
    });
    setShowAddModal(false);
  };

  const takenCount = medicines.filter(m => m.statusToday === 'TAKEN').length;
  const totalCount = medicines.length;

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Top Header Card */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/15 text-blue-800 rounded-full text-sm font-extrabold uppercase mb-2 border border-blue-300/40">
            <Pill className="w-4 h-4" />
            <span>{takenCount} of {totalCount} Taken Today</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
            {t("medicines.title", "Today's Medicines")}
          </h1>
          <p className="text-lg sm:text-xl font-semibold text-slate-600 mt-1">
            {t("medicines.subtitle", "Track and take your medicines safely on time.")}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="min-h-[56px] px-6 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-md border-2 border-blue-800 active:scale-95 transition-all self-start sm:self-auto"
        >
          <Plus className="w-6 h-6 stroke-[3]" />
          <span>{t("medicines.addBtn", "+ Add Medicine")}</span>
        </button>
      </div>

      {/* Safety Notice Banner */}
      <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 sm:p-5 flex items-start gap-3 shadow-sm">
        <AlertCircle className="w-7 h-7 text-amber-700 flex-shrink-0 mt-0.5" />
        <p className="text-base sm:text-lg font-bold text-amber-950">
          {t("medicines.disclaimer", "⚠️ The AI never independently changes medicine dosage. Always consult your doctor before modifying medication.")}
        </p>
      </div>

      {/* Medicine List */}
      <div className="space-y-4">
        {medicines.map((med) => {
          const isTaken = med.statusToday === 'TAKEN';
          const isSkipped = med.statusToday === 'SKIPPED';
          const isPending = med.statusToday === 'PENDING' || !med.statusToday;

          const spokenSummary = language === 'hi'
            ? `${med.name}, मात्रा: ${med.dosage}, समय: ${med.scheduledTime}, ${med.withFood}। वर्तमान स्थिति: ${isTaken ? 'ली जा चुकी है' : isSkipped ? 'छोड़ दी गई' : 'लेना बाकी है'}`
            : `${med.name}, dosage: ${med.dosage}, scheduled for ${med.scheduledTime}, ${med.withFood}. Status: ${isTaken ? 'Taken' : isSkipped ? 'Skipped' : 'Pending'}`;

          return (
            <div
              key={med.id}
              className={`glass-card rounded-3xl p-6 shadow-lg transition-all ${
                isTaken
                  ? 'border-emerald-400/80 bg-emerald-500/10'
                  : isSkipped
                  ? 'border-slate-300/80 bg-slate-50/60'
                  : 'border-blue-300/90 ring-2 ring-blue-400/20'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                {/* Left: Medicine Info */}
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-sm flex-shrink-0 ${
                    isTaken ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    💊
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                        {med.name}
                      </h2>
                      <span className="px-3 py-0.5 text-sm font-extrabold rounded-full bg-slate-100 text-slate-700 border border-slate-300">
                        {med.dosage}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-lg font-bold text-slate-600">
                      <span className="flex items-center gap-1.5 text-blue-800">
                        <Clock className="w-5 h-5" />
                        <span>{med.scheduledTime}</span>
                      </span>
                      <span>•</span>
                      <span className="text-amber-800">{med.withFood}</span>
                      <span>•</span>
                      <span className="text-slate-500">{med.frequency}</span>
                    </div>

                    {med.instructions && (
                      <p className="text-base text-slate-600 font-medium">
                        📝 {med.instructions}
                      </p>
                    )}

                    {isTaken && (
                      <div className="text-sm font-extrabold text-emerald-700 pt-1">
                        ✅ {t("medicines.statusTaken", "Taken at")} {med.takenAt || "Scheduled time"}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 self-end md:self-center">
                  <SpeechReader text={spokenSummary} label={language === 'hi' ? 'सुने' : 'Listen'} />

                  {/* TAKEN BUTTON */}
                  <button
                    onClick={() => updateMedicineStatus(med.id, 'TAKEN')}
                    className={`min-h-[56px] px-5 py-3 rounded-2xl font-black text-lg flex items-center gap-2 transition-all active:scale-95 shadow ${
                      isTaken
                        ? 'bg-emerald-700 text-white border-2 border-emerald-800'
                        : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border-2 border-emerald-400'
                    }`}
                  >
                    <CheckCircle2 className="w-6 h-6 stroke-[2.5]" />
                    <span>{t("medicines.taken", "TAKEN")}</span>
                  </button>

                  {/* SKIP BUTTON */}
                  <button
                    onClick={() => updateMedicineStatus(med.id, 'SKIPPED')}
                    className={`min-h-[56px] px-4 py-3 rounded-2xl font-bold text-base flex items-center gap-1.5 transition-all active:scale-95 border ${
                      isSkipped
                        ? 'bg-slate-700 text-white border-slate-800'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                    }`}
                  >
                    <XCircle className="w-5 h-5" />
                    <span>{t("medicines.skip", "SKIP")}</span>
                  </button>

                  {/* PENDING RESET BUTTON */}
                  {!isPending && (
                    <button
                      onClick={() => updateMedicineStatus(med.id, 'PENDING')}
                      className="p-3 text-slate-400 hover:text-slate-600 rounded-xl"
                      title="Reset to Pending"
                    >
                      <Clock className="w-6 h-6" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border-2 border-slate-300 p-6 sm:p-8 space-y-5">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {t("medicines.addModalTitle", "Add New Medicine")}
            </h3>

            <form onSubmit={handleCreateMedicine} className="space-y-4">
              <div>
                <label className="block text-lg font-bold text-slate-800 mb-1">
                  {t("medicines.medName", "Medicine Name")} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Amlodipine 5mg"
                  value={newMed.name}
                  onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3.5 text-lg font-medium text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    {t("medicines.dosage", "Dosage")}
                  </label>
                  <input
                    type="text"
                    placeholder="1 tablet"
                    value={newMed.dosage}
                    onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    {t("medicines.time", "Time")} *
                  </label>
                  <input
                    type="text"
                    placeholder="08:00 AM"
                    value={newMed.scheduledTime}
                    onChange={(e) => setNewMed({ ...newMed, scheduledTime: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-base font-bold text-slate-800 mb-1">
                  {t("medicines.withFood", "Food Instructions")}
                </label>
                <select
                  value={newMed.withFood}
                  onChange={(e) => setNewMed({ ...newMed, withFood: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-bold text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
                >
                  <option value="After breakfast">After breakfast / नाश्ते के बाद</option>
                  <option value="Before meals">Before meals / खाने से पहले</option>
                  <option value="After lunch">After lunch / दोपहर के खाने के बाद</option>
                  <option value="After dinner">After dinner / रात के खाने के बाद</option>
                  <option value="With warm milk">With warm milk / दूध के साथ</option>
                </select>
              </div>

              <div>
                <label className="block text-base font-bold text-slate-800 mb-1">
                  Special Instructions
                </label>
                <input
                  type="text"
                  placeholder="e.g. Take with half glass of water"
                  value={newMed.instructions}
                  onChange={(e) => setNewMed({ ...newMed, instructions: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 min-h-[56px] bg-blue-700 hover:bg-blue-800 text-white rounded-2xl font-bold text-xl shadow"
                >
                  {t("medicines.save", "Save Medicine")}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-6 min-h-[56px] bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-2xl font-bold text-lg"
                >
                  {t("medicines.cancel", "Cancel")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicinesPage;
