import React, { useState } from 'react';
import { Heart, Moon, Droplets, Activity, CheckCircle, Clock, Sparkles, Smile, ShieldAlert } from 'lucide-react';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import SpeechReader from '../components/common/SpeechReader.jsx';

export const WellnessPage = () => {
  const { wellnessCheckins, saveWellnessCheckin } = useHealthData();
  const { language, t } = useLanguage();

  const [mood, setMood] = useState('good');
  const [sleepHours, setSleepHours] = useState(7);
  const [waterGlasses, setWaterGlasses] = useState(6);
  const [painLevel, setPainLevel] = useState(2);
  const [painArea, setPainArea] = useState('None');
  const [notes, setNotes] = useState('');
  const [submittedToday, setSubmittedToday] = useState(false);

  const moodOptions = [
    { id: 'good', emoji: '😊', label: t("wellness.moods.good", "Good / बहुत अच्छा"), color: 'hover:bg-emerald-50 border-emerald-300' },
    { id: 'okay', emoji: '🙂', label: t("wellness.moods.okay", "Okay / ठीक-ठाक"), color: 'hover:bg-blue-50 border-blue-300' },
    { id: 'not_great', emoji: '😐', label: t("wellness.moods.not_great", "Not Great / कुछ खास नहीं"), color: 'hover:bg-amber-50 border-amber-300' },
    { id: 'worried', emoji: '😟', label: t("wellness.moods.worried", "Worried / चिंतित"), color: 'hover:bg-orange-50 border-orange-300' },
    { id: 'low', emoji: '😢', label: t("wellness.moods.low", "Very Low / कमज़ोरी"), color: 'hover:bg-rose-50 border-rose-300' },
  ];

  const handleSave = (e) => {
    e.preventDefault();
    const selectedMoodObj = moodOptions.find(m => m.id === mood) || moodOptions[0];

    saveWellnessCheckin({
      mood,
      moodEmoji: selectedMoodObj.emoji,
      moodLabel: selectedMoodObj.label,
      sleepHours: Number(sleepHours),
      sleepQuality: sleepHours >= 7 ? "Good Rest" : "Light Rest",
      waterGlasses: Number(waterGlasses),
      painLevel: Number(painLevel),
      painArea: painArea || "None",
      notes: notes || "Feeling peaceful today."
    });

    setSubmittedToday(true);
  };

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-rose-500/15 text-rose-800 rounded-full text-sm font-extrabold uppercase mb-2 border border-rose-300/40">
          <Heart className="w-4 h-4" />
          <span>Daily Wellness</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
          {t("wellness.title", "Daily Wellness Check-In")}
        </h1>
        <p className="text-lg sm:text-xl font-semibold text-slate-600 mt-1">
          {t("wellness.subtitle", "How are you feeling today?")}
        </p>
      </div>

      {/* Check-in Form Card */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        {submittedToday ? (
          <div className="bg-emerald-50 border-2 border-emerald-400 rounded-2xl p-6 text-center space-y-3">
            <CheckCircle className="w-16 h-16 text-emerald-600 mx-auto" />
            <h2 className="text-2xl sm:text-3xl font-extrabold text-emerald-900">
              {t("wellness.savedSuccess", "Wellness check-in recorded! You are doing great. 🌸")}
            </h2>
            <p className="text-lg text-slate-700 font-semibold">
              {language === 'hi'
                ? 'आपकी सेहत की जानकारी सहेज ली गई है और राहुल को अपडेट मिल गया है।'
                : 'Your daily check-in is logged and Rahul can see your positive routine.'}
            </p>
            <button
              onClick={() => setSubmittedToday(false)}
              className="px-6 py-2.5 bg-white border border-slate-300 text-slate-800 font-bold rounded-xl text-base shadow-sm hover:bg-slate-50"
            >
              Update Today's Status
            </button>
          </div>
        ) : (
          <form onSubmit={handleSave} className="space-y-6">
            {/* 1. Mood Picker */}
            <div>
              <label className="block text-2xl font-extrabold text-slate-900 mb-3">
                1. {t("wellness.moodPrompt", "Choose how your body and mind feel today:")}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {moodOptions.map((m) => {
                  const isSelected = mood === m.id;
                  return (
                    <button
                      type="button"
                      key={m.id}
                      onClick={() => setMood(m.id)}
                      className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all select-none min-h-[110px] ${
                        isSelected
                          ? 'bg-blue-700 text-white border-blue-800 shadow-md scale-105'
                          : `bg-slate-50 text-slate-800 ${m.color}`
                      }`}
                    >
                      <span className="text-4xl">{m.emoji}</span>
                      <span className="text-base font-bold text-center leading-tight">
                        {m.label.split('/')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Sleep Hours */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Moon className="w-6 h-6 text-purple-700" />
                  <span>2. {t("wellness.sleepTitle", "Sleep Last Night")}</span>
                </label>
                <span className="text-2xl font-black text-purple-800">
                  {sleepHours} {t("wellness.hours", "hours")}
                </span>
              </div>
              <input
                type="range"
                min="3"
                max="12"
                step="0.5"
                value={sleepHours}
                onChange={(e) => setSleepHours(Number(e.target.value))}
                className="w-full h-4 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-purple-700"
              />
              <div className="flex justify-between text-sm font-bold text-slate-500 mt-1">
                <span>3 hours</span>
                <span>7-8 hrs (Ideal)</span>
                <span>12 hours</span>
              </div>
            </div>

            {/* 3. Water Intake */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <label className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Droplets className="w-6 h-6 text-blue-600" />
                  <span>3. {t("wellness.waterTitle", "Water Intake Today")}</span>
                </label>
                <span className="text-2xl font-black text-blue-700">
                  {waterGlasses} {t("wellness.glasses", "glasses")}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setWaterGlasses(prev => Math.max(0, prev - 1))}
                  className="w-14 h-14 bg-white border-2 border-slate-300 hover:bg-slate-100 rounded-2xl font-black text-3xl text-slate-800 flex items-center justify-center shadow-sm"
                >
                  -
                </button>
                <div className="flex-1 flex gap-1.5 overflow-x-auto py-1">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <button
                      type="button"
                      key={i}
                      onClick={() => setWaterGlasses(i + 1)}
                      className={`w-10 h-12 rounded-xl text-xl flex items-center justify-center transition-all ${
                        i < waterGlasses ? 'bg-blue-600 text-white shadow' : 'bg-slate-200 text-slate-400'
                      }`}
                    >
                      💧
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => setWaterGlasses(prev => Math.min(15, prev + 1))}
                  className="w-14 h-14 bg-blue-700 hover:bg-blue-800 text-white rounded-2xl font-black text-3xl flex items-center justify-center shadow-md"
                >
                  +
                </button>
              </div>
            </div>

            {/* 4. Discomfort / Pain Level */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Activity className="w-6 h-6 text-rose-600" />
                  <span>4. {t("wellness.painTitle", "Discomfort / Pain (0 - 10)")}</span>
                </label>
                <span className={`text-2xl font-black ${painLevel > 5 ? 'text-red-600' : 'text-slate-800'}`}>
                  {painLevel} / 10 {painLevel === 0 ? '(None)' : painLevel <= 3 ? '(Mild)' : '(Moderate)'}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                step="1"
                value={painLevel}
                onChange={(e) => setPainLevel(Number(e.target.value))}
                className="w-full h-4 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-rose-600"
              />

              {painLevel > 0 && (
                <div className="mt-4">
                  <label className="block text-base font-bold text-slate-800 mb-2">
                    {t("wellness.painArea", "Where is the discomfort?")}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {['Knees (घुटने)', 'Lower Back (कमर)', 'Shoulders (कंधे)', 'Headache (सिरदर्द)', 'General Fatigue (थकान)'].map((area) => (
                      <button
                        type="button"
                        key={area}
                        onClick={() => setPainArea(area)}
                        className={`px-3.5 py-1.5 rounded-xl font-bold text-base transition-colors ${
                          painArea === area
                            ? 'bg-rose-600 text-white shadow'
                            : 'bg-white text-slate-700 border border-slate-300'
                        }`}
                      >
                        {area}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label className="block text-lg font-bold text-slate-800 mb-1">
                {t("wellness.notes", "Any other thoughts or feelings?")}
              </label>
              <textarea
                rows="2"
                placeholder={language === 'hi' ? 'जैसे: सुबह बालकनी में टहलने गई थी...' : 'e.g. Went for a gentle balcony walk in the morning...'}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-50 border-2 border-slate-300 rounded-2xl p-3.5 text-lg font-medium text-slate-900 focus:bg-white focus:border-blue-700 outline-none"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full min-h-[64px] bg-rose-600 hover:bg-rose-700 active:scale-98 text-white rounded-2xl font-extrabold text-2xl shadow-lg border-2 border-rose-700 transition-all flex items-center justify-center gap-3"
            >
              <Heart className="w-8 h-8 fill-current" />
              <span>{t("wellness.saveCheckin", "Save Today's Check-In")}</span>
            </button>
          </form>
        )}
      </div>

      {/* Wellness History List */}
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900">
          {t("wellness.history", "Recent Wellness History")}
        </h2>

        {wellnessCheckins.map((w) => (
          <div
            key={w.id}
            className="bg-white rounded-3xl p-5 shadow-sm border-2 border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="flex items-start gap-4">
              <span className="text-4xl p-2 bg-slate-100 rounded-2xl">{w.moodEmoji}</span>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-extrabold text-slate-900">{w.moodLabel}</h3>
                  <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                    {w.date} • {w.time}
                  </span>
                </div>
                <div className="flex flex-wrap gap-3 text-base font-bold text-slate-600 mt-1">
                  <span>🌙 {w.sleepHours} hrs</span>
                  <span>•</span>
                  <span>💧 {w.waterGlasses} glasses</span>
                  <span>•</span>
                  <span>⚡ Discomfort: {w.painLevel}/10 {w.painArea !== 'None' ? `(${w.painArea})` : ''}</span>
                </div>
                {w.notes && (
                  <p className="text-base text-slate-600 mt-1 italic">
                    "{w.notes}"
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Non-Diagnostic Disclaimer */}
      <div className="p-4 bg-slate-100 border border-slate-300 rounded-2xl flex items-center gap-3 text-slate-600 text-sm">
        <ShieldAlert className="w-5 h-5 flex-shrink-0 text-slate-500" />
        <span>{t("wellness.disclaimer", "Note: Wellness check-in is for daily activity tracking and is not a clinical medical diagnosis.")}</span>
      </div>
    </div>
  );
};

export default WellnessPage;
