import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Phone, MessageSquare, Plus, CheckCircle, ShieldCheck, User } from 'lucide-react';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import SpeechReader from '../components/common/SpeechReader.jsx';

export const AppointmentsPage = ({ onNavigate }) => {
  const { appointments, addAppointment } = useHealthData();
  const { language, t } = useLanguage();

  const [showAddModal, setShowAddModal] = useState(false);
  const [newApt, setNewApt] = useState({
    doctorName: '',
    specialty: '',
    clinicName: '',
    date: '',
    time: '10:30 AM',
    purpose: '',
    notes: ''
  });

  const handleCreateAppointment = (e) => {
    e.preventDefault();
    if (!newApt.doctorName || !newApt.date) return;

    addAppointment({
      doctorName: newApt.doctorName,
      specialty: newApt.specialty || "Physician",
      clinicName: newApt.clinicName || "City Hospital",
      date: newApt.date,
      displayDate: newApt.date,
      time: newApt.time,
      purpose: newApt.purpose || "Regular checkup",
      notes: newApt.notes || "Carry medical diary and reports."
    });

    setNewApt({
      doctorName: '',
      specialty: '',
      clinicName: '',
      date: '',
      time: '10:30 AM',
      purpose: '',
      notes: ''
    });
    setShowAddModal(false);
  };

  const handleAskAiAboutAppointment = (apt) => {
    onNavigate('chat');
  };

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/15 text-purple-800 rounded-full text-sm font-extrabold uppercase mb-2 border border-purple-300/40">
            <Calendar className="w-4 h-4" />
            <span>{appointments.length} Appointments Scheduled</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
            {t("appointments.title", "Upcoming Doctor Appointments")}
          </h1>
          <p className="text-lg sm:text-xl font-semibold text-slate-600 mt-1">
            {t("appointments.subtitle", "Never miss a health checkup or clinic visit.")}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="min-h-[56px] px-6 py-3 bg-purple-700 hover:bg-purple-800 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-md border-2 border-purple-800 active:scale-95 transition-all self-start sm:self-auto"
        >
          <Plus className="w-6 h-6 stroke-[3]" />
          <span>{t("appointments.addBtn", "+ Add Appointment")}</span>
        </button>
      </div>

      {/* Appointment Cards */}
      <div className="space-y-5">
        {appointments.map((apt) => {
          const spokenText = language === 'hi'
            ? `अपॉइंटमेंट: ${apt.doctorName}, ${apt.specialty}। तारीख: ${apt.displayDate}, समय: ${apt.time}। क्लिनिक: ${apt.clinicName}। उद्देश्य: ${apt.purpose}।`
            : `Appointment with ${apt.doctorName}, ${apt.specialty}. On ${apt.displayDate} at ${apt.time} at ${apt.clinicName}. Purpose: ${apt.purpose}.`;

          return (
            <div
              key={apt.id}
              className="glass-card glass-card-hover rounded-3xl p-6 sm:p-8 shadow-xl space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-purple-100 text-purple-700 rounded-2xl flex items-center justify-center text-3xl shadow-sm flex-shrink-0">
                    🩺
                  </div>
                  <div>
                    <span className="px-3 py-1 bg-purple-50 text-purple-900 rounded-full text-sm font-extrabold border border-purple-200">
                      {apt.specialty}
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                      {apt.doctorName}
                    </h2>
                    <p className="text-lg font-bold text-slate-600 mt-0.5">
                      🏥 {apt.clinicName}
                    </p>
                  </div>
                </div>

                <div className="self-start sm:self-auto flex items-center gap-2">
                  <SpeechReader text={spokenText} label={language === 'hi' ? 'सुने' : 'Listen'} />
                  <span className="px-3.5 py-1.5 bg-emerald-100 text-emerald-800 rounded-full text-base font-extrabold">
                    {t("appointments.confirmed", "CONFIRMED")}
                  </span>
                </div>
              </div>

              {/* Date & Time Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-purple-50/70 border border-purple-200 rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-purple-700 flex-shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-purple-900 uppercase">Date / तारीख</div>
                    <div className="text-xl font-extrabold text-slate-900">{apt.displayDate}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-6 h-6 text-purple-700 flex-shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-purple-900 uppercase">Time / समय</div>
                    <div className="text-xl font-extrabold text-slate-900">{apt.time}</div>
                  </div>
                </div>
              </div>

              {/* Purpose & Notes */}
              <div className="space-y-1.5 text-lg font-medium text-slate-800">
                <div>
                  <span className="font-bold text-slate-900">Purpose: </span>
                  {apt.purpose}
                </div>
                {apt.notes && (
                  <div className="text-base text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    💡 <span className="font-bold text-slate-800">Instructions: </span>{apt.notes}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  onClick={() => handleAskAiAboutAppointment(apt)}
                  className="min-h-[52px] px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold text-base flex items-center gap-2 shadow-sm transition-all"
                >
                  <MessageSquare className="w-5 h-5" />
                  <span>{t("appointments.askAi", "Ask AI to Explain Instructions")}</span>
                </button>

                <a
                  href="tel:+919876500002"
                  className="min-h-[52px] px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-base flex items-center gap-2 border border-slate-300 shadow-sm transition-all no-underline"
                >
                  <Phone className="w-5 h-5 text-blue-700" />
                  <span>{t("appointments.callClinic", "Call Clinic")}</span>
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Appointment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border-2 border-slate-300 p-6 sm:p-8 space-y-5">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {t("appointments.addBtn", "+ Add Appointment")}
            </h3>

            <form onSubmit={handleCreateAppointment} className="space-y-4">
              <div>
                <label className="block text-base font-bold text-slate-800 mb-1">
                  Doctor Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Arvind Sharma"
                  value={newApt.doctorName}
                  onChange={(e) => setNewApt({ ...newApt, doctorName: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    Specialty
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Cardiologist"
                    value={newApt.specialty}
                    onChange={(e) => setNewApt({ ...newApt, specialty: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    Clinic / Hospital
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. City Heart Clinic"
                    value={newApt.clinicName}
                    onChange={(e) => setNewApt({ ...newApt, clinicName: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={newApt.date}
                    onChange={(e) => setNewApt({ ...newApt, date: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-base font-bold text-slate-800 mb-1">
                    Time *
                  </label>
                  <input
                    type="text"
                    placeholder="10:30 AM"
                    value={newApt.time}
                    onChange={(e) => setNewApt({ ...newApt, time: e.target.value })}
                    className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-base font-bold text-slate-800 mb-1">
                  Purpose of Visit
                </label>
                <input
                  type="text"
                  placeholder="e.g. Blood pressure checkup"
                  value={newApt.purpose}
                  onChange={(e) => setNewApt({ ...newApt, purpose: e.target.value })}
                  className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-3 text-base font-medium text-slate-900 focus:bg-white focus:border-purple-700 outline-none"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 min-h-[56px] bg-purple-700 hover:bg-purple-800 text-white rounded-2xl font-bold text-xl shadow"
                >
                  Save Appointment
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-6 min-h-[56px] bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-2xl font-bold text-lg"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentsPage;
