import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Phone, 
  MapPin, 
  AlertCircle, 
  Check, 
  Volume2, 
  ArrowRight, 
  Send, 
  CheckCircle2, 
  PhoneCall, 
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';
import { useVoice } from '../contexts/VoiceContext.jsx';
import { useAuth } from '../contexts/AuthContext.jsx';

export const SOSPage = () => {
  const { triggerSOS, setActiveFallModal, setActiveSOSModal } = useHealthData();
  const { elderlyUser, caregiver } = useAuth();
  const { language, t } = useLanguage();
  const { speak } = useVoice();
  const [copied, setCopied] = useState(false);

  const sonPhone = caregiver?.phone || "+91 98765 00001";
  const sonName = caregiver?.name || "Rahul";
  const policePhone = "112";
  const ambulancePhone = "108";

  const sampleLocation = "https://maps.google.com/?q=28.4595,77.0266";
  const locationText = elderlyUser?.address 
    ? `${elderlyUser.address} (28.4595° N, 77.0266° E)`
    : "Sector 14, Gurugram (28.4595° N, 77.0266° E)";

  const smsMessage = `🚨 EMERGENCY ALERT: ${elderlyUser?.name || 'Kamla Devi'} needs urgent assistance! Location: ${locationText} Maps link: ${sampleLocation}`;

  const handleCopyLocation = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`Emergency Location: ${locationText} - ${sampleLocation}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const speakEmergencyInfo = () => {
    const text = language === 'hi'
      ? "कमला जी, यह आपातकालीन सहायता केंद्र है। लाल बटन दबाते ही तीनों नंबरों पर तुरंत जीपीएस लोकेशन एसएमएस जाएगा और पहले राहुल जी, फिर पुलिस 112 और फिर एम्बुलेंस 108 को कॉल लगेगी।"
      : "Emergency Assistance Center. Activating SOS simultaneously sends your GPS location via SMS to all three responders and sequentially connects calls to your Son, Police 112, and Ambulance 108.";
    speak(text);
  };

  const handleTriggerFullSOS = () => {
    triggerSOS({
      type: "DIRECT_TRIPLE_SOS",
      location: locationText,
      notes: "Elderly activated full emergency protocol from SOS page."
    });
  };

  const handleOpenSms = (phone) => {
    const cleanPhone = phone.replace(/\s+/g, '');
    window.location.href = `sms:${cleanPhone}?body=${encodeURIComponent(smsMessage)}`;
  };

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Top Banner with Direct Activation */}
      <div className="bg-red-600 text-white rounded-3xl p-6 sm:p-8 shadow-elder-sos border-4 border-red-700 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-18 h-18 bg-white text-red-600 rounded-2xl flex items-center justify-center p-3 shadow-lg">
              <ShieldAlert className="w-12 h-12 stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight uppercase">
                {language === 'hi' ? '🚨 आपातकालीन सहायता (SOS)' : '🚨 EMERGENCY ASSISTANCE'}
              </h1>
              <p className="text-xl font-bold text-red-100 mt-1">
                {language === 'hi' 
                  ? 'तीनों को एक साथ लोकेशन SMS व क्रमबद्ध डायरेक्ट कॉलिंग'
                  : 'Simultaneous Location SMS & Sequential Auto-Calling to all 3'}
              </p>
            </div>
          </div>

          <button
            onClick={speakEmergencyInfo}
            className="px-4 py-2.5 bg-red-800 hover:bg-red-900 rounded-2xl text-lg font-bold border border-red-400 text-white shadow self-start sm:self-auto flex items-center gap-2"
          >
            <Volume2 className="w-6 h-6" />
            <span>{language === 'hi' ? 'आवाज़ में सुनें' : 'Listen'}</span>
          </button>
        </div>

        {/* Big Action Bar */}
        <div className="mt-6 pt-5 border-t-2 border-red-500/80">
          <button
            onClick={handleTriggerFullSOS}
            className="w-full min-h-[76px] bg-white hover:bg-red-50 active:scale-98 text-red-700 rounded-2xl p-4 flex items-center justify-between font-black text-2xl sm:text-3xl shadow-2xl transition-all border-4 border-red-300"
          >
            <div className="flex items-center gap-3">
              <PhoneCall className="w-9 h-9 text-red-600 animate-bounce" />
              <div className="text-left">
                <div>{language === 'hi' ? 'तीनों को कॉल व लोकेशन SMS भेजें' : 'TRIGGER TRIPLE CALL & SMS NOW'}</div>
                <div className="text-sm sm:text-base font-bold text-slate-700">
                  {language === 'hi' ? '1st बेटा ➔ 2nd पुलिस 112 ➔ 3rd एम्बुलेंस 108' : '1st Son ➔ 2nd Police 112 ➔ 3rd Ambulance 108'}
                </div>
              </div>
            </div>
            <ArrowRight className="w-8 h-8 stroke-[3]" />
          </button>
        </div>
      </div>

      {/* Simultaneous Location SMS Broadcast Box */}
      <div className="bg-emerald-50 border-2 border-emerald-400 rounded-3xl p-6 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 bg-emerald-600 text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow">
            <Send className="w-7 h-7" />
          </div>
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h2 className="text-2xl font-black text-emerald-950">
                {language === 'hi' ? 'तीनों नंबरों पर लोकेशन SMS' : 'Simultaneous Location SMS Alert'}
              </h2>
              <span className="self-start sm:self-auto px-3 py-1 bg-emerald-200 text-emerald-900 font-black text-xs rounded-full uppercase">
                Ready for Instant SMS
              </span>
            </div>
            <p className="text-base text-emerald-900 font-semibold mt-1">
              {language === 'hi'
                ? `जैसे ही आप SOS बटन दबाते हैं, यह GPS पता तीनों नंबरों पर संदेश के रूप में जाता है:`
                : `Whenever SOS is activated, this live GPS address and Google Maps link is broadcast to all three recipients:`}
            </p>
            <div className="p-3 bg-white rounded-xl border border-emerald-300 font-bold text-slate-800 text-base mt-2">
              📍 {locationText}
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
              <button
                onClick={() => handleOpenSms(sonPhone)}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-sm flex items-center gap-1.5 shadow"
              >
                <MessageSquare className="w-4 h-4" />
                <span>SMS Son ({sonName})</span>
              </button>
              <button
                onClick={() => handleOpenSms(policePhone)}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-sm flex items-center gap-1.5 shadow"
              >
                <MessageSquare className="w-4 h-4" />
                <span>SMS Police 112</span>
              </button>
              <button
                onClick={() => handleOpenSms(ambulancePhone)}
                className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl text-sm flex items-center gap-1.5 shadow"
              >
                <MessageSquare className="w-4 h-4" />
                <span>SMS Ambulance 108</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Speed Dial Action Cards (Sequential Call Targets) */}
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900 flex items-center gap-2">
          <Phone className="w-7 h-7 text-red-600" />
          <span>{language === 'hi' ? 'कॉल क्रम (क्रमशः सभी को)' : 'Sequential Call Targets:'}</span>
        </h2>

        {/* 1. Rahul Primary Caregiver */}
        <div className="bg-white rounded-3xl p-5 shadow-elder border-2 border-red-300 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-red-100 text-red-700 rounded-2xl flex items-center justify-center text-3xl font-bold shadow">
              1
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black text-slate-900">
                  {language === 'hi' ? `1. राहुल (${sonName} - बेटा)` : `1. Son (${sonName})`}
                </span>
                <span className="px-2.5 py-0.5 bg-red-100 text-red-800 text-xs font-black rounded-full uppercase">
                  FIRST PRIORITY
                </span>
              </div>
              <div className="text-base text-slate-600 font-bold">{sonPhone} (Primary Caregiver)</div>
            </div>
          </div>
          <a
            href={`tel:${sonPhone.replace(/\s+/g, '')}`}
            className="min-h-[58px] px-6 py-3 bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-2xl font-black text-xl flex items-center justify-center gap-2 shadow-md no-underline transition-all"
          >
            <Phone className="w-6 h-6 stroke-[2.5]" />
            <span>Call Son</span>
          </a>
        </div>

        {/* 2. National Emergency 112 */}
        <div className="bg-white rounded-3xl p-5 shadow-elder border-2 border-slate-300 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-slate-100 text-slate-900 rounded-2xl flex items-center justify-center text-3xl font-bold shadow">
              2
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black text-slate-900">
                  {language === 'hi' ? '2. पुलिस (National Police 112)' : '2. National Police (112)'}
                </span>
                <span className="px-2.5 py-0.5 bg-slate-200 text-slate-900 text-xs font-black rounded-full uppercase">
                  SECOND PRIORITY
                </span>
              </div>
              <div className="text-base text-slate-600 font-bold">112 (Police, Fire & All-India 24x7 Emergency)</div>
            </div>
          </div>
          <a
            href="tel:112"
            className="min-h-[58px] px-6 py-3 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white rounded-2xl font-black text-xl flex items-center justify-center gap-2 shadow-md no-underline transition-all"
          >
            <Phone className="w-6 h-6 stroke-[2.5]" />
            <span>Call 112</span>
          </a>
        </div>

        {/* 3. Ambulance 108 */}
        <div className="bg-white rounded-3xl p-5 shadow-elder border-2 border-emerald-300 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-800 rounded-2xl flex items-center justify-center text-3xl font-bold shadow">
              3
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black text-slate-900">
                  {language === 'hi' ? '3. एम्बुलेंस (Ambulance 108)' : '3. Medical Ambulance (108)'}
                </span>
                <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 text-xs font-black rounded-full uppercase">
                  THIRD PRIORITY
                </span>
              </div>
              <div className="text-base text-slate-600 font-bold">108 / 102 (Immediate Medical Transport & Paramedics)</div>
            </div>
          </div>
          <a
            href="tel:108"
            className="min-h-[58px] px-6 py-3 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-2xl font-black text-xl flex items-center justify-center gap-2 shadow-md no-underline transition-all"
          >
            <Phone className="w-6 h-6 stroke-[2.5]" />
            <span>Call 108</span>
          </a>
        </div>
      </div>

      {/* Fall Assistance Option */}
      <div className="bg-amber-100 border-2 border-amber-400 rounded-3xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-amber-500 text-white rounded-2xl flex items-center justify-center text-3xl">
            🚨
          </div>
          <div>
            <h3 className="text-2xl font-extrabold text-slate-900">
              {language === 'hi' ? 'क्या आप गिर गई हैं?' : 'Did you slip or fall down?'}
            </h3>
            <p className="text-lg text-slate-700 font-bold">
              {language === 'hi' ? 'सुरक्षित उठने के लिए चरणबद्ध सहायता लें' : 'Get step-by-step guided safe recovery assistance'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveFallModal(true)}
          className="min-h-[56px] px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-2xl font-extrabold text-xl shadow border-2 border-amber-700 transition-all flex items-center justify-center gap-2"
        >
          <span>{language === 'hi' ? 'सहायता शुरू करें' : 'Start Fall Recovery'}</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>

      {/* Live Location Box */}
      <div className="bg-white border-2 border-slate-300 rounded-3xl p-6 shadow-elder">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 bg-blue-100 text-blue-700 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0">
            <MapPin className="w-8 h-8" />
          </div>
          <div className="flex-1">
            <h3 className="text-2xl font-extrabold text-slate-900">
              {t("sos.shareLocation", "Current GPS Location")}
            </h3>
            <p className="text-lg text-slate-700 font-medium mt-1">
              📍 {locationText}
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <button
                onClick={handleCopyLocation}
                className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold text-base transition-colors shadow flex items-center gap-2"
              >
                {copied ? <Check className="w-5 h-5" /> : <MapPin className="w-5 h-5" />}
                <span>{copied ? t("sos.locationCopied", "Location Copied!") : "Copy Location Link"}</span>
              </button>

              <a
                href={sampleLocation}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl font-bold text-base transition-colors shadow-sm no-underline"
              >
                Open in Google Maps
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SOSPage;
