import React, { useState } from 'react';
import {
  User, Phone, MapPin, Heart, Stethoscope, Users, Plus, Pencil,
  Trash2, Check, X, ShieldCheck, Save, ChevronDown, ChevronUp
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useHealthData } from '../contexts/HealthDataContext.jsx';
import { useLanguage } from '../contexts/LanguageContext.jsx';

/* ─── Tiny reusable "section card" wrapper ─────────────────────────── */
const SectionCard = ({ icon: Icon, title, color = 'blue', children, defaultOpen = true }) => {
  const [open, setOpen] = useState(defaultOpen);
  const colors = {
    blue:   'bg-blue-500/10  border-blue-300/40  text-blue-900',
    teal:   'bg-teal-500/10  border-teal-300/40  text-teal-900',
    purple: 'bg-purple-500/10 border-purple-300/40 text-purple-900',
    rose:   'bg-rose-500/10  border-rose-300/40  text-rose-900',
    amber:  'bg-amber-500/10 border-amber-300/40 text-amber-900',
  };
  return (
    <div className="glass-card rounded-3xl shadow-xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className={`w-full flex items-center justify-between px-6 py-5 ${colors[color] || colors.blue} border-b backdrop-blur-md`}
      >
        <div className="flex items-center gap-3">
          <Icon className="w-7 h-7" />
          <span className="text-xl sm:text-2xl font-extrabold">{title}</span>
        </div>
        {open ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
      </button>
      {open && <div className="p-6 sm:p-8 space-y-4">{children}</div>}
    </div>
  );
};

/* ─── Single editable field row ────────────────────────────────────── */
const FieldRow = ({ label, value, onChange, type = 'text', placeholder }) => (
  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
    <label className="sm:w-44 text-base font-bold text-slate-600 flex-shrink-0">{label}</label>
    <input
      type={type}
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder || label}
      className="flex-1 bg-slate-50 border-2 border-slate-300 focus:border-blue-600 focus:bg-white rounded-xl px-4 py-3 text-lg font-medium text-slate-900 outline-none transition-colors"
    />
  </div>
);

/* ─── Avatar picker chips ───────────────────────────────────────────── */
const AVATARS = ['👨', '👩', '👴', '👵', '🧑', '🩺', '👮', '🚨', '🚑', '👤'];
const AvatarPicker = ({ value, onChange }) => (
  <div className="flex flex-wrap gap-2">
    {AVATARS.map(a => (
      <button
        key={a}
        type="button"
        onClick={() => onChange(a)}
        className={`w-11 h-11 text-2xl rounded-xl border-2 transition-all ${
          value === a ? 'border-blue-600 bg-blue-50 scale-110 shadow' : 'border-slate-200 bg-white hover:bg-slate-100'
        }`}
      >
        {a}
      </button>
    ))}
  </div>
);

/* ══════════════════════════════════════════════════════════════════════
   MAIN PROFILE PAGE
══════════════════════════════════════════════════════════════════════ */
export const ProfilePage = () => {
  const { elderlyUser, updateElderlyProfile, caregiver, updateCaregiver } = useAuth();
  const { contacts, addContact, updateContact, deleteContact } = useHealthData();
  const { language } = useLanguage();

  /* ── Local draft state so edits can be confirmed / cancelled ──── */
  const [elderlyDraft, setElderlyDraft] = useState({ ...elderlyUser });
  const [doctorDraft,  setDoctorDraft]  = useState({ ...elderlyUser.doctor });
  const [caregiverDraft, setCaregiverDraft] = useState({ ...caregiver });

  const [elderlyDirty, setElderlyDirty]     = useState(false);
  const [doctorDirty,  setDoctorDirty]      = useState(false);
  const [caregiverDirty, setCaregiverDirty] = useState(false);

  /* ── Contact editing state ────────────────────────────────────── */
  const [editingContactId, setEditingContactId] = useState(null);
  const [contactDraft, setContactDraft] = useState({});
  const [showAddContact, setShowAddContact] = useState(false);
  const [newContact, setNewContact] = useState({
    name: '', relation: '', phone: '', avatar: '👤', isPrimary: false
  });

  const [savedBanner, setSavedBanner] = useState('');

  const showBanner = (msg) => {
    setSavedBanner(msg);
    setTimeout(() => setSavedBanner(''), 2800);
  };

  /* ── Helpers ────────────────────────────────────────────────── */
  const patchElderly = (field, value) => {
    setElderlyDraft(d => ({ ...d, [field]: value }));
    setElderlyDirty(true);
  };

  const patchDoctor = (field, value) => {
    setDoctorDraft(d => ({ ...d, [field]: value }));
    setDoctorDirty(true);
  };

  const patchCaregiver = (field, value) => {
    setCaregiverDraft(d => ({ ...d, [field]: value }));
    setCaregiverDirty(true);
  };

  const saveElderly = () => {
    updateElderlyProfile(elderlyDraft);
    setElderlyDirty(false);
    showBanner(language === 'hi' ? '✅ प्रोफ़ाइल सहेज ली गई!' : '✅ Profile saved!');
  };

  const cancelElderly = () => {
    setElderlyDraft({ ...elderlyUser });
    setElderlyDirty(false);
  };

  const saveDoctor = () => {
    updateElderlyProfile({ doctor: doctorDraft });
    setDoctorDirty(false);
    showBanner(language === 'hi' ? '✅ डॉक्टर की जानकारी सहेज ली गई!' : '✅ Doctor details saved!');
  };

  const cancelDoctor = () => {
    setDoctorDraft({ ...elderlyUser.doctor });
    setDoctorDirty(false);
  };

  const saveCaregiver = () => {
    updateCaregiver(caregiverDraft);
    setCaregiverDirty(false);
    showBanner(language === 'hi' ? '✅ देखभालकर्ता की जानकारी सहेज ली गई!' : '✅ Caregiver details saved!');
  };

  const cancelCaregiver = () => {
    setCaregiverDraft({ ...caregiver });
    setCaregiverDirty(false);
  };

  const startEditContact = (c) => {
    setEditingContactId(c.id);
    setContactDraft({ ...c });
  };

  const saveContact = () => {
    updateContact(editingContactId, contactDraft);
    setEditingContactId(null);
    showBanner(language === 'hi' ? '✅ संपर्क सहेज लिया गया!' : '✅ Contact saved!');
  };

  const cancelContact = () => {
    setEditingContactId(null);
    setContactDraft({});
  };

  const handleAddContact = () => {
    if (!newContact.name || !newContact.phone) return;
    addContact(newContact);
    setNewContact({ name: '', relation: '', phone: '', avatar: '👤', isPrimary: false });
    setShowAddContact(false);
    showBanner(language === 'hi' ? '✅ नया संपर्क जोड़ा गया!' : '✅ Contact added!');
  };

  /* ── Save / Cancel action bar ────────────────────────────────── */
  const SaveBar = ({ dirty, onSave, onCancel }) =>
    dirty ? (
      <div className="flex gap-3 pt-2">
        <button
          onClick={onSave}
          className="flex-1 min-h-[52px] bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow"
        >
          <Save className="w-5 h-5" />
          <span>{language === 'hi' ? 'बदलाव सहेजें' : 'Save Changes'}</span>
        </button>
        <button
          onClick={onCancel}
          className="px-5 min-h-[52px] bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-2xl font-bold text-base"
        >
          {language === 'hi' ? 'रद्द करें' : 'Cancel'}
        </button>
      </div>
    ) : null;

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-4xl mx-auto">
      {/* Page Header */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/15 text-blue-800 rounded-full text-sm font-extrabold uppercase mb-2 border border-blue-300/40">
          <User className="w-4 h-4" />
          <span>{language === 'hi' ? 'प्रोफ़ाइल और संपर्क' : 'Profile & Contacts'}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
          {language === 'hi' ? 'प्रोफ़ाइल संपादित करें' : 'Edit Profile & Contacts'}
        </h1>
        <p className="text-lg font-semibold text-slate-600 mt-1">
          {language === 'hi'
            ? 'नाम, फ़ोन नंबर और अन्य जानकारी बदलें और सहेजें।'
            : 'Update names, phone numbers, and other details — changes are saved instantly.'}
        </p>
      </div>

      {/* Floating success banner */}
      {savedBanner && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-emerald-700 text-white rounded-2xl font-bold text-lg shadow-lg animate-bounce">
          {savedBanner}
        </div>
      )}

      {/* ── 1. Elderly User Profile ───────────────────────────────── */}
      <SectionCard icon={User} title={language === 'hi' ? '👵 कमला देवी की प्रोफ़ाइल' : '👵 Elderly User Profile'} color="blue">
        <FieldRow label={language === 'hi' ? 'पूरा नाम' : 'Full Name'}
          value={elderlyDraft.name}
          onChange={v => patchElderly('name', v)} />
        <FieldRow label={language === 'hi' ? 'फ़ोन नंबर' : 'Phone Number'}
          type="tel"
          value={elderlyDraft.phone || ''}
          placeholder="+91 98765 43210"
          onChange={v => patchElderly('phone', v)} />
        <FieldRow label={language === 'hi' ? 'उम्र (वर्ष)' : 'Age (years)'}
          type="number"
          value={elderlyDraft.age}
          onChange={v => patchElderly('age', v)} />
        <FieldRow label={language === 'hi' ? 'ब्लड ग्रुप' : 'Blood Group'}
          value={elderlyDraft.bloodGroup}
          placeholder="O+, A+, B+..."
          onChange={v => patchElderly('bloodGroup', v)} />
        <FieldRow label={language === 'hi' ? 'पता' : 'Address'}
          value={elderlyDraft.address}
          onChange={v => patchElderly('address', v)} />
        <div className="flex flex-col sm:flex-row sm:items-start gap-2 sm:gap-4">
          <label className="sm:w-44 text-base font-bold text-slate-600 flex-shrink-0 pt-1">
            {language === 'hi' ? 'स्वास्थ्य नोट' : 'Health Notes'}
          </label>
          <textarea
            rows={3}
            value={elderlyDraft.emergencyNotes || ''}
            onChange={e => patchElderly('emergencyNotes', e.target.value)}
            placeholder="Known conditions, allergies..."
            className="flex-1 bg-slate-50 border-2 border-slate-300 focus:border-blue-600 focus:bg-white rounded-xl px-4 py-3 text-lg font-medium text-slate-900 outline-none transition-colors"
          />
        </div>
        <SaveBar dirty={elderlyDirty} onSave={saveElderly} onCancel={cancelElderly} />
      </SectionCard>

      {/* ── 2. Primary Caregiver ───────────────────────────────────── */}
      <SectionCard icon={Users} title={language === 'hi' ? '👨 प्राथमिक देखभालकर्ता (राहुल)' : '👨 Primary Caregiver (Rahul)'} color="teal">
        <FieldRow label={language === 'hi' ? 'पूरा नाम' : 'Full Name'}
          value={caregiverDraft.name}
          onChange={v => patchCaregiver('name', v)} />
        <FieldRow label={language === 'hi' ? 'संबंध' : 'Relation'}
          value={caregiverDraft.relation}
          placeholder="Son, Daughter, Spouse..."
          onChange={v => patchCaregiver('relation', v)} />
        <FieldRow label={language === 'hi' ? 'फ़ोन नंबर' : 'Phone Number'}
          type="tel"
          value={caregiverDraft.phone}
          placeholder="+91 98765 00001"
          onChange={v => patchCaregiver('phone', v)} />
        <FieldRow label={language === 'hi' ? 'ईमेल' : 'Email'}
          type="email"
          value={caregiverDraft.email}
          onChange={v => patchCaregiver('email', v)} />
        <SaveBar dirty={caregiverDirty} onSave={saveCaregiver} onCancel={cancelCaregiver} />
      </SectionCard>

      {/* ── 3. Doctor Details ─────────────────────────────────────── */}
      <SectionCard icon={Stethoscope} title={language === 'hi' ? '🩺 डॉक्टर की जानकारी' : '🩺 Doctor Details'} color="purple">
        <FieldRow label={language === 'hi' ? 'डॉक्टर का नाम' : 'Doctor Name'}
          value={doctorDraft.name}
          onChange={v => patchDoctor('name', v)} />
        <FieldRow label={language === 'hi' ? 'विशेषज्ञता' : 'Specialty'}
          value={doctorDraft.specialty}
          placeholder="Cardiologist, GP..."
          onChange={v => patchDoctor('specialty', v)} />
        <FieldRow label={language === 'hi' ? 'क्लिनिक / अस्पताल' : 'Clinic / Hospital'}
          value={doctorDraft.clinic}
          onChange={v => patchDoctor('clinic', v)} />
        <FieldRow label={language === 'hi' ? 'फ़ोन नंबर' : 'Phone Number'}
          type="tel"
          value={doctorDraft.phone}
          onChange={v => patchDoctor('phone', v)} />
        <SaveBar dirty={doctorDirty} onSave={saveDoctor} onCancel={cancelDoctor} />
      </SectionCard>

      {/* ── 4. Emergency & Family Contacts ────────────────────────── */}
      <SectionCard icon={Phone} title={language === 'hi' ? '📞 आपातकालीन और परिवार संपर्क' : '📞 Emergency & Family Contacts'} color="rose">
        <div className="space-y-4">
          {contacts.map((c) => {
            const isEditing = editingContactId === c.id;

            if (isEditing) {
              return (
                <div key={c.id} className="bg-blue-50 border-2 border-blue-300 rounded-2xl p-5 space-y-4">
                  {/* Avatar Picker */}
                  <div>
                    <p className="text-base font-bold text-slate-700 mb-2">
                      {language === 'hi' ? 'अवतार चुनें:' : 'Choose avatar:'}
                    </p>
                    <AvatarPicker
                      value={contactDraft.avatar}
                      onChange={v => setContactDraft(d => ({ ...d, avatar: v }))}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { key: 'name',     label: language === 'hi' ? 'नाम' : 'Name',     type: 'text' },
                      { key: 'relation', label: language === 'hi' ? 'संबंध' : 'Relation', type: 'text' },
                      { key: 'phone',    label: language === 'hi' ? 'फ़ोन' : 'Phone',     type: 'tel' },
                    ].map(({ key, label, type }) => (
                      <div key={key} className="flex flex-col gap-1">
                        <label className="text-sm font-bold text-slate-600">{label}</label>
                        <input
                          type={type}
                          value={contactDraft[key] || ''}
                          onChange={e => setContactDraft(d => ({ ...d, [key]: e.target.value }))}
                          className="bg-white border-2 border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2.5 text-base font-medium text-slate-900 outline-none"
                        />
                      </div>
                    ))}

                    {/* Primary toggle */}
                    <div className="flex flex-col gap-1">
                      <label className="text-sm font-bold text-slate-600">
                        {language === 'hi' ? 'प्राथमिक संपर्क?' : 'Primary Contact?'}
                      </label>
                      <label className="flex items-center gap-3 mt-1 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={!!contactDraft.isPrimary}
                          onChange={e => setContactDraft(d => ({ ...d, isPrimary: e.target.checked }))}
                          className="w-5 h-5 rounded text-blue-600"
                        />
                        <span className="text-base font-semibold text-slate-800">
                          {language === 'hi' ? 'हाँ, यह प्राथमिक है' : 'Yes, mark as primary'}
                        </span>
                      </label>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-1">
                    <button
                      onClick={saveContact}
                      className="flex-1 min-h-[50px] bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      <span>{language === 'hi' ? 'सहेजें' : 'Save'}</span>
                    </button>
                    <button
                      onClick={cancelContact}
                      className="px-5 min-h-[50px] bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-2xl font-bold text-base"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={c.id}
                className={`flex items-center justify-between gap-3 p-4 rounded-2xl border-2 ${
                  c.isPrimary ? 'bg-rose-50 border-rose-300' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-2xl shadow-sm border border-slate-200">
                    {c.avatar}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-extrabold text-slate-900">{c.name}</span>
                      {c.isPrimary && (
                        <span className="px-2 py-0.5 bg-rose-200 text-rose-900 text-xs font-extrabold rounded-full">
                          PRIMARY
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-semibold text-slate-600">
                      {c.relation} • {c.phone}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => startEditContact(c)}
                    className="p-2.5 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded-xl transition-colors"
                    title="Edit contact"
                  >
                    <Pencil className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => deleteContact(c.id)}
                    className="p-2.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl transition-colors"
                    title="Delete contact"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Add New Contact */}
        {showAddContact ? (
          <div className="mt-4 bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 space-y-4">
            <h4 className="text-lg font-extrabold text-slate-900">
              {language === 'hi' ? 'नया संपर्क जोड़ें' : 'Add New Contact'}
            </h4>

            <div>
              <p className="text-sm font-bold text-slate-600 mb-2">
                {language === 'hi' ? 'अवतार चुनें:' : 'Choose avatar:'}
              </p>
              <AvatarPicker
                value={newContact.avatar}
                onChange={v => setNewContact(d => ({ ...d, avatar: v }))}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { key: 'name',     label: language === 'hi' ? 'नाम *' : 'Name *',       type: 'text' },
                { key: 'relation', label: language === 'hi' ? 'संबंध' : 'Relation',      type: 'text' },
                { key: 'phone',    label: language === 'hi' ? 'फ़ोन *' : 'Phone Number *', type: 'tel' },
              ].map(({ key, label, type }) => (
                <div key={key} className="flex flex-col gap-1">
                  <label className="text-sm font-bold text-slate-600">{label}</label>
                  <input
                    type={type}
                    value={newContact[key]}
                    onChange={e => setNewContact(d => ({ ...d, [key]: e.target.value }))}
                    className="bg-white border-2 border-slate-300 focus:border-amber-500 rounded-xl px-3 py-2.5 text-base font-medium text-slate-900 outline-none"
                    placeholder={label.replace(' *', '')}
                  />
                </div>
              ))}

              <div className="flex flex-col gap-1">
                <label className="text-sm font-bold text-slate-600">
                  {language === 'hi' ? 'प्राथमिक संपर्क?' : 'Primary Contact?'}
                </label>
                <label className="flex items-center gap-3 mt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newContact.isPrimary}
                    onChange={e => setNewContact(d => ({ ...d, isPrimary: e.target.checked }))}
                    className="w-5 h-5 rounded text-blue-600"
                  />
                  <span className="text-base font-semibold text-slate-800">
                    {language === 'hi' ? 'हाँ, प्राथमिक बनाएँ' : 'Mark as primary'}
                  </span>
                </label>
              </div>
            </div>

            <div className="flex gap-3 pt-1">
              <button
                onClick={handleAddContact}
                disabled={!newContact.name || !newContact.phone}
                className="flex-1 min-h-[52px] bg-amber-600 hover:bg-amber-700 disabled:opacity-40 disabled:pointer-events-none text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow"
              >
                <Plus className="w-5 h-5" />
                <span>{language === 'hi' ? 'संपर्क जोड़ें' : 'Add Contact'}</span>
              </button>
              <button
                onClick={() => setShowAddContact(false)}
                className="px-5 min-h-[52px] bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-2xl font-bold text-base"
              >
                {language === 'hi' ? 'रद्द' : 'Cancel'}
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowAddContact(true)}
            className="mt-4 w-full min-h-[56px] border-2 border-dashed border-slate-400 hover:border-blue-500 hover:bg-blue-50 text-slate-700 hover:text-blue-800 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
            <span>{language === 'hi' ? '+ नया संपर्क जोड़ें' : '+ Add New Contact'}</span>
          </button>
        )}

        {/* Safety disclaimer */}
        <div className="flex items-start gap-3 p-4 bg-slate-100 rounded-2xl text-sm text-slate-600 font-medium mt-2">
          <ShieldCheck className="w-5 h-5 flex-shrink-0 text-slate-500 mt-0.5" />
          <span>
            {language === 'hi'
              ? 'आपातकाल में SOS बटन का उपयोग करें। यहाँ केवल संपर्क प्रबंधन किया जाता है।'
              : 'In a real emergency always use the SOS button. This section only manages your contact list.'}
          </span>
        </div>
      </SectionCard>
    </div>
  );
};

export default ProfilePage;
