import React, { createContext, useContext, useState, useEffect, useMemo } from "react";
import confetti from "canvas-confetti";
import { api } from "../services/api.js";
import { seedMedicines, seedAppointments, seedWellnessCheckins, seedEmergencyContacts, seedEmergencyEvents } from "../../server/data/seedData.js";
import { calculateCareScore } from "../utils/careScore.js";

const HealthDataContext = createContext(null);

export const HealthDataProvider = ({ children }) => {
  const [medicines, setMedicines] = useState(() => {
    const saved = localStorage.getItem("eldercare_medicines");
    return saved ? JSON.parse(saved) : seedMedicines;
  });

  const [appointments, setAppointments] = useState(() => {
    const saved = localStorage.getItem("eldercare_appointments");
    return saved ? JSON.parse(saved) : seedAppointments;
  });

  const [wellnessCheckins, setWellnessCheckins] = useState(() => {
    const saved = localStorage.getItem("eldercare_wellness");
    return saved ? JSON.parse(saved) : seedWellnessCheckins;
  });

  const [emergencyEvents, setEmergencyEvents] = useState(() => {
    const saved = localStorage.getItem("eldercare_sos_events");
    return saved ? JSON.parse(saved) : seedEmergencyEvents;
  });

  const [contacts, setContacts] = useState(() => {
    try {
      const saved = localStorage.getItem("eldercare_contacts");
      return saved ? JSON.parse(saved) : seedEmergencyContacts;
    } catch {
      return seedEmergencyContacts;
    }
  });
  const [activeSOSModal, setActiveSOSModal] = useState(false);
  const [activeFallModal, setActiveFallModal] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem("eldercare_medicines", JSON.stringify(medicines));
  }, [medicines]);

  useEffect(() => {
    localStorage.setItem("eldercare_appointments", JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem("eldercare_wellness", JSON.stringify(wellnessCheckins));
  }, [wellnessCheckins]);

  useEffect(() => {
    localStorage.setItem("eldercare_sos_events", JSON.stringify(emergencyEvents));
  }, [emergencyEvents]);

  useEffect(() => {
    localStorage.setItem("eldercare_contacts", JSON.stringify(contacts));
  }, [contacts]);

  // Initial load from backend API if available
  useEffect(() => {
    async function loadData() {
      const serverMeds = await api.getMedicines();
      if (serverMeds && Array.isArray(serverMeds) && serverMeds.length > 0) {
        setMedicines(serverMeds);
      }
      const serverApts = await api.getAppointments();
      if (serverApts && Array.isArray(serverApts)) {
        setAppointments(serverApts);
      }
      const serverWellness = await api.getWellnessCheckins();
      if (serverWellness && Array.isArray(serverWellness)) {
        setWellnessCheckins(serverWellness);
      }
      const serverEvents = await api.getEmergencyEvents();
      if (serverEvents && Array.isArray(serverEvents)) {
        setEmergencyEvents(serverEvents);
      }
    }
    loadData();
  }, []);

  // Update Medicine Status ([TAKEN], [SKIP], [PENDING])
  const updateMedicineStatus = async (id, status) => {
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMedicines(prev => prev.map(med => {
      if (med.id === id) {
        return {
          ...med,
          statusToday: status,
          takenAt: status === "TAKEN" ? nowTime : undefined
        };
      }
      return med;
    }));

    if (status === "TAKEN") {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 }
        });
      } catch (e) {}
    }

    await api.updateMedicineStatus(id, status);
  };

  // Add Medicine
  const addMedicine = async (medData) => {
    const newMed = {
      id: `med_${Date.now()}`,
      userId: "elderly_kamla_001",
      statusToday: "PENDING",
      ...medData
    };
    setMedicines(prev => [newMed, ...prev]);
    await api.addMedicine(newMed);
  };

  // Delete Medicine
  const deleteMedicine = (id) => {
    setMedicines(prev => prev.filter(m => m.id !== id));
  };

  // Add Appointment
  const addAppointment = async (aptData) => {
    const newApt = {
      id: `apt_${Date.now()}`,
      userId: "elderly_kamla_001",
      status: "CONFIRMED",
      ...aptData
    };
    setAppointments(prev => [newApt, ...prev]);
    await api.addAppointment(newApt);
  };

  // Save Wellness Check-in
  const saveWellnessCheckin = async (checkinData) => {
    const now = new Date();
    const newCheckin = {
      id: `well_${Date.now()}`,
      userId: "elderly_kamla_001",
      date: now.toISOString().split("T")[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      ...checkinData
    };

    setWellnessCheckins(prev => [newCheckin, ...prev]);
    try {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.6 }
      });
    } catch (e) {}
    await api.saveWellnessCheckin(newCheckin);
  };

  // Trigger SOS Event
  const triggerSOS = async (details = {}) => {
    const newEvent = {
      id: `sos_${Date.now()}`,
      userId: "elderly_kamla_001",
      timestamp: new Date().toISOString(),
      displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: details.type || "MANUAL_SOS_BUTTON",
      status: "ACTIVE_ALERT",
      triggeredBy: "Kamla Devi",
      location: details.location || "GPS: 28.4595° N, 77.0266° E (Gurugram)",
      isDemo: true,
      caregiverNotified: true,
      userNotes: details.notes || "Emergency SOS pressed by elderly user."
    };

    setEmergencyEvents(prev => [newEvent, ...prev]);
    setActiveSOSModal(true);
    await api.triggerSOS(newEvent);
  };

  // Trigger Fall Recovery Flow
  const reportFallAssistance = async (ableToMove, stepReached) => {
    const fallEvent = {
      id: `fall_${Date.now()}`,
      userId: "elderly_kamla_001",
      timestamp: new Date().toISOString(),
      displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: ableToMove ? "FALL_ASSISTED_RECOVERY" : "FALL_IMMOBILIZED_ALERT",
      status: ableToMove ? "RECOVERED_GUIDED" : "CRITICAL_HELP_DISPATCHED",
      triggeredBy: "Kamla Devi",
      ableToMove,
      stepReached
    };

    setEmergencyEvents(prev => [fallEvent, ...prev]);
    await api.reportFallAssistance(fallEvent);
  };

  // Resolve Emergency Event
  const resolveEmergencyEvent = (id) => {
    setEmergencyEvents(prev => prev.map(e => e.id === id ? { ...e, status: "RESOLVED" } : e));
  };

  // ── Contact CRUD ──────────────────────────────────────────────────────────
  /** Add a new emergency / family contact */
  const addContact = (contactData) => {
    const newContact = {
      id: `cont_${Date.now()}`,
      avatar: contactData.avatar || "👤",
      isPrimary: false,
      ...contactData,
    };
    setContacts(prev => [...prev, newContact]);
  };

  /** Update an existing contact by id (partial merge) */
  const updateContact = (id, updates) => {
    setContacts(prev =>
      prev.map(c => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  /** Delete a contact by id */
  const deleteContact = (id) => {
    setContacts(prev => prev.filter(c => c.id !== id));
  };

  // ── Care Activity Score ───────────────────────────────────────────────────
  // Compute Care Activity Score
  const careScore = useMemo(() => {
    return calculateCareScore({
      medicines,
      wellnessCheckins,
      appointments
    });
  }, [medicines, wellnessCheckins, appointments]);

  return (
    <HealthDataContext.Provider
      value={{
        medicines,
        updateMedicineStatus,
        addMedicine,
        deleteMedicine,
        appointments,
        addAppointment,
        wellnessCheckins,
        saveWellnessCheckin,
        emergencyEvents,
        triggerSOS,
        reportFallAssistance,
        resolveEmergencyEvent,
        contacts,
        addContact,
        updateContact,
        deleteContact,
        careScore,
        activeSOSModal,
        setActiveSOSModal,
        activeFallModal,
        setActiveFallModal
      }}
    >
      {children}
    </HealthDataContext.Provider>
  );
};

export const useHealthData = () => {
  const context = useContext(HealthDataContext);
  if (!context) {
    throw new Error("useHealthData must be used within a HealthDataProvider");
  }
  return context;
};
