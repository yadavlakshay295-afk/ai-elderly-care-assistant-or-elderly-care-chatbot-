import React, { createContext, useContext, useState, useEffect } from "react";
import enTranslations from "../locales/en.json";
import hiTranslations from "../locales/hi.json";

const LanguageContext = createContext(null);

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem("eldercare_language") || "hi"; // Default to Hindi for elderly warmth
  });

  useEffect(() => {
    localStorage.setItem("eldercare_language", language);
    document.documentElement.lang = language;
  }, [language]);

  const translations = language === "hi" ? hiTranslations : enTranslations;

  /**
   * Helper to retrieve nested translation keys like 'nav.home'
   */
  const t = (path, fallback = "") => {
    if (!path) return "";
    const keys = path.split(".");
    let current = translations;
    for (const key of keys) {
      if (current && typeof current === "object" && key in current) {
        current = current[key];
      } else {
        // Fallback to English if key is missing in Hindi
        let enCurrent = enTranslations;
        for (const k of keys) {
          if (enCurrent && typeof enCurrent === "object" && k in enCurrent) {
            enCurrent = enCurrent[k];
          } else {
            return fallback || path;
          }
        }
        return enCurrent || fallback || path;
      }
    }
    return current || fallback || path;
  };

  const toggleLanguage = () => {
    setLanguage(prev => (prev === "hi" ? "en" : "hi"));
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
