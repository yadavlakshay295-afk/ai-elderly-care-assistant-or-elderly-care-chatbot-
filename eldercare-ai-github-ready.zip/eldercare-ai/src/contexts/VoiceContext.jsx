import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import speechService from "../services/speechService.js";
import { useLanguage } from "./LanguageContext.jsx";

const VoiceContext = createContext(null);

export const VoiceProvider = ({ children }) => {
  const { language } = useLanguage();
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speechRate, setSpeechRate] = useState(0.88);
  const [autoSpeak, setAutoSpeak] = useState(true);

  // Monitor speaking status
  useEffect(() => {
    const checkInterval = setInterval(() => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        setIsSpeaking(window.speechSynthesis.speaking);
      }
    }, 200);
    return () => clearInterval(checkInterval);
  }, []);

  const speak = useCallback((text) => {
    if (!text) return;
    speechService.speak(text, language, speechRate);
    setIsSpeaking(true);
  }, [language, speechRate]);

  const stopSpeaking = useCallback(() => {
    speechService.stopSpeaking();
    setIsSpeaking(false);
  }, []);

  const startListening = useCallback((onResult, onError) => {
    setIsListening(true);
    speechService.startListening({
      lang: language === 'hi' ? 'hi-IN' : 'en-IN',
      onResult: (transcript) => {
        setIsListening(false);
        if (onResult) onResult(transcript);
      },
      onError: (err) => {
        setIsListening(false);
        if (onError) onError(err);
      },
      onEnd: () => {
        setIsListening(false);
      }
    });
  }, [language]);

  const stopListening = useCallback(() => {
    speechService.stopListening();
    setIsListening(false);
  }, []);

  return (
    <VoiceContext.Provider
      value={{
        isSpeaking,
        isListening,
        speechRate,
        setSpeechRate,
        autoSpeak,
        setAutoSpeak,
        speak,
        stopSpeaking,
        startListening,
        stopListening,
        isSupported: speechService.isSpeechRecognitionSupported()
      }}
    >
      {children}
    </VoiceContext.Provider>
  );
};

export const useVoice = () => {
  const context = useContext(VoiceContext);
  if (!context) {
    throw new Error("useVoice must be used within a VoiceProvider");
  }
  return context;
};
