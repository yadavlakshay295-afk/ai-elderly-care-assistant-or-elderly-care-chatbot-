import React, { createContext, useContext, useState, useEffect } from "react";
import { seedElderlyProfile } from "../../server/data/seedData.js";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  // Current active view role: 'elderly' or 'caregiver'
  const [currentRole, setCurrentRole] = useState(() => {
    return localStorage.getItem("eldercare_role") || "elderly";
  });

  // Elderly profile — persisted to localStorage so edits survive reload
  const [elderlyUser, setElderlyUser] = useState(() => {
    try {
      const saved = localStorage.getItem("eldercare_elderly_profile");
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure default phone is present if omitted in older saved state
        return { ...seedElderlyProfile, ...parsed, phone: parsed.phone || seedElderlyProfile.phone };
      }
      return seedElderlyProfile;
    } catch {
      return seedElderlyProfile;
    }
  });

  // Caregiver profile — persisted to localStorage
  const [caregiver, setCaregiver] = useState(() => {
    try {
      const saved = localStorage.getItem("eldercare_caregiver_profile");
      if (saved) {
        const parsed = JSON.parse(saved);
        // If the saved phone is the old default dummy, update it to the new specified phone
        const phone = (!parsed.phone || parsed.phone.includes("9876543210") || parsed.phone.includes("98765 43210"))
          ? seedElderlyProfile.primaryCaregiver.phone
          : parsed.phone;
        return { ...seedElderlyProfile.primaryCaregiver, ...parsed, phone };
      }
      return seedElderlyProfile.primaryCaregiver;
    } catch {
      return seedElderlyProfile.primaryCaregiver;
    }
  });

  const [isDemoMode, setIsDemoMode] = useState(true);
  const [fontSizeScale, setFontSizeScale] = useState(() => {
    return Number(localStorage.getItem("eldercare_font_scale")) || 1.1;
  });

  // Sync role to localStorage
  useEffect(() => {
    localStorage.setItem("eldercare_role", currentRole);
  }, [currentRole]);

  // Sync font scale to localStorage and CSS variable
  useEffect(() => {
    localStorage.setItem("eldercare_font_scale", fontSizeScale.toString());
    document.documentElement.style.setProperty("--font-scale", fontSizeScale.toString());
  }, [fontSizeScale]);

  // Sync elderly profile to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("eldercare_elderly_profile", JSON.stringify(elderlyUser));
  }, [elderlyUser]);

  // Sync caregiver profile to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("eldercare_caregiver_profile", JSON.stringify(caregiver));
  }, [caregiver]);

  const switchRole = (role) => {
    setCurrentRole(role);
  };

  /**
   * Partially update the elderly user profile.
   * Merges the provided fields with the existing profile.
   * @param {object} updates - Fields to update (e.g. { name, age, phone })
   */
  const updateElderlyProfile = (updates) => {
    setElderlyUser((prev) => ({
      ...prev,
      ...updates,
      // Support nested doctor update
      ...(updates.doctor
        ? { doctor: { ...prev.doctor, ...updates.doctor } }
        : {}),
    }));
  };

  /**
   * Partially update the primary caregiver profile.
   * @param {object} updates - Fields to update (e.g. { name, phone, relation })
   */
  const updateCaregiver = (updates) => {
    setCaregiver((prev) => ({ ...prev, ...updates }));
    // Also keep elderlyUser.primaryCaregiver in sync
    setElderlyUser((prev) => ({
      ...prev,
      primaryCaregiver: { ...prev.primaryCaregiver, ...updates },
    }));
  };

  return (
    <AuthContext.Provider
      value={{
        currentRole,
        switchRole,
        elderlyUser,
        setElderlyUser,
        updateElderlyProfile,
        caregiver,
        setCaregiver,
        updateCaregiver,
        isDemoMode,
        setIsDemoMode,
        fontSizeScale,
        setFontSizeScale,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
