// Speech Service using Web Speech API (STT + TTS)
// Optimized for elderly users: calm pacing, clear articulation, Hindi & English voice selection

class SpeechService {
  constructor() {
    this.synth = typeof window !== 'undefined' ? window.speechSynthesis : null;
    this.recognition = null;
    this.isListening = false;
    this.voices = [];

    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.maxAlternatives = 1;
      }

      if (this.synth) {
        this.loadVoices();
        if (speechSynthesis.onvoiceschanged !== undefined) {
          speechSynthesis.onvoiceschanged = () => this.loadVoices();
        }
      }
    }
  }

  loadVoices() {
    if (!this.synth) return [];
    this.voices = this.synth.getVoices();
    return this.voices;
  }

  /**
   * Speak text out loud with elderly-friendly calm cadence.
   * @param {string} text - Text to speak
   * @param {string} lang - 'hi' or 'en'
   * @param {number} rate - Speech speed (default 0.88 for elder clarity)
   */
  speak(text, lang = 'en', rate = 0.88) {
    if (!this.synth || !text) return;

    // Cancel any ongoing speech
    this.synth.cancel();

    // Clean markdown/emojis for clean speech
    const cleanText = text
      .replace(/[*#_`]/g, '')
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = rate;
    utterance.pitch = 1.0;

    // Pick best matching voice
    if (this.voices.length === 0) {
      this.loadVoices();
    }

    if (lang === 'hi') {
      utterance.lang = 'hi-IN';
      const hiVoice = this.voices.find(v => v.lang.includes('hi') || v.name.includes('Hindi') || v.name.includes('Indian'));
      if (hiVoice) utterance.voice = hiVoice;
    } else {
      utterance.lang = 'en-IN';
      const enVoice = this.voices.find(v => v.lang.includes('en-IN') || v.lang.includes('en-GB') || v.lang.includes('en-US'));
      if (enVoice) utterance.voice = enVoice;
    }

    this.synth.speak(utterance);
  }

  /**
   * Stop speaking immediately.
   */
  stopSpeaking() {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  /**
   * Start microphone listening.
   * @param {string} lang - 'hi-IN' or 'en-IN'
   * @param {Function} onResult - Callback with transcript string
   * @param {Function} onError - Callback on error
   * @param {Function} onEnd - Callback when stopped
   */
  startListening({ lang = 'en-IN', onResult, onError, onEnd }) {
    if (!this.recognition) {
      if (onError) onError(new Error("Speech recognition is not supported in this browser. Please use text input."));
      return;
    }

    try {
      this.recognition.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
      
      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (onResult) onResult(transcript);
      };

      this.recognition.onerror = (event) => {
        console.warn("Speech Recognition Error:", event.error);
        if (onError) onError(event);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (onEnd) onEnd();
      };

      this.isListening = true;
      this.recognition.start();
    } catch (err) {
      this.isListening = false;
      if (onError) onError(err);
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  isSpeechRecognitionSupported() {
    return Boolean(this.recognition);
  }
}

export const speechService = new SpeechService();
export default speechService;
