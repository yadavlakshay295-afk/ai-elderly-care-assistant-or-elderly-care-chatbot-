// Client API Service for ElderCare AI
// Connects to Node.js backend with graceful local offline resilience

const BASE_URL = "/api";

export const api = {
  // Check Backend Health
  async getHealth() {
    try {
      const res = await fetch(`${BASE_URL}/health`);
      return await res.json();
    } catch (err) {
      console.warn("Backend unavailable, using client local mode:", err.message);
      return { 
        status: "client-offline-mode", 
        aiEngine: "Local Intelligence Engine (API-Free)" 
      };
    }
  },

  // AI Chat
  async sendChatMessage({ message, language = "en", userContext }) {
    try {
      const res = await fetch(`${BASE_URL}/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, language, userContext })
      });
      if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
      const json = await res.json();
      return json.data;
    } catch (err) {
      console.warn("Using local client fallback:", err.message);
      // Client-side fallback response
      const isHindi = language === "hi";
      return {
        text: isHindi 
          ? "कमला जी, मैं यहाँ आपकी सहायता के लिए उपस्थित हूँ। आपकी दवाई और स्वास्थ्य का पूरा ध्यान रखा जा रहा है।"
          : "I am here with you. Your health, comfort, and peace of mind are my top priority.",
        intent: "GENERAL_CHAT",
        severity: "LOW",
        requires_human_help: false,
        engine: "ElderCare Local Intelligence Engine"
      };
    }
  },

  // Classify Intent
  async classifyIntent(message, language = "en") {
    try {
      const res = await fetch(`${BASE_URL}/ai/classify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, language })
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return { intent: "GENERAL_CHAT", severity: "LOW", requires_human_help: false };
    }
  },

  // Medicines
  async getMedicines() {
    try {
      const res = await fetch(`${BASE_URL}/medicines`);
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null; // Signals context to use local storage
    }
  },

  async updateMedicineStatus(id, status) {
    try {
      const res = await fetch(`${BASE_URL}/medicines/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  async addMedicine(medicineData) {
    try {
      const res = await fetch(`${BASE_URL}/medicines`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(medicineData)
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  // Appointments
  async getAppointments() {
    try {
      const res = await fetch(`${BASE_URL}/appointments`);
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  async addAppointment(aptData) {
    try {
      const res = await fetch(`${BASE_URL}/appointments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(aptData)
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  // Wellness
  async getWellnessCheckins() {
    try {
      const res = await fetch(`${BASE_URL}/wellness`);
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  async saveWellnessCheckin(checkinData) {
    try {
      const res = await fetch(`${BASE_URL}/wellness`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(checkinData)
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  },

  // Emergency SOS & Falls
  async triggerSOS(data) {
    try {
      const res = await fetch(`${BASE_URL}/emergency/trigger`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return { id: `sos_${Date.now()}`, ...data, status: "ACTIVE_ALERT" };
    }
  },

  async reportFallAssistance(data) {
    try {
      const res = await fetch(`${BASE_URL}/emergency/fall-assistance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      return json.data;
    } catch (err) {
      return { id: `fall_${Date.now()}`, ...data };
    }
  },

  async getEmergencyEvents() {
    try {
      const res = await fetch(`${BASE_URL}/emergency/events`);
      const json = await res.json();
      return json.data;
    } catch (err) {
      return null;
    }
  }
};
